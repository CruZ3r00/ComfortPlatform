--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Debian 17.10-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: classify_staff_role_for_category(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.classify_staff_role_for_category(p_category text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  v text := lower(coalesce(p_category, ''));
begin
  if v ~ '(bevande|bibite|drink|cocktail|vino|vini|birra|birre|amari|liquori|distillati|aperitivi|\ybar\y|caffe|caffè|acqua|soft drink|analcolic)' then
    return 'bar';
  end if;

  if v ~ '(senza glutine|gluten free|gluten-free|\ysg\y|celiac|celiach)' then
    return 'cucina_sg';
  end if;

  if v ~ '(pizza|pizze|pizzeria|focaccia|calzone)' then
    return 'pizzeria';
  end if;

  return 'cucina';
end;
$$;


--
-- Name: copy_owner_auth_role_link(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.copy_owner_auth_role_link(p_staff_id integer, p_owner_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_role_id integer;
begin
  if to_regclass('public.up_users_role_lnk') is null then
    return;
  end if;

  select role_id into v_role_id
  from public.up_users_role_lnk
  where user_id = p_owner_id
  limit 1;

  if v_role_id is not null then
    insert into public.up_users_role_lnk (user_id, role_id)
    values (p_staff_id, v_role_id)
    on conflict do nothing;
  end if;
end;
$$;


--
-- Name: emit_order_realtime_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.emit_order_realtime_event() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_source_id integer;
  v_order_id integer;
  v_user_id integer;
begin
  if TG_TABLE_NAME = 'orders' then
    v_order_id := coalesce(NEW.id, OLD.id);
    v_source_id := v_order_id;
  elsif TG_TABLE_NAME = 'order_items' then
    v_source_id := coalesce(NEW.id, OLD.id);

    select l.order_id
      into v_order_id
      from public.order_items_fk_order_lnk l
     where l.order_item_id = v_source_id
     limit 1;
  elsif TG_TABLE_NAME = 'orders_fk_user_lnk' then
    v_order_id := coalesce(NEW.order_id, OLD.order_id);
    v_source_id := v_order_id;
    v_user_id := coalesce(NEW.user_id, OLD.user_id);
  elsif TG_TABLE_NAME = 'order_items_fk_order_lnk' then
    v_source_id := coalesce(NEW.order_item_id, OLD.order_item_id);
    v_order_id := coalesce(NEW.order_id, OLD.order_id);
  elsif TG_TABLE_NAME = 'tables_fk_user_lnk' then
    v_source_id := coalesce(NEW.table_id, OLD.table_id);
    v_user_id := coalesce(NEW.user_id, OLD.user_id);
  elsif TG_TABLE_NAME = 'reservations_fk_user_lnk' then
    v_source_id := coalesce(NEW.reservation_id, OLD.reservation_id);
    v_user_id := coalesce(NEW.user_id, OLD.user_id);
  elsif TG_TABLE_NAME = 'tables' then
    v_source_id := coalesce(NEW.id, OLD.id);

    select l.user_id
      into v_user_id
      from public.tables_fk_user_lnk l
     where l.table_id = v_source_id
     limit 1;
  elsif TG_TABLE_NAME = 'reservations' then
    v_source_id := coalesce(NEW.id, OLD.id);

    select l.user_id
      into v_user_id
      from public.reservations_fk_user_lnk l
     where l.reservation_id = v_source_id
     limit 1;
  else
    return coalesce(NEW, OLD);
  end if;

  if v_user_id is null and v_order_id is not null then
    select l.user_id
      into v_user_id
      from public.orders_fk_user_lnk l
     where l.order_id = v_order_id
     limit 1;
  end if;

  if v_user_id is not null then
    insert into public.order_realtime_events (user_id, source_table, source_id, event_type)
    values (v_user_id, TG_TABLE_NAME, v_source_id, TG_OP);
  end if;

  delete from public.order_realtime_events
   where created_at < now() - interval '1 day';

  return coalesce(NEW, OLD);
end;
$$;


--
-- Name: enforce_unique_ingredient_on_rename(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_unique_ingredient_on_rename() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE
        v_owner_id INT;
        v_dup INT;
      BEGIN
        IF NEW.name_normalized IS NULL OR NEW.name_normalized = '' THEN
          RETURN NEW;
        END IF;
        IF OLD.name_normalized IS NOT NULL AND NEW.name_normalized = OLD.name_normalized THEN
          RETURN NEW;
        END IF;

        SELECT user_id INTO v_owner_id FROM ingredients_fk_user_lnk WHERE ingredient_id = NEW.id LIMIT 1;
        IF v_owner_id IS NULL THEN
          RETURN NEW;
        END IF;

        PERFORM pg_advisory_xact_lock(v_owner_id, hashtext(NEW.name_normalized));

        SELECT COUNT(*) INTO v_dup
        FROM ingredients_fk_user_lnk lnk
        JOIN ingredients i ON i.id = lnk.ingredient_id
        WHERE lnk.user_id = v_owner_id
          AND lnk.ingredient_id <> NEW.id
          AND i.name_normalized = NEW.name_normalized;

        IF v_dup > 0 THEN
          RAISE EXCEPTION 'rename to duplicate name % for user_id=%', NEW.name_normalized, v_owner_id
            USING ERRCODE = 'unique_violation';
        END IF;

        RETURN NEW;
      END;
      $$;


--
-- Name: enforce_unique_ingredient_per_owner(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_unique_ingredient_per_owner() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE
        v_name_norm TEXT;
        v_dup INT;
      BEGIN
        SELECT name_normalized INTO v_name_norm FROM ingredients WHERE id = NEW.ingredient_id;
        IF v_name_norm IS NULL OR v_name_norm = '' THEN
          RETURN NEW;
        END IF;

        PERFORM pg_advisory_xact_lock(NEW.user_id, hashtext(v_name_norm));

        SELECT COUNT(*) INTO v_dup
        FROM ingredients_fk_user_lnk lnk
        JOIN ingredients i ON i.id = lnk.ingredient_id
        WHERE lnk.user_id = NEW.user_id
          AND lnk.ingredient_id <> NEW.ingredient_id
          AND i.name_normalized = v_name_norm;

        IF v_dup > 0 THEN
          RAISE EXCEPTION 'duplicate ingredient name % for user_id=%', v_name_norm, NEW.user_id
            USING ERRCODE = 'unique_violation';
        END IF;

        RETURN NEW;
      END;
      $$;


--
-- Name: enforce_unique_table_number_on_renumber(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_unique_table_number_on_renumber() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE
        v_owner_id INT;
        v_dup INT;
      BEGIN
        IF NEW.number IS NULL THEN
          RETURN NEW;
        END IF;
        IF OLD.number IS NOT DISTINCT FROM NEW.number THEN
          RETURN NEW;
        END IF;

        SELECT user_id INTO v_owner_id FROM tables_fk_user_lnk WHERE table_id = NEW.id LIMIT 1;
        IF v_owner_id IS NULL THEN
          RETURN NEW;
        END IF;

        PERFORM pg_advisory_xact_lock(v_owner_id, NEW.number);

        SELECT COUNT(*) INTO v_dup
        FROM tables_fk_user_lnk lnk
        JOIN tables t ON t.id = lnk.table_id
        WHERE lnk.user_id = v_owner_id
          AND lnk.table_id <> NEW.id
          AND t.number = NEW.number;

        IF v_dup > 0 THEN
          RAISE EXCEPTION 'duplicate table number % for user_id=%', NEW.number, v_owner_id
            USING ERRCODE = 'unique_violation';
        END IF;

        RETURN NEW;
      END;
      $$;


--
-- Name: enforce_unique_table_number_per_owner(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_unique_table_number_per_owner() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE
        v_number INT;
        v_dup INT;
      BEGIN
        SELECT number INTO v_number FROM tables WHERE id = NEW.table_id;
        -- I derivati (merged/split_part) hanno number NULL: fuori dal vincolo.
        IF v_number IS NULL THEN
          RETURN NEW;
        END IF;

        PERFORM pg_advisory_xact_lock(NEW.user_id, v_number);

        SELECT COUNT(*) INTO v_dup
        FROM tables_fk_user_lnk lnk
        JOIN tables t ON t.id = lnk.table_id
        WHERE lnk.user_id = NEW.user_id
          AND lnk.table_id <> NEW.table_id
          AND t.number = v_number;

        IF v_dup > 0 THEN
          RAISE EXCEPTION 'duplicate table number % for user_id=%', v_number, NEW.user_id
            USING ERRCODE = 'unique_violation';
        END IF;

        RETURN NEW;
      END;
      $$;


--
-- Name: ensure_owner_role_link(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_owner_role_link(p_staff_id integer, p_owner_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  if to_regclass('public.up_users_fk_owner_lnk') is not null then
    insert into public.up_users_fk_owner_lnk (user_id, inv_user_id)
    values (p_staff_id, p_owner_id)
    on conflict do nothing;
  end if;
end;
$$;


--
-- Name: ensure_restaurant_category_routing(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ensure_restaurant_category_routing(p_owner_id integer, p_category text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_category text := nullif(btrim(coalesce(p_category, '')), '');
  v_role text;
begin
  if p_owner_id is null or v_category is null then
    return;
  end if;

  v_role := public.classify_staff_role_for_category(v_category);

  insert into public.restaurant_category_routing (owner_id, category, staff_role, locked)
  values (p_owner_id, v_category, v_role, false)
  on conflict (owner_id, category_key) do nothing;
end;
$$;


--
-- Name: is_active_tavolo_subscription(text, timestamp with time zone, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_active_tavolo_subscription(p_status text, p_period_end timestamp with time zone, p_end_subscription date) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  select coalesce(p_status, '') in ('active', 'trialing')
    and case
      when p_period_end is not null then p_period_end >= now()
      when p_end_subscription is not null then p_end_subscription >= current_date
      else true
    end;
$$;


--
-- Name: owner_has_feature(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.owner_has_feature(p_owner_id integer, p_feature_code text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  with owner_row as (
    select *
    from public.up_users u
    where u.id = p_owner_id
      and public.is_active_tavolo_subscription(
        u.subscription_status,
        u.subscription_current_period_end,
        u.end_subscription
      )
  ),
  wanted as (
    select fd.code, fd.professional_enabled
    from public.feature_definitions fd
    where fd.code = p_feature_code
      and fd.status in ('active', 'hidden', 'deprecated')
      and coalesce(fd.system_only, false) = false
  ),
  active_grants as (
    select g.feature_code
    from public.owner_feature_grants g
    join owner_row o on o.id = g.owner_id
    where g.status = 'active'
  )
  select exists (
    select 1
    from wanted w
    where exists (select 1 from active_grants g where g.feature_code = w.code)
       or (
         w.professional_enabled = true
         and exists (select 1 from active_grants g where g.feature_code = 'all.feature')
       )
  );
$$;


--
-- Name: owner_has_production_routing(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.owner_has_production_routing(p_owner_id integer) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  select public.owner_has_feature(p_owner_id, 'production.department_routing');
$$;


--
-- Name: purge_table_order_realtime_events(interval); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.purge_table_order_realtime_events(p_older_than interval DEFAULT '01:00:00'::interval) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_deleted integer;
begin
  delete from public.table_order_realtime_events
  where created_at < now() - p_older_than;
  get diagnostics v_deleted = row_count;
  return v_deleted;
end;
$$;


--
-- Name: route_category_from_element_link(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.route_category_from_element_link() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_category text;
begin
  select category into v_category
  from public.elements
  where id = new.element_id;

  perform public.ensure_restaurant_category_routing(new.user_id, v_category);
  return new;
end;
$$;


--
-- Name: route_category_from_element_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.route_category_from_element_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
  v_owner_id integer;
begin
  if new.category is null or new.category is not distinct from old.category then
    return new;
  end if;

  if to_regclass('public.elements_fk_user_lnk') is not null then
    select user_id into v_owner_id
    from public.elements_fk_user_lnk
    where element_id = new.id
    limit 1;
  end if;

  perform public.ensure_restaurant_category_routing(v_owner_id, new.category);
  return new;
end;
$$;


--
-- Name: set_restaurant_staff_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_restaurant_staff_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  new.updated_at = now();
  return new;
end;
$$;


--
-- Name: staff_username_for_role(integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.staff_username_for_role(p_owner_id integer, p_owner_username text, p_role text) RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
declare
  v_restaurant_name text;
  v_base text;
begin
  if to_regclass('public.website_configs') is not null
     and to_regclass('public.website_configs_fk_user_lnk') is not null then
    select wc.restaurant_name into v_restaurant_name
    from public.website_configs wc
    join public.website_configs_fk_user_lnk lnk on lnk.website_config_id = wc.id
    where lnk.user_id = p_owner_id
    order by wc.id desc
    limit 1;
  end if;

  v_base := regexp_replace(
    initcap(regexp_replace(coalesce(nullif(btrim(v_restaurant_name), ''), nullif(btrim(p_owner_username), ''), 'Ristorante'), '[^[:alnum:]]+', ' ', 'g')),
    '[^[:alnum:]]+',
    '',
    'g'
  );

  return concat(
    v_base,
    '.',
    case p_role
      when 'cucina_sg' then 'cucinasg'
      else p_role
    end
  );
end;
$$;


--
-- Name: sync_owner_staff_accounts(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_owner_staff_accounts(p_owner_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_owner public.up_users%rowtype;
  v_has_subscription boolean;
  v_has_production_routing boolean;
  v_core_staff boolean;
  v_role text;
begin
  select * into v_owner
  from public.up_users
  where id = p_owner_id;

  if not found then
    return;
  end if;

  if coalesce(v_owner.staff_role, 'owner') <> 'owner' then
    return;
  end if;

  v_has_subscription := public.is_active_tavolo_subscription(
    v_owner.subscription_status,
    v_owner.subscription_current_period_end,
    v_owner.end_subscription
  );

  if not v_has_subscription then
    update public.up_users staff
    set blocked = true,
        updated_at = now()
    from public.restaurant_staff rs
    where rs.owner_id = v_owner.id
      and rs.user_id = staff.id;
    return;
  end if;

  v_core_staff := coalesce(v_owner.subscription_plan, '') in ('starter', 'pro', 'custom');
  v_has_production_routing := public.owner_has_feature(v_owner.id, 'production.department_routing');

  perform public.upsert_staff_account(v_owner, 'cameriere', v_core_staff);
  update public.restaurant_staff
  set active = true
  where owner_id = v_owner.id
    and role = 'cameriere';

  perform public.upsert_staff_account(v_owner, 'cucina', v_core_staff);

  update public.up_users staff
  set blocked = not (rs.active and v_core_staff),
      updated_at = now()
  from public.restaurant_staff rs
  where rs.owner_id = v_owner.id
    and rs.role in ('cameriere', 'cucina')
    and rs.user_id = staff.id;

  update public.up_users staff
  set blocked = not (rs.active and v_core_staff),
      updated_at = now()
  from public.restaurant_staff rs
  where rs.owner_id = v_owner.id
    and rs.role = 'gestione'
    and rs.user_id = staff.id;

  if v_has_production_routing then
    perform public.upsert_staff_account(v_owner, 'bar', true);
    perform public.upsert_staff_account(v_owner, 'pizzeria', true);
    perform public.upsert_staff_account(v_owner, 'cucina_sg', true);
  else
    for v_role in select unnest(array['bar', 'pizzeria', 'cucina_sg'])
    loop
      update public.up_users staff
      set blocked = true,
          updated_at = now()
      from public.restaurant_staff rs
      where rs.owner_id = v_owner.id
        and rs.role = v_role
        and rs.user_id = staff.id;
    end loop;
  end if;
end;
$$;


--
-- Name: sync_owner_staff_accounts_trigger(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_owner_staff_accounts_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if coalesce(new.staff_role, 'owner') = 'owner' then
    perform public.sync_owner_staff_accounts(new.id);
  end if;
  return new;
end;
$$;


--
-- Name: synthetic_staff_email(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.synthetic_staff_email(p_owner_id integer, p_role text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  select concat('staff+', p_owner_id::text, '.', replace(p_role, '_', ''), '@staff.local.tavolo');
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: up_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.up_users (
    id integer NOT NULL,
    document_id character varying(255),
    username character varying(255),
    email character varying(255),
    provider character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    confirmation_token character varying(255),
    confirmed boolean,
    blocked boolean,
    name character varying(255),
    surname character varying(255),
    payment_method jsonb,
    stripe_customer_id character varying(255),
    stripe_subscription_id character varying(255),
    subscription_status character varying(255),
    subscription_plan character varying(255),
    subscription_current_period_end timestamp(6) without time zone,
    subscription_cancel_at_period_end boolean,
    end_subscription date,
    birth_date date,
    url character varying(255),
    staff_role character varying(255),
    two_factor_secret character varying(255),
    two_factor_enabled boolean,
    two_factor_recovery_codes jsonb,
    unavailable_ingredients jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    feature_grants_version integer DEFAULT 0 NOT NULL,
    staff_access_email_sent_at timestamp(6) without time zone,
    staff_access_email_sent_plan character varying(255),
    signup_restaurant_name character varying(255),
    signup_coperti_invernali integer,
    signup_coperti_estivi integer,
    two_factor_method character varying(255),
    two_factor_email_code_hash character varying(255),
    two_factor_email_code_expires_at timestamp(6) without time zone,
    two_factor_email_last_sent_at timestamp(6) without time zone,
    address character varying(255),
    city character varying(255),
    cap character varying(255),
    province character varying(255),
    vat character varying(255),
    stripe_connect_account_id character varying(255),
    stripe_connect_charges_enabled boolean,
    stripe_connect_details_submitted boolean,
    stripe_connect_card_payments_status character varying(255),
    stripe_terminal_location_id character varying(255),
    stripe_connect_status_checked_at timestamp(6) without time zone
);


--
-- Name: upsert_staff_account(public.up_users, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.upsert_staff_account(p_owner public.up_users, p_role text, p_enabled boolean) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
  v_staff_id integer;
  v_username text;
  v_email text;
  v_active boolean;
begin
  v_username := public.staff_username_for_role(p_owner.id, p_owner.username, p_role);
  v_email := public.synthetic_staff_email(p_owner.id, p_role);

  select user_id into v_staff_id
  from public.restaurant_staff
  where owner_id = p_owner.id
    and role = p_role
  limit 1;

  if v_staff_id is null then
    select id into v_staff_id
    from public.up_users
    where username = v_username
    limit 1;
  end if;

  if v_staff_id is null then
    insert into public.up_users (
      document_id,
      username,
      email,
      provider,
      password,
      confirmed,
      blocked,
      name,
      surname,
      staff_role,
      created_at,
      updated_at
    )
    values (
      replace(gen_random_uuid()::text, '-', ''),
      v_username,
      v_email,
      'local',
      p_owner.password,
      true,
      not p_enabled,
      coalesce(nullif(p_owner.name, ''), v_username),
      coalesce(nullif(p_owner.surname, ''), p_role),
      p_role,
      now(),
      now()
    )
    returning id into v_staff_id;
  else
    update public.up_users
    set
      username = case
        when not exists (
          select 1
          from public.up_users existing
          where existing.username = v_username
            and existing.id <> v_staff_id
        ) then v_username
        else username
      end,
      email = coalesce(nullif(email, ''), v_email),
      provider = coalesce(provider, 'local'),
      password = p_owner.password,
      confirmed = true,
      blocked = not p_enabled,
      staff_role = p_role,
      stripe_customer_id = null,
      stripe_subscription_id = null,
      subscription_status = null,
      subscription_plan = null,
      subscription_current_period_end = null,
      subscription_cancel_at_period_end = false,
      end_subscription = null,
      updated_at = now()
    where id = v_staff_id;
  end if;

  perform public.ensure_owner_role_link(v_staff_id, p_owner.id);
  perform public.copy_owner_auth_role_link(v_staff_id, p_owner.id);

  insert into public.restaurant_staff (owner_id, user_id, role, active, display_name)
  values (p_owner.id, v_staff_id, p_role, true, v_username)
  on conflict (owner_id, user_id) do update
  set role = excluded.role,
      display_name = excluded.display_name;

  update public.restaurant_staff
  set active = false
  where owner_id = p_owner.id
    and role = p_role
    and user_id <> v_staff_id;

  select active into v_active
  from public.restaurant_staff
  where owner_id = p_owner.id
    and user_id = v_staff_id
  limit 1;

  update public.up_users
  set blocked = not (coalesce(v_active, true) and p_enabled),
      updated_at = now()
  where id = v_staff_id;

  return v_staff_id;
end;
$$;


--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    action_parameters jsonb,
    subject character varying(255),
    properties jsonb,
    conditions jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: admin_permissions_api_token_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_permissions_api_token_lnk (
    id integer NOT NULL,
    permission_id integer,
    api_token_id integer,
    permission_ord double precision
);


--
-- Name: admin_permissions_api_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_permissions_api_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_permissions_api_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_permissions_api_token_lnk_id_seq OWNED BY public.admin_permissions_api_token_lnk.id;


--
-- Name: admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_permissions_id_seq OWNED BY public.admin_permissions.id;


--
-- Name: admin_permissions_role_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNED BY public.admin_permissions_role_lnk.id;


--
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    description character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_roles_id_seq OWNED BY public.admin_roles.id;


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    document_id character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    username character varying(255),
    email character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    registration_token character varying(255),
    is_active boolean,
    blocked boolean,
    prefered_language character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: admin_users_roles_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_users_roles_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    role_ord double precision,
    user_ord double precision
);


--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_users_roles_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNED BY public.admin_users_roles_lnk.id;


--
-- Name: audit_hardware_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_hardware_events (
    id integer NOT NULL,
    document_id character varying(255),
    "timestamp" timestamp(6) without time zone,
    kind character varying(255),
    actor jsonb,
    entity_type character varying(255),
    entity_id character varying(255),
    payload_hash character varying(255),
    details jsonb,
    reason text,
    prev_hash character varying(255),
    chain_hash character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: audit_hardware_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_hardware_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_hardware_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_hardware_events_id_seq OWNED BY public.audit_hardware_events.id;


--
-- Name: bar_shifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bar_shifts (
    id integer NOT NULL,
    document_id character varying(255),
    status character varying(255),
    opened_at timestamp(6) without time zone,
    closed_at timestamp(6) without time zone,
    note text,
    snapshot jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: bar_shifts_closed_by_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bar_shifts_closed_by_lnk (
    id integer NOT NULL,
    bar_shift_id integer,
    user_id integer
);


--
-- Name: bar_shifts_closed_by_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bar_shifts_closed_by_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bar_shifts_closed_by_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bar_shifts_closed_by_lnk_id_seq OWNED BY public.bar_shifts_closed_by_lnk.id;


--
-- Name: bar_shifts_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bar_shifts_fk_user_lnk (
    id integer NOT NULL,
    bar_shift_id integer,
    user_id integer
);


--
-- Name: bar_shifts_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bar_shifts_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bar_shifts_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bar_shifts_fk_user_lnk_id_seq OWNED BY public.bar_shifts_fk_user_lnk.id;


--
-- Name: bar_shifts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bar_shifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bar_shifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bar_shifts_id_seq OWNED BY public.bar_shifts.id;


--
-- Name: bar_shifts_opened_by_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bar_shifts_opened_by_lnk (
    id integer NOT NULL,
    bar_shift_id integer,
    user_id integer
);


--
-- Name: bar_shifts_opened_by_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bar_shifts_opened_by_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bar_shifts_opened_by_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bar_shifts_opened_by_lnk_id_seq OWNED BY public.bar_shifts_opened_by_lnk.id;


--
-- Name: checkout_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checkout_attempts (
    id integer NOT NULL,
    document_id character varying(255),
    event_id character varying(255),
    snapshot_json jsonb,
    snapshot_hash character varying(255),
    schema_version integer,
    total_amount numeric(10,2),
    currency character varying(255),
    vat_breakdown jsonb,
    payment_method character varying(255),
    status character varying(255),
    created_by_user character varying(255),
    device_id character varying(255),
    app_shell character varying(255),
    lock_version integer,
    finalized_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    expires_at timestamp(6) without time zone,
    expired_at timestamp(6) without time zone
);


--
-- Name: checkout_attempts_fk_order_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checkout_attempts_fk_order_lnk (
    id integer NOT NULL,
    checkout_attempt_id integer,
    order_id integer
);


--
-- Name: checkout_attempts_fk_order_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.checkout_attempts_fk_order_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: checkout_attempts_fk_order_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.checkout_attempts_fk_order_lnk_id_seq OWNED BY public.checkout_attempts_fk_order_lnk.id;


--
-- Name: checkout_attempts_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checkout_attempts_fk_user_lnk (
    id integer NOT NULL,
    checkout_attempt_id integer,
    user_id integer
);


--
-- Name: checkout_attempts_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.checkout_attempts_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: checkout_attempts_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.checkout_attempts_fk_user_lnk_id_seq OWNED BY public.checkout_attempts_fk_user_lnk.id;


--
-- Name: checkout_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.checkout_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: checkout_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.checkout_attempts_id_seq OWNED BY public.checkout_attempts.id;


--
-- Name: ct_idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ct_idempotency_keys (
    id integer NOT NULL,
    scope character varying(64) NOT NULL,
    key character varying(191) NOT NULL,
    fingerprint character varying(64),
    response_status integer,
    response_body text,
    expires_at bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    state character varying(24),
    claim_token character varying(64),
    claimed_at bigint
);


--
-- Name: ct_idempotency_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ct_idempotency_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ct_idempotency_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ct_idempotency_keys_id_seq OWNED BY public.ct_idempotency_keys.id;


--
-- Name: customer_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_messages (
    id integer NOT NULL,
    document_id character varying(255),
    event_key character varying(255),
    message_type character varying(255),
    recipient_email character varying(255),
    template_payload jsonb,
    status character varying(255),
    attempts integer,
    max_attempts integer,
    next_attempt_at timestamp(6) without time zone,
    claim_token character varying(255),
    claimed_at timestamp(6) without time zone,
    sent_at timestamp(6) without time zone,
    provider_message_id character varying(255),
    last_error_code character varying(255),
    last_error_message text,
    manual_resend_count integer,
    owner_id integer,
    order_document_id character varying(255),
    proposal_document_id character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: customer_messages_fk_order_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_messages_fk_order_lnk (
    id integer NOT NULL,
    customer_message_id integer,
    order_id integer
);


--
-- Name: customer_messages_fk_order_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_messages_fk_order_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_messages_fk_order_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_messages_fk_order_lnk_id_seq OWNED BY public.customer_messages_fk_order_lnk.id;


--
-- Name: customer_messages_fk_time_proposal_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_messages_fk_time_proposal_lnk (
    id integer NOT NULL,
    customer_message_id integer,
    takeaway_time_proposal_id integer
);


--
-- Name: customer_messages_fk_time_proposal_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_messages_fk_time_proposal_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_messages_fk_time_proposal_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_messages_fk_time_proposal_lnk_id_seq OWNED BY public.customer_messages_fk_time_proposal_lnk.id;


--
-- Name: customer_messages_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_messages_fk_user_lnk (
    id integer NOT NULL,
    customer_message_id integer,
    user_id integer
);


--
-- Name: customer_messages_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_messages_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_messages_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_messages_fk_user_lnk_id_seq OWNED BY public.customer_messages_fk_user_lnk.id;


--
-- Name: customer_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_messages_id_seq OWNED BY public.customer_messages.id;


--
-- Name: element_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.element_ingredients (
    id integer NOT NULL,
    document_id character varying(255),
    qty_per_serving numeric(10,2),
    unit_override character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    is_public boolean,
    table_order_public_id character varying(36)
);


--
-- Name: element_ingredients_fk_element_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.element_ingredients_fk_element_lnk (
    id integer NOT NULL,
    element_ingredient_id integer,
    element_id integer,
    element_ingredient_ord double precision
);


--
-- Name: element_ingredients_fk_element_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.element_ingredients_fk_element_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: element_ingredients_fk_element_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.element_ingredients_fk_element_lnk_id_seq OWNED BY public.element_ingredients_fk_element_lnk.id;


--
-- Name: element_ingredients_fk_ingredient_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.element_ingredients_fk_ingredient_lnk (
    id integer NOT NULL,
    element_ingredient_id integer,
    ingredient_id integer,
    element_ingredient_ord double precision
);


--
-- Name: element_ingredients_fk_ingredient_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.element_ingredients_fk_ingredient_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: element_ingredients_fk_ingredient_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.element_ingredients_fk_ingredient_lnk_id_seq OWNED BY public.element_ingredients_fk_ingredient_lnk.id;


--
-- Name: element_ingredients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.element_ingredients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: element_ingredients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.element_ingredients_id_seq OWNED BY public.element_ingredients.id;


--
-- Name: elements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elements (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    price numeric(10,2),
    category character varying(255),
    allergens jsonb,
    available boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    is_beverage boolean,
    is_beverage_advanced boolean,
    is_archived boolean,
    table_order_public_id character varying(36)
);


--
-- Name: elements_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elements_fk_user_lnk (
    id integer NOT NULL,
    element_id integer,
    user_id integer
);


--
-- Name: elements_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.elements_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: elements_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.elements_fk_user_lnk_id_seq OWNED BY public.elements_fk_user_lnk.id;


--
-- Name: elements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.elements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: elements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.elements_id_seq OWNED BY public.elements.id;


--
-- Name: feature_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_definitions (
    id integer NOT NULL,
    code character varying(160) NOT NULL,
    title_it character varying(255) NOT NULL,
    description_it text,
    area character varying(80) NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    custom_selectable boolean DEFAULT false NOT NULL,
    professional_enabled boolean DEFAULT false NOT NULL,
    system_only boolean DEFAULT false NOT NULL,
    requires json DEFAULT '[]'::json NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    metadata json DEFAULT '{}'::json NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: feature_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feature_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feature_definitions_id_seq OWNED BY public.feature_definitions.id;


--
-- Name: feature_rollout_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_rollout_events (
    id integer NOT NULL,
    feature_code character varying(128) NOT NULL,
    owner_id integer,
    change_type character varying(32) NOT NULL,
    previous_value character varying(64),
    next_value character varying(64),
    previous_version integer,
    next_version integer,
    actor character varying(128),
    reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: feature_rollout_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feature_rollout_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_rollout_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feature_rollout_events_id_seq OWNED BY public.feature_rollout_events.id;


--
-- Name: feature_rollout_owners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_rollout_owners (
    id integer NOT NULL,
    feature_code character varying(128) NOT NULL,
    owner_id integer NOT NULL,
    status character varying(32) DEFAULT 'pilot_enabled'::character varying NOT NULL,
    changed_by integer,
    changed_at timestamp with time zone,
    reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: feature_rollout_owners_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feature_rollout_owners_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_rollout_owners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feature_rollout_owners_id_seq OWNED BY public.feature_rollout_owners.id;


--
-- Name: feature_rollouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_rollouts (
    id integer NOT NULL,
    feature_code character varying(128) NOT NULL,
    mode character varying(32) DEFAULT 'disabled'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    changed_by integer,
    changed_at timestamp with time zone,
    reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: feature_rollouts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feature_rollouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_rollouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feature_rollouts_id_seq OWNED BY public.feature_rollouts.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.files (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    alternative_text text,
    caption text,
    focal_point jsonb,
    width integer,
    height integer,
    formats jsonb,
    hash character varying(255),
    ext character varying(255),
    mime character varying(255),
    size numeric(10,2),
    url text,
    preview_url text,
    provider character varying(255),
    provider_metadata jsonb,
    folder_path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: files_folder_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.files_folder_lnk (
    id integer NOT NULL,
    file_id integer,
    folder_id integer,
    file_ord double precision
);


--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.files_folder_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.files_folder_lnk_id_seq OWNED BY public.files_folder_lnk.id;


--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: files_related_mph; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.files_related_mph (
    id integer NOT NULL,
    file_id integer,
    related_id integer,
    related_type character varying(255),
    field character varying(255),
    "order" double precision
);


--
-- Name: files_related_mph_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.files_related_mph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: files_related_mph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.files_related_mph_id_seq OWNED BY public.files_related_mph.id;


--
-- Name: fiscal_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_attempts (
    id integer NOT NULL,
    document_id character varying(255),
    event_id character varying(255),
    fiscal_event_id character varying(255),
    adapter_family character varying(255),
    vendor character varying(255),
    model character varying(255),
    firmware character varying(255),
    matricola character varying(255),
    payment_mode_rt character varying(255),
    status character varying(255),
    document_number character varying(255),
    closure_number character varying(255),
    document_date_time timestamp(6) without time zone,
    rt_response_code character varying(255),
    rt_response_message text,
    raw_request_hash character varying(255),
    raw_response_hash character varying(255),
    retry_count integer,
    next_retry_at timestamp(6) without time zone,
    requires_manual_action boolean,
    manual_action_code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_attempts_fk_checkout_attempt_lnk (
    id integer NOT NULL,
    fiscal_attempt_id integer,
    checkout_attempt_id integer
);


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_attempts_fk_checkout_attempt_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_attempts_fk_checkout_attempt_lnk_id_seq OWNED BY public.fiscal_attempts_fk_checkout_attempt_lnk.id;


--
-- Name: fiscal_attempts_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_attempts_fk_user_lnk (
    id integer NOT NULL,
    fiscal_attempt_id integer,
    user_id integer
);


--
-- Name: fiscal_attempts_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_attempts_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_attempts_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_attempts_fk_user_lnk_id_seq OWNED BY public.fiscal_attempts_fk_user_lnk.id;


--
-- Name: fiscal_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_attempts_id_seq OWNED BY public.fiscal_attempts.id;


--
-- Name: fiscal_correction_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_correction_attempts (
    id integer NOT NULL,
    document_id character varying(255),
    event_id character varying(255),
    correction_type character varying(255),
    adapter_family character varying(255),
    vendor character varying(255),
    model character varying(255),
    firmware character varying(255),
    matricola character varying(255),
    status character varying(255),
    original_matricola character varying(255),
    original_document_number character varying(255),
    original_closure_number character varying(255),
    original_document_date date,
    original_vat_lines jsonb,
    reason text,
    amount numeric(10,2),
    document_number character varying(255),
    closure_number character varying(255),
    document_date_time timestamp(6) without time zone,
    rt_response_code character varying(255),
    rt_response_message text,
    raw_request_hash character varying(255),
    raw_response_hash character varying(255),
    requires_manual_action boolean,
    manual_action_code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_correction_attempts_fk_checkout_attempt_lnk (
    id integer NOT NULL,
    fiscal_correction_attempt_id integer,
    checkout_attempt_id integer
);


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_correction_attempts_fk_checkout_attempt_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_correction_attempts_fk_checkout_attempt_lnk_id_seq OWNED BY public.fiscal_correction_attempts_fk_checkout_attempt_lnk.id;


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_correction_attempts_fk_fiscal_attempt_lnk (
    id integer NOT NULL,
    fiscal_correction_attempt_id integer,
    fiscal_attempt_id integer
);


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_correction_attempts_fk_fiscal_attempt_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_correction_attempts_fk_fiscal_attempt_lnk_id_seq OWNED BY public.fiscal_correction_attempts_fk_fiscal_attempt_lnk.id;


--
-- Name: fiscal_correction_attempts_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_correction_attempts_fk_user_lnk (
    id integer NOT NULL,
    fiscal_correction_attempt_id integer,
    user_id integer
);


--
-- Name: fiscal_correction_attempts_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_correction_attempts_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_correction_attempts_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_correction_attempts_fk_user_lnk_id_seq OWNED BY public.fiscal_correction_attempts_fk_user_lnk.id;


--
-- Name: fiscal_correction_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_correction_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_correction_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_correction_attempts_id_seq OWNED BY public.fiscal_correction_attempts.id;


--
-- Name: hardware_endpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hardware_endpoints (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    endpoint_type character varying(255),
    provider character varying(255),
    integration_mode character varying(255),
    model character varying(255),
    firmware character varying(255),
    serial character varying(255),
    connection_config jsonb,
    capabilities jsonb,
    status character varying(255),
    last_seen timestamp(6) without time zone,
    last_test_result jsonb,
    evidence_source character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: hardware_endpoints_fk_pos_device_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hardware_endpoints_fk_pos_device_lnk (
    id integer NOT NULL,
    hardware_endpoint_id integer,
    pos_device_id integer
);


--
-- Name: hardware_endpoints_fk_pos_device_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hardware_endpoints_fk_pos_device_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hardware_endpoints_fk_pos_device_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hardware_endpoints_fk_pos_device_lnk_id_seq OWNED BY public.hardware_endpoints_fk_pos_device_lnk.id;


--
-- Name: hardware_endpoints_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hardware_endpoints_fk_user_lnk (
    id integer NOT NULL,
    hardware_endpoint_id integer,
    user_id integer
);


--
-- Name: hardware_endpoints_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hardware_endpoints_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hardware_endpoints_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hardware_endpoints_fk_user_lnk_id_seq OWNED BY public.hardware_endpoints_fk_user_lnk.id;


--
-- Name: hardware_endpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hardware_endpoints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hardware_endpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hardware_endpoints_id_seq OWNED BY public.hardware_endpoints.id;


--
-- Name: hardware_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hardware_jobs (
    id integer NOT NULL,
    document_id character varying(255),
    event_id character varying(255),
    kind character varying(255),
    payload jsonb,
    payload_hash character varying(255),
    signature character varying(255),
    status character varying(255),
    priority integer,
    outcome jsonb,
    outcome_hash character varying(255),
    error_code character varying(255),
    error_category character varying(255),
    error_message text,
    retry_count integer,
    max_retries integer,
    next_retry_at timestamp(6) without time zone,
    dispatched_at timestamp(6) without time zone,
    in_progress_at timestamp(6) without time zone,
    acked_at timestamp(6) without time zone,
    dead_letter_at timestamp(6) without time zone,
    dead_letter_reason text,
    correlation_id character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hardware_jobs_fk_checkout_attempt_lnk (
    id integer NOT NULL,
    hardware_job_id integer,
    checkout_attempt_id integer
);


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hardware_jobs_fk_checkout_attempt_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hardware_jobs_fk_checkout_attempt_lnk_id_seq OWNED BY public.hardware_jobs_fk_checkout_attempt_lnk.id;


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hardware_jobs_fk_hardware_endpoint_lnk (
    id integer NOT NULL,
    hardware_job_id integer,
    hardware_endpoint_id integer
);


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hardware_jobs_fk_hardware_endpoint_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hardware_jobs_fk_hardware_endpoint_lnk_id_seq OWNED BY public.hardware_jobs_fk_hardware_endpoint_lnk.id;


--
-- Name: hardware_jobs_fk_pos_device_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hardware_jobs_fk_pos_device_lnk (
    id integer NOT NULL,
    hardware_job_id integer,
    pos_device_id integer
);


--
-- Name: hardware_jobs_fk_pos_device_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hardware_jobs_fk_pos_device_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hardware_jobs_fk_pos_device_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hardware_jobs_fk_pos_device_lnk_id_seq OWNED BY public.hardware_jobs_fk_pos_device_lnk.id;


--
-- Name: hardware_jobs_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hardware_jobs_fk_user_lnk (
    id integer NOT NULL,
    hardware_job_id integer,
    user_id integer
);


--
-- Name: hardware_jobs_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hardware_jobs_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hardware_jobs_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hardware_jobs_fk_user_lnk_id_seq OWNED BY public.hardware_jobs_fk_user_lnk.id;


--
-- Name: hardware_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hardware_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hardware_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hardware_jobs_id_seq OWNED BY public.hardware_jobs.id;


--
-- Name: i18n_locale; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.i18n_locale (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: i18n_locale_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.i18n_locale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: i18n_locale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.i18n_locale_id_seq OWNED BY public.i18n_locale.id;


--
-- Name: ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredients (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    name_normalized character varying(255),
    unit character varying(255),
    unit_size numeric(10,2),
    stock_qty numeric(10,2),
    low_stock_threshold numeric(10,2),
    reorder_lead_days numeric(10,2),
    is_unavailable boolean,
    is_active boolean,
    is_addon boolean,
    addon_price numeric(10,2),
    addon_avg_qty numeric(10,2),
    supplier_name character varying(255),
    supplier_email character varying(255),
    notes text,
    allergens jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    unit_label character varying(40),
    unit_cost double precision,
    table_order_public_id character varying(36)
);


--
-- Name: ingredients_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingredients_fk_user_lnk (
    id integer NOT NULL,
    ingredient_id integer,
    user_id integer
);


--
-- Name: ingredients_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ingredients_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ingredients_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ingredients_fk_user_lnk_id_seq OWNED BY public.ingredients_fk_user_lnk.id;


--
-- Name: ingredients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ingredients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ingredients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ingredients_id_seq OWNED BY public.ingredients.id;


--
-- Name: inventory_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_alerts (
    id integer NOT NULL,
    document_id character varying(255),
    alert_type character varying(255),
    level character varying(255),
    ingredients_payload jsonb,
    sent_email boolean,
    sent_inapp boolean,
    acknowledged_at timestamp(6) without time zone,
    dismissed_by_restock boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: inventory_alerts_acknowledged_by_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_alerts_acknowledged_by_lnk (
    id integer NOT NULL,
    inventory_alert_id integer,
    user_id integer
);


--
-- Name: inventory_alerts_acknowledged_by_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_alerts_acknowledged_by_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_alerts_acknowledged_by_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_alerts_acknowledged_by_lnk_id_seq OWNED BY public.inventory_alerts_acknowledged_by_lnk.id;


--
-- Name: inventory_alerts_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_alerts_fk_user_lnk (
    id integer NOT NULL,
    inventory_alert_id integer,
    user_id integer
);


--
-- Name: inventory_alerts_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_alerts_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_alerts_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_alerts_fk_user_lnk_id_seq OWNED BY public.inventory_alerts_fk_user_lnk.id;


--
-- Name: inventory_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_alerts_id_seq OWNED BY public.inventory_alerts.id;


--
-- Name: inventory_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements (
    id integer NOT NULL,
    document_id character varying(255),
    kind character varying(255),
    qty_delta numeric(10,2),
    qty_after numeric(10,2),
    cost numeric(10,2),
    reason character varying(255),
    note text,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    supplier character varying(255),
    batch_id character varying(255)
);


--
-- Name: inventory_movements_fk_bar_shift_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements_fk_bar_shift_lnk (
    id integer NOT NULL,
    inventory_movement_id integer,
    bar_shift_id integer
);


--
-- Name: inventory_movements_fk_bar_shift_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_fk_bar_shift_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_fk_bar_shift_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_fk_bar_shift_lnk_id_seq OWNED BY public.inventory_movements_fk_bar_shift_lnk.id;


--
-- Name: inventory_movements_fk_ingredient_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements_fk_ingredient_lnk (
    id integer NOT NULL,
    inventory_movement_id integer,
    ingredient_id integer
);


--
-- Name: inventory_movements_fk_ingredient_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_fk_ingredient_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_fk_ingredient_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_fk_ingredient_lnk_id_seq OWNED BY public.inventory_movements_fk_ingredient_lnk.id;


--
-- Name: inventory_movements_fk_order_item_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements_fk_order_item_lnk (
    id integer NOT NULL,
    inventory_movement_id integer,
    order_item_id integer
);


--
-- Name: inventory_movements_fk_order_item_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_fk_order_item_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_fk_order_item_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_fk_order_item_lnk_id_seq OWNED BY public.inventory_movements_fk_order_item_lnk.id;


--
-- Name: inventory_movements_fk_order_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements_fk_order_lnk (
    id integer NOT NULL,
    inventory_movement_id integer,
    order_id integer
);


--
-- Name: inventory_movements_fk_order_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_fk_order_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_fk_order_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_fk_order_lnk_id_seq OWNED BY public.inventory_movements_fk_order_lnk.id;


--
-- Name: inventory_movements_fk_restock_order_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements_fk_restock_order_lnk (
    id integer NOT NULL,
    inventory_movement_id integer,
    restock_order_id integer
);


--
-- Name: inventory_movements_fk_restock_order_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_fk_restock_order_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_fk_restock_order_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_fk_restock_order_lnk_id_seq OWNED BY public.inventory_movements_fk_restock_order_lnk.id;


--
-- Name: inventory_movements_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements_fk_user_lnk (
    id integer NOT NULL,
    inventory_movement_id integer,
    user_id integer
);


--
-- Name: inventory_movements_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_fk_user_lnk_id_seq OWNED BY public.inventory_movements_fk_user_lnk.id;


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_movements_id_seq OWNED BY public.inventory_movements.id;


--
-- Name: menu_element_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_element_stats (
    id integer NOT NULL,
    document_id character varying(255),
    element_name_snapshot character varying(255),
    total_ordered integer,
    total_revenue numeric(10,2),
    first_ordered_at timestamp(6) without time zone,
    last_ordered_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: menu_element_stats_fk_element_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_element_stats_fk_element_lnk (
    id integer NOT NULL,
    menu_element_stat_id integer,
    element_id integer
);


--
-- Name: menu_element_stats_fk_element_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_element_stats_fk_element_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_element_stats_fk_element_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_element_stats_fk_element_lnk_id_seq OWNED BY public.menu_element_stats_fk_element_lnk.id;


--
-- Name: menu_element_stats_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_element_stats_fk_user_lnk (
    id integer NOT NULL,
    menu_element_stat_id integer,
    user_id integer
);


--
-- Name: menu_element_stats_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_element_stats_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_element_stats_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_element_stats_fk_user_lnk_id_seq OWNED BY public.menu_element_stats_fk_user_lnk.id;


--
-- Name: menu_element_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_element_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_element_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_element_stats_id_seq OWNED BY public.menu_element_stats.id;


--
-- Name: menu_import_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_import_jobs (
    id integer NOT NULL,
    document_id character varying(255),
    status character varying(255),
    owner_id integer,
    requested_by_id integer,
    idempotency_key character varying(255),
    file_hash character varying(255),
    pipeline_revision character varying(255),
    original_filename character varying(255),
    mime_type character varying(255),
    file_size bigint,
    source_path text,
    restaurant_context jsonb,
    result_payload jsonb,
    draft_payload jsonb,
    quality jsonb,
    element_reviews jsonb,
    warnings jsonb,
    ocr_confidence numeric(10,2),
    attempts integer,
    max_attempts integer,
    next_attempt_at timestamp(6) without time zone,
    claim_token character varying(255),
    claimed_at timestamp(6) without time zone,
    lease_expires_at timestamp(6) without time zone,
    cancellation_requested boolean,
    started_at timestamp(6) without time zone,
    completed_at timestamp(6) without time zone,
    confirmed_at timestamp(6) without time zone,
    cancelled_at timestamp(6) without time zone,
    source_deleted_at timestamp(6) without time zone,
    last_error_code character varying(255),
    last_error_message text,
    draft_version integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: menu_import_jobs_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_import_jobs_fk_user_lnk (
    id integer NOT NULL,
    menu_import_job_id integer,
    user_id integer
);


--
-- Name: menu_import_jobs_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_import_jobs_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_import_jobs_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_import_jobs_fk_user_lnk_id_seq OWNED BY public.menu_import_jobs_fk_user_lnk.id;


--
-- Name: menu_import_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_import_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_import_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_import_jobs_id_seq OWNED BY public.menu_import_jobs.id;


--
-- Name: menu_import_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_import_leases (
    id integer NOT NULL,
    document_id character varying(255),
    lane character varying(255),
    holder_token character varying(255),
    lease_expires_at timestamp(6) without time zone,
    heartbeat_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: menu_import_leases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_import_leases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_import_leases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_import_leases_id_seq OWNED BY public.menu_import_leases.id;


--
-- Name: menus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menus (
    id integer NOT NULL,
    document_id character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: menus_fk_elements_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menus_fk_elements_lnk (
    id integer NOT NULL,
    menu_id integer,
    element_id integer,
    element_ord double precision
);


--
-- Name: menus_fk_elements_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menus_fk_elements_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menus_fk_elements_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menus_fk_elements_lnk_id_seq OWNED BY public.menus_fk_elements_lnk.id;


--
-- Name: menus_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menus_fk_user_lnk (
    id integer NOT NULL,
    menu_id integer,
    user_id integer
);


--
-- Name: menus_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menus_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menus_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menus_fk_user_lnk_id_seq OWNED BY public.menus_fk_user_lnk.id;


--
-- Name: menus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menus_id_seq OWNED BY public.menus.id;


--
-- Name: order_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_archives (
    id integer NOT NULL,
    document_id character varying(255),
    order_document_id character varying(255),
    reservation_document_id character varying(255),
    opened_at timestamp(6) without time zone,
    closed_at timestamp(6) without time zone,
    duration_minutes integer,
    customer_name character varying(255),
    covers integer,
    is_walkin boolean,
    table_number integer,
    table_area character varying(255),
    total_amount numeric(10,2),
    payment_method character varying(255),
    payment_reference character varying(255),
    items_json jsonb,
    items_count integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    service_type character varying(255),
    customer_phone character varying(255),
    customer_email character varying(255),
    pickup_at timestamp(6) without time zone,
    table_label character varying(255)
);


--
-- Name: order_archives_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_archives_fk_user_lnk (
    id integer NOT NULL,
    order_archive_id integer,
    user_id integer
);


--
-- Name: order_archives_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_archives_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_archives_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_archives_fk_user_lnk_id_seq OWNED BY public.order_archives_fk_user_lnk.id;


--
-- Name: order_archives_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_archives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_archives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_archives_id_seq OWNED BY public.order_archives.id;


--
-- Name: order_item_addons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_item_addons (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    price numeric(10,2),
    qty_used numeric(10,2),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: order_item_addons_fk_ingredient_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_item_addons_fk_ingredient_lnk (
    id integer NOT NULL,
    order_item_addon_id integer,
    ingredient_id integer
);


--
-- Name: order_item_addons_fk_ingredient_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_item_addons_fk_ingredient_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_item_addons_fk_ingredient_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_item_addons_fk_ingredient_lnk_id_seq OWNED BY public.order_item_addons_fk_ingredient_lnk.id;


--
-- Name: order_item_addons_fk_order_item_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_item_addons_fk_order_item_lnk (
    id integer NOT NULL,
    order_item_addon_id integer,
    order_item_id integer,
    order_item_addon_ord double precision
);


--
-- Name: order_item_addons_fk_order_item_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_item_addons_fk_order_item_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_item_addons_fk_order_item_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_item_addons_fk_order_item_lnk_id_seq OWNED BY public.order_item_addons_fk_order_item_lnk.id;


--
-- Name: order_item_addons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_item_addons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_item_addons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_item_addons_id_seq OWNED BY public.order_item_addons.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    price numeric(10,2),
    quantity integer,
    notes text,
    status character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    category character varying(255),
    course integer,
    voided boolean,
    voided_reason text,
    voided_at timestamp(6) without time zone,
    served_at timestamp(6) without time zone,
    removed_ingredients jsonb,
    client_item_id character varying(255),
    source character varying(32) DEFAULT 'staff'::character varying NOT NULL,
    table_order_participant_id integer,
    table_order_item_revision integer DEFAULT 1 NOT NULL,
    table_order_public_id character varying(64) DEFAULT (gen_random_uuid())::text NOT NULL,
    customer_notes text,
    table_order_sent_at timestamp with time zone
);


--
-- Name: order_items_fk_element_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items_fk_element_lnk (
    id integer NOT NULL,
    order_item_id integer,
    element_id integer
);


--
-- Name: order_items_fk_element_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_fk_element_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_fk_element_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_fk_element_lnk_id_seq OWNED BY public.order_items_fk_element_lnk.id;


--
-- Name: order_items_fk_order_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items_fk_order_lnk (
    id integer NOT NULL,
    order_item_id integer,
    order_id integer,
    order_item_ord double precision
);


--
-- Name: order_items_fk_order_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_fk_order_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_fk_order_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_fk_order_lnk_id_seq OWNED BY public.order_items_fk_order_lnk.id;


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: order_realtime_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_realtime_events (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    source_table text NOT NULL,
    source_id integer,
    event_type text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: order_realtime_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_realtime_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_realtime_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_realtime_events_id_seq OWNED BY public.order_realtime_events.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    document_id character varying(255),
    status character varying(255),
    opened_at timestamp(6) without time zone,
    closed_at timestamp(6) without time zone,
    total_amount numeric(10,2),
    payment_status character varying(255),
    payment_reference character varying(255),
    fiscal_status character varying(255),
    fiscal_receipt_id character varying(255),
    fiscal_event_id character varying(255),
    lock_version integer,
    covers integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    service_type character varying(255),
    takeaway_status character varying(255),
    customer_name character varying(255),
    customer_phone character varying(255),
    customer_email character varying(255),
    pickup_at timestamp(6) without time zone,
    sent_to_departments_at timestamp(6) without time zone,
    ready_at timestamp(6) without time zone,
    picked_up_at timestamp(6) without time zone,
    client_order_id character varying(255),
    takeaway_source character varying(32),
    requested_pickup_at timestamp with time zone,
    kitchen_lead_minutes integer,
    kitchen_release_at timestamp with time zone,
    confirmed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    cancellation_reason character varying(64),
    takeaway_idempotency_key_hash character varying(64),
    takeaway_request_fingerprint character varying(64)
);


--
-- Name: orders_fk_table_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders_fk_table_lnk (
    id integer NOT NULL,
    order_id integer,
    table_id integer
);


--
-- Name: orders_fk_table_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_fk_table_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_fk_table_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_fk_table_lnk_id_seq OWNED BY public.orders_fk_table_lnk.id;


--
-- Name: orders_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders_fk_user_lnk (
    id integer NOT NULL,
    order_id integer,
    user_id integer
);


--
-- Name: orders_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_fk_user_lnk_id_seq OWNED BY public.orders_fk_user_lnk.id;


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: owner_feature_grant_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.owner_feature_grant_events (
    id integer NOT NULL,
    owner_id integer NOT NULL,
    previous_plan character varying(32),
    next_plan character varying(32),
    previous_grants json DEFAULT '[]'::json NOT NULL,
    next_grants json DEFAULT '[]'::json NOT NULL,
    reason character varying(160),
    actor_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: owner_feature_grant_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.owner_feature_grant_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: owner_feature_grant_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.owner_feature_grant_events_id_seq OWNED BY public.owner_feature_grant_events.id;


--
-- Name: owner_feature_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.owner_feature_grants (
    id integer NOT NULL,
    owner_id integer NOT NULL,
    feature_code character varying(160) NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    source character varying(32) DEFAULT 'migration'::character varying NOT NULL,
    config json DEFAULT '{}'::json NOT NULL,
    activated_at timestamp with time zone,
    suspended_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: owner_feature_grants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.owner_feature_grants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: owner_feature_grants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.owner_feature_grants_id_seq OWNED BY public.owner_feature_grants.id;


--
-- Name: payment_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_attempts (
    id integer NOT NULL,
    document_id character varying(255),
    event_id character varying(255),
    external_id character varying(255),
    provider character varying(255),
    integration_mode character varying(255),
    terminal_id character varying(255),
    cash_register_id character varying(255),
    amount numeric(10,2),
    currency character varying(255),
    status character varying(255),
    stan character varying(255),
    authorization_code character varying(255),
    transaction_ref character varying(255),
    approved_at timestamp(6) without time zone,
    raw_request_hash character varying(255),
    raw_response_hash character varying(255),
    last_error_code character varying(255),
    last_error_message text,
    retry_count integer,
    next_retry_at timestamp(6) without time zone,
    requires_inquiry boolean,
    requires_manual_action boolean,
    manual_action_code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: payment_attempts_fk_checkout_attempt_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_attempts_fk_checkout_attempt_lnk (
    id integer NOT NULL,
    payment_attempt_id integer,
    checkout_attempt_id integer
);


--
-- Name: payment_attempts_fk_checkout_attempt_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_attempts_fk_checkout_attempt_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_attempts_fk_checkout_attempt_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_attempts_fk_checkout_attempt_lnk_id_seq OWNED BY public.payment_attempts_fk_checkout_attempt_lnk.id;


--
-- Name: payment_attempts_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_attempts_fk_user_lnk (
    id integer NOT NULL,
    payment_attempt_id integer,
    user_id integer
);


--
-- Name: payment_attempts_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_attempts_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_attempts_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_attempts_fk_user_lnk_id_seq OWNED BY public.payment_attempts_fk_user_lnk.id;


--
-- Name: payment_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_attempts_id_seq OWNED BY public.payment_attempts.id;


--
-- Name: pos_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_devices (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    device_token_hash character varying(255),
    fingerprint character varying(255),
    last_seen timestamp(6) without time zone,
    revoked_at timestamp(6) without time zone,
    version character varying(255),
    notes character varying(255),
    platform character varying(255),
    apns_token character varying(255),
    apns_token_updated_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: pos_devices_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_devices_fk_user_lnk (
    id integer NOT NULL,
    pos_device_id integer,
    user_id integer
);


--
-- Name: pos_devices_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_devices_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_devices_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_devices_fk_user_lnk_id_seq OWNED BY public.pos_devices_fk_user_lnk.id;


--
-- Name: pos_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_devices_id_seq OWNED BY public.pos_devices.id;


--
-- Name: pos_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_jobs (
    id integer NOT NULL,
    document_id character varying(255),
    event_id character varying(255),
    kind character varying(255),
    payload jsonb,
    status character varying(255),
    priority integer,
    outcome jsonb,
    error_code character varying(255),
    error_message text,
    dispatched_at timestamp(6) without time zone,
    acked_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: pos_jobs_fk_device_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_jobs_fk_device_lnk (
    id integer NOT NULL,
    pos_job_id integer,
    pos_device_id integer
);


--
-- Name: pos_jobs_fk_device_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_jobs_fk_device_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_jobs_fk_device_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_jobs_fk_device_lnk_id_seq OWNED BY public.pos_jobs_fk_device_lnk.id;


--
-- Name: pos_jobs_fk_order_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_jobs_fk_order_lnk (
    id integer NOT NULL,
    pos_job_id integer,
    order_id integer
);


--
-- Name: pos_jobs_fk_order_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_jobs_fk_order_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_jobs_fk_order_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_jobs_fk_order_lnk_id_seq OWNED BY public.pos_jobs_fk_order_lnk.id;


--
-- Name: pos_jobs_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_jobs_fk_user_lnk (
    id integer NOT NULL,
    pos_job_id integer,
    user_id integer
);


--
-- Name: pos_jobs_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_jobs_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_jobs_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_jobs_fk_user_lnk_id_seq OWNED BY public.pos_jobs_fk_user_lnk.id;


--
-- Name: pos_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_jobs_id_seq OWNED BY public.pos_jobs.id;


--
-- Name: pos_pairing_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_pairing_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    token_hash character varying(255),
    expires_at timestamp(6) without time zone,
    consumed_at timestamp(6) without time zone,
    created_ip character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: pos_pairing_tokens_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_pairing_tokens_fk_user_lnk (
    id integer NOT NULL,
    pos_pairing_token_id integer,
    user_id integer
);


--
-- Name: pos_pairing_tokens_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_pairing_tokens_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_pairing_tokens_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_pairing_tokens_fk_user_lnk_id_seq OWNED BY public.pos_pairing_tokens_fk_user_lnk.id;


--
-- Name: pos_pairing_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_pairing_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_pairing_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_pairing_tokens_id_seq OWNED BY public.pos_pairing_tokens.id;


--
-- Name: reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reservations (
    id integer NOT NULL,
    document_id character varying(255),
    customer_name character varying(255),
    phone character varying(255),
    date date,
    "time" time without time zone,
    datetime timestamp(6) without time zone,
    slot_start timestamp(6) without time zone,
    number_of_people integer,
    notes text,
    status character varying(255),
    is_walkin boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    customer_email character varying(255)
);


--
-- Name: reservations_fk_order_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reservations_fk_order_lnk (
    id integer NOT NULL,
    reservation_id integer,
    order_id integer
);


--
-- Name: reservations_fk_order_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reservations_fk_order_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reservations_fk_order_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reservations_fk_order_lnk_id_seq OWNED BY public.reservations_fk_order_lnk.id;


--
-- Name: reservations_fk_table_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reservations_fk_table_lnk (
    id integer NOT NULL,
    reservation_id integer,
    table_id integer
);


--
-- Name: reservations_fk_table_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reservations_fk_table_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reservations_fk_table_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reservations_fk_table_lnk_id_seq OWNED BY public.reservations_fk_table_lnk.id;


--
-- Name: reservations_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reservations_fk_user_lnk (
    id integer NOT NULL,
    reservation_id integer,
    user_id integer
);


--
-- Name: reservations_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reservations_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reservations_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reservations_fk_user_lnk_id_seq OWNED BY public.reservations_fk_user_lnk.id;


--
-- Name: reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reservations_id_seq OWNED BY public.reservations.id;


--
-- Name: restaurant_category_routing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_category_routing (
    id bigint NOT NULL,
    owner_id integer NOT NULL,
    category text NOT NULL,
    category_key text GENERATED ALWAYS AS (lower(btrim(category))) STORED,
    staff_role text DEFAULT 'cucina'::text NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT restaurant_category_routing_role_check CHECK ((staff_role = ANY (ARRAY['cucina'::text, 'bar'::text, 'pizzeria'::text, 'cucina_sg'::text])))
);


--
-- Name: restaurant_category_routing_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restaurant_category_routing_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restaurant_category_routing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restaurant_category_routing_id_seq OWNED BY public.restaurant_category_routing.id;


--
-- Name: restaurant_daily_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_daily_stats (
    id integer NOT NULL,
    document_id character varying(255),
    date date,
    orders_count integer,
    customers_count integer,
    revenue numeric(10,2),
    items_sold integer,
    walkin_count integer,
    reservation_count integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    takeaway_count integer,
    voided_count integer,
    voided_revenue_lost numeric(10,2)
);


--
-- Name: restaurant_daily_stats_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_daily_stats_fk_user_lnk (
    id integer NOT NULL,
    restaurant_daily_stat_id integer,
    user_id integer
);


--
-- Name: restaurant_daily_stats_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restaurant_daily_stats_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restaurant_daily_stats_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restaurant_daily_stats_fk_user_lnk_id_seq OWNED BY public.restaurant_daily_stats_fk_user_lnk.id;


--
-- Name: restaurant_daily_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restaurant_daily_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restaurant_daily_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restaurant_daily_stats_id_seq OWNED BY public.restaurant_daily_stats.id;


--
-- Name: restaurant_printer_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_printer_configs (
    id integer NOT NULL,
    document_id character varying(255),
    auto_print_kitchen_enabled boolean,
    stations_json jsonb,
    cash_devices_json jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: restaurant_printer_configs_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_printer_configs_fk_user_lnk (
    id integer NOT NULL,
    restaurant_printer_config_id integer,
    user_id integer
);


--
-- Name: restaurant_printer_configs_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restaurant_printer_configs_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restaurant_printer_configs_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restaurant_printer_configs_fk_user_lnk_id_seq OWNED BY public.restaurant_printer_configs_fk_user_lnk.id;


--
-- Name: restaurant_printer_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restaurant_printer_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restaurant_printer_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restaurant_printer_configs_id_seq OWNED BY public.restaurant_printer_configs.id;


--
-- Name: restaurant_staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_staff (
    id bigint NOT NULL,
    owner_id integer NOT NULL,
    user_id integer NOT NULL,
    role text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    display_name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT restaurant_staff_not_self CHECK ((owner_id <> user_id)),
    CONSTRAINT restaurant_staff_role_check CHECK ((role = ANY (ARRAY['gestione'::text, 'cameriere'::text, 'cucina'::text, 'bar'::text, 'pizzeria'::text, 'cucina_sg'::text])))
);


--
-- Name: restaurant_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restaurant_staff_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restaurant_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restaurant_staff_id_seq OWNED BY public.restaurant_staff.id;


--
-- Name: restock_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restock_orders (
    id integer NOT NULL,
    document_id character varying(255),
    status character varying(255),
    ordered_at timestamp(6) without time zone,
    received_at timestamp(6) without time zone,
    cancelled_at timestamp(6) without time zone,
    expected_qty numeric(10,2),
    received_qty numeric(10,2),
    cost numeric(10,2),
    note text,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: restock_orders_fk_ingredient_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restock_orders_fk_ingredient_lnk (
    id integer NOT NULL,
    restock_order_id integer,
    ingredient_id integer
);


--
-- Name: restock_orders_fk_ingredient_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restock_orders_fk_ingredient_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restock_orders_fk_ingredient_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restock_orders_fk_ingredient_lnk_id_seq OWNED BY public.restock_orders_fk_ingredient_lnk.id;


--
-- Name: restock_orders_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restock_orders_fk_user_lnk (
    id integer NOT NULL,
    restock_order_id integer,
    user_id integer
);


--
-- Name: restock_orders_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restock_orders_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restock_orders_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restock_orders_fk_user_lnk_id_seq OWNED BY public.restock_orders_fk_user_lnk.id;


--
-- Name: restock_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restock_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restock_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restock_orders_id_seq OWNED BY public.restock_orders.id;


--
-- Name: strapi_ai_localization_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_ai_localization_jobs (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255) NOT NULL,
    source_locale character varying(255) NOT NULL,
    target_locales jsonb NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone
);


--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_ai_localization_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNED BY public.strapi_ai_localization_jobs.id;


--
-- Name: strapi_ai_metadata_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_ai_metadata_jobs (
    id integer NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(6) without time zone,
    completed_at timestamp(6) without time zone
);


--
-- Name: strapi_ai_metadata_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_ai_metadata_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_ai_metadata_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_ai_metadata_jobs_id_seq OWNED BY public.strapi_ai_metadata_jobs.id;


--
-- Name: strapi_api_token_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_api_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_api_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNED BY public.strapi_api_token_permissions.id;


--
-- Name: strapi_api_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_api_token_permissions_token_lnk (
    id integer NOT NULL,
    api_token_permission_id integer,
    api_token_id integer,
    api_token_permission_ord double precision
);


--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNED BY public.strapi_api_token_permissions_token_lnk.id;


--
-- Name: strapi_api_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_api_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    access_key character varying(255),
    encrypted_key text,
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    kind character varying(255)
);


--
-- Name: strapi_api_tokens_admin_user_owner_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_api_tokens_admin_user_owner_lnk (
    id integer NOT NULL,
    api_token_id integer,
    user_id integer,
    api_token_ord double precision
);


--
-- Name: strapi_api_tokens_admin_user_owner_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_api_tokens_admin_user_owner_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_api_tokens_admin_user_owner_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_api_tokens_admin_user_owner_lnk_id_seq OWNED BY public.strapi_api_tokens_admin_user_owner_lnk.id;


--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_api_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNED BY public.strapi_api_tokens.id;


--
-- Name: strapi_core_store_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_core_store_settings (
    id integer NOT NULL,
    key character varying(255),
    value text,
    type character varying(255),
    environment character varying(255),
    tag character varying(255)
);


--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_core_store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNED BY public.strapi_core_store_settings.id;


--
-- Name: strapi_database_schema; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_database_schema (
    id integer NOT NULL,
    schema json,
    "time" timestamp without time zone,
    hash character varying(255)
);


--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_database_schema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_database_schema_id_seq OWNED BY public.strapi_database_schema.id;


--
-- Name: strapi_history_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_history_versions (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255),
    locale character varying(255),
    status character varying(255),
    data jsonb,
    schema jsonb,
    created_at timestamp(6) without time zone,
    created_by_id integer
);


--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_history_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_history_versions_id_seq OWNED BY public.strapi_history_versions.id;


--
-- Name: strapi_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_migrations (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_migrations_id_seq OWNED BY public.strapi_migrations.id;


--
-- Name: strapi_migrations_internal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_migrations_internal (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_migrations_internal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNED BY public.strapi_migrations_internal.id;


--
-- Name: strapi_release_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_release_actions (
    id integer NOT NULL,
    document_id character varying(255),
    type character varying(255),
    content_type character varying(255),
    entry_document_id character varying(255),
    locale character varying(255),
    is_entry_valid boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer
);


--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_release_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_release_actions_id_seq OWNED BY public.strapi_release_actions.id;


--
-- Name: strapi_release_actions_release_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_release_actions_release_lnk (
    id integer NOT NULL,
    release_action_id integer,
    release_id integer,
    release_action_ord double precision
);


--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_release_actions_release_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNED BY public.strapi_release_actions_release_lnk.id;


--
-- Name: strapi_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_releases (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    released_at timestamp(6) without time zone,
    scheduled_at timestamp(6) without time zone,
    timezone character varying(255),
    status character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: strapi_releases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_releases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_releases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_releases_id_seq OWNED BY public.strapi_releases.id;


--
-- Name: strapi_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_sessions (
    id integer NOT NULL,
    document_id character varying(255),
    user_id character varying(255),
    session_id character varying(255),
    child_id character varying(255),
    device_id character varying(255),
    origin character varying(255),
    expires_at timestamp(6) without time zone,
    absolute_expires_at timestamp(6) without time zone,
    status character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    metadata jsonb
);


--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_sessions_id_seq OWNED BY public.strapi_sessions.id;


--
-- Name: strapi_transfer_token_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_transfer_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNED BY public.strapi_transfer_token_permissions.id;


--
-- Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_transfer_token_permissions_token_lnk (
    id integer NOT NULL,
    transfer_token_permission_id integer,
    transfer_token_id integer,
    transfer_token_permission_ord double precision
);


--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNED BY public.strapi_transfer_token_permissions_token_lnk.id;


--
-- Name: strapi_transfer_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_transfer_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    access_key character varying(255),
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    kind character varying(32) DEFAULT 'custom'::character varying NOT NULL
);


--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_transfer_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNED BY public.strapi_transfer_tokens.id;


--
-- Name: strapi_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_webhooks (
    id integer NOT NULL,
    name character varying(255),
    url text,
    headers jsonb,
    events jsonb,
    enabled boolean
);


--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_webhooks_id_seq OWNED BY public.strapi_webhooks.id;


--
-- Name: strapi_workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_workflows (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    content_types jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_workflows_id_seq OWNED BY public.strapi_workflows.id;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_workflows_stage_required_to_publish_lnk (
    id integer NOT NULL,
    workflow_id integer,
    workflow_stage_id integer
);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNED BY public.strapi_workflows_stage_required_to_publish_lnk.id;


--
-- Name: strapi_workflows_stages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_workflows_stages (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    color character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_workflows_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNED BY public.strapi_workflows_stages.id;


--
-- Name: strapi_workflows_stages_permissions_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_workflows_stages_permissions_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    permission_id integer,
    permission_ord double precision
);


--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNED BY public.strapi_workflows_stages_permissions_lnk.id;


--
-- Name: strapi_workflows_stages_workflow_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strapi_workflows_stages_workflow_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    workflow_id integer,
    workflow_stage_ord double precision
);


--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNED BY public.strapi_workflows_stages_workflow_lnk.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    name_normalized character varying(255),
    category character varying(255),
    phone character varying(255),
    email character varying(255),
    lead_time character varying(255),
    order_days character varying(255),
    notes text,
    is_active boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: suppliers_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers_fk_user_lnk (
    id integer NOT NULL,
    supplier_id integer,
    user_id integer
);


--
-- Name: suppliers_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_fk_user_lnk_id_seq OWNED BY public.suppliers_fk_user_lnk.id;


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: sync_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_events (
    id integer NOT NULL,
    document_id character varying(255),
    event_id character varying(255),
    hlc character varying(255),
    type character varying(255),
    payload jsonb,
    actor_json jsonb,
    order_document_id character varying(255),
    device_id character varying(255),
    applied_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: sync_events_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_events_fk_user_lnk (
    id integer NOT NULL,
    sync_event_id integer,
    user_id integer
);


--
-- Name: sync_events_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sync_events_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sync_events_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sync_events_fk_user_lnk_id_seq OWNED BY public.sync_events_fk_user_lnk.id;


--
-- Name: sync_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sync_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sync_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sync_events_id_seq OWNED BY public.sync_events.id;


--
-- Name: table_order_access_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_order_access_points (
    id integer NOT NULL,
    public_id character varying(64) NOT NULL,
    owner_id integer NOT NULL,
    bound_table_id integer,
    bound_table_ref character varying(128),
    token_version integer DEFAULT 1 NOT NULL,
    signing_kid character varying(128),
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    created_by integer,
    rotated_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    rotated_at timestamp with time zone,
    revoked_at timestamp with time zone
);


--
-- Name: table_order_access_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_order_access_points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_order_access_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_order_access_points_id_seq OWNED BY public.table_order_access_points.id;


--
-- Name: table_order_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_order_commands (
    id integer NOT NULL,
    session_id integer NOT NULL,
    participant_id integer NOT NULL,
    operation_id_hash character varying(128) NOT NULL,
    action character varying(32) NOT NULL,
    fingerprint character varying(256) NOT NULL,
    state character varying(32) DEFAULT 'started'::character varying NOT NULL,
    result_json text,
    result_revision integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    effects_json text,
    effects_attempts integer DEFAULT 0 NOT NULL,
    effects_at timestamp with time zone,
    manual_handled_at timestamp with time zone,
    manual_handled_by integer
);


--
-- Name: table_order_commands_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_order_commands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_order_commands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_order_commands_id_seq OWNED BY public.table_order_commands.id;


--
-- Name: table_order_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_order_participants (
    id integer NOT NULL,
    public_id character varying(64) NOT NULL,
    session_id integer NOT NULL,
    owner_id integer NOT NULL,
    access_point_id integer NOT NULL,
    access_point_token_version integer NOT NULL,
    token_hash character varying(128) NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_seen_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    user_agent_hash character varying(128)
);


--
-- Name: table_order_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_order_participants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_order_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_order_participants_id_seq OWNED BY public.table_order_participants.id;


--
-- Name: table_order_rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_order_rate_limits (
    id integer NOT NULL,
    bucket_key character varying(200) NOT NULL,
    window_start bigint NOT NULL,
    hits integer DEFAULT 0 NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: table_order_rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_order_rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_order_rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_order_rate_limits_id_seq OWNED BY public.table_order_rate_limits.id;


--
-- Name: table_order_realtime_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_order_realtime_events (
    id integer NOT NULL,
    session_public_id character varying(64) NOT NULL,
    revision integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: table_order_realtime_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_order_realtime_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_order_realtime_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_order_realtime_events_id_seq OWNED BY public.table_order_realtime_events.id;


--
-- Name: table_order_service_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_order_service_requests (
    id integer NOT NULL,
    public_id character varying(64) NOT NULL,
    owner_id integer NOT NULL,
    session_id integer NOT NULL,
    participant_id integer,
    table_id integer,
    order_id integer NOT NULL,
    kind character varying(32) NOT NULL,
    message text,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    resolved_at timestamp with time zone,
    resolved_by integer
);


--
-- Name: table_order_service_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_order_service_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_order_service_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_order_service_requests_id_seq OWNED BY public.table_order_service_requests.id;


--
-- Name: table_order_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_order_sessions (
    id integer NOT NULL,
    public_id character varying(64) NOT NULL,
    owner_id integer NOT NULL,
    table_id integer,
    order_id integer NOT NULL,
    status character varying(32) DEFAULT 'open'::character varying NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    pause_reason character varying(64),
    opened_by integer,
    paused_by integer,
    closed_by integer,
    opened_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    paused_at timestamp with time zone,
    closed_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    close_reason character varying(64)
);


--
-- Name: table_order_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_order_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_order_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_order_sessions_id_seq OWNED BY public.table_order_sessions.id;


--
-- Name: tables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tables (
    id integer NOT NULL,
    document_id character varying(255),
    number integer,
    seats integer,
    area character varying(255),
    status character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    kind character varying(255),
    label character varying(255),
    sort_key numeric(10,2),
    layout_x integer,
    layout_y integer,
    self_order_enabled boolean DEFAULT false NOT NULL
);


--
-- Name: tables_fk_origins_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tables_fk_origins_lnk (
    id integer NOT NULL,
    table_id integer,
    inv_table_id integer,
    table_ord double precision,
    inv_table_ord double precision
);


--
-- Name: tables_fk_origins_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tables_fk_origins_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tables_fk_origins_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tables_fk_origins_lnk_id_seq OWNED BY public.tables_fk_origins_lnk.id;


--
-- Name: tables_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tables_fk_user_lnk (
    id integer NOT NULL,
    table_id integer,
    user_id integer
);


--
-- Name: tables_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tables_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tables_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tables_fk_user_lnk_id_seq OWNED BY public.tables_fk_user_lnk.id;


--
-- Name: tables_fk_zone_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tables_fk_zone_lnk (
    id integer NOT NULL,
    table_id integer,
    zone_id integer,
    table_ord double precision
);


--
-- Name: tables_fk_zone_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tables_fk_zone_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tables_fk_zone_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tables_fk_zone_lnk_id_seq OWNED BY public.tables_fk_zone_lnk.id;


--
-- Name: tables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tables_id_seq OWNED BY public.tables.id;


--
-- Name: takeaway_time_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.takeaway_time_proposals (
    id integer NOT NULL,
    document_id character varying(255),
    order_document_id character varying(255),
    version integer,
    previous_pickup_at timestamp(6) without time zone,
    proposed_pickup_at timestamp(6) without time zone,
    proposed_lead_minutes integer,
    status character varying(255),
    response_nonce character varying(255),
    token_key_id character varying(255),
    expires_at timestamp(6) without time zone,
    responded_at timestamp(6) without time zone,
    decision character varying(255),
    message character varying(255),
    created_by_user_id character varying(255),
    created_by_role character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: takeaway_time_proposals_fk_order_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.takeaway_time_proposals_fk_order_lnk (
    id integer NOT NULL,
    takeaway_time_proposal_id integer,
    order_id integer
);


--
-- Name: takeaway_time_proposals_fk_order_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.takeaway_time_proposals_fk_order_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: takeaway_time_proposals_fk_order_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.takeaway_time_proposals_fk_order_lnk_id_seq OWNED BY public.takeaway_time_proposals_fk_order_lnk.id;


--
-- Name: takeaway_time_proposals_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.takeaway_time_proposals_fk_user_lnk (
    id integer NOT NULL,
    takeaway_time_proposal_id integer,
    user_id integer
);


--
-- Name: takeaway_time_proposals_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.takeaway_time_proposals_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: takeaway_time_proposals_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.takeaway_time_proposals_fk_user_lnk_id_seq OWNED BY public.takeaway_time_proposals_fk_user_lnk.id;


--
-- Name: takeaway_time_proposals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.takeaway_time_proposals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: takeaway_time_proposals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.takeaway_time_proposals_id_seq OWNED BY public.takeaway_time_proposals.id;


--
-- Name: up_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.up_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: up_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.up_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: up_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.up_permissions_id_seq OWNED BY public.up_permissions.id;


--
-- Name: up_permissions_role_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.up_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.up_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNED BY public.up_permissions_role_lnk.id;


--
-- Name: up_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.up_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: up_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.up_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: up_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.up_roles_id_seq OWNED BY public.up_roles.id;


--
-- Name: up_users_fk_owner_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.up_users_fk_owner_lnk (
    id integer NOT NULL,
    user_id integer,
    inv_user_id integer,
    user_ord double precision
);


--
-- Name: up_users_fk_owner_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.up_users_fk_owner_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: up_users_fk_owner_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.up_users_fk_owner_lnk_id_seq OWNED BY public.up_users_fk_owner_lnk.id;


--
-- Name: up_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.up_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: up_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.up_users_id_seq OWNED BY public.up_users.id;


--
-- Name: up_users_role_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.up_users_role_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    user_ord double precision
);


--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.up_users_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNED BY public.up_users_role_lnk.id;


--
-- Name: upload_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.upload_folders (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    path_id integer,
    path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: upload_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.upload_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: upload_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.upload_folders_id_seq OWNED BY public.upload_folders.id;


--
-- Name: upload_folders_parent_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.upload_folders_parent_lnk (
    id integer NOT NULL,
    folder_id integer,
    inv_folder_id integer,
    folder_ord double precision
);


--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.upload_folders_parent_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNED BY public.upload_folders_parent_lnk.id;


--
-- Name: website_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.website_configs (
    id integer NOT NULL,
    document_id character varying(255),
    site_url character varying(255),
    restaurant_name character varying(255),
    coperti_invernali integer,
    coperti_estivi integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    cover_charge numeric(10,2),
    timezone character varying(255),
    takeaway_default_lead_minutes integer,
    takeaway_time_proposals_enabled boolean,
    digital_payment_mode character varying(255),
    table_ordering_enabled boolean DEFAULT false NOT NULL,
    table_ordering_session_ttl_minutes integer DEFAULT 720 NOT NULL
);


--
-- Name: website_configs_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.website_configs_fk_user_lnk (
    id integer NOT NULL,
    website_config_id integer,
    user_id integer
);


--
-- Name: website_configs_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.website_configs_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: website_configs_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.website_configs_fk_user_lnk_id_seq OWNED BY public.website_configs_fk_user_lnk.id;


--
-- Name: website_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.website_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: website_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.website_configs_id_seq OWNED BY public.website_configs.id;


--
-- Name: zones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.zones (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    sort_order integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


--
-- Name: zones_fk_user_lnk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.zones_fk_user_lnk (
    id integer NOT NULL,
    zone_id integer,
    user_id integer
);


--
-- Name: zones_fk_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.zones_fk_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zones_fk_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.zones_fk_user_lnk_id_seq OWNED BY public.zones_fk_user_lnk.id;


--
-- Name: zones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.zones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: zones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.zones_id_seq OWNED BY public.zones.id;


--
-- Name: admin_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_id_seq'::regclass);


--
-- Name: admin_permissions_api_token_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_api_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_api_token_lnk_id_seq'::regclass);


--
-- Name: admin_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_role_lnk_id_seq'::regclass);


--
-- Name: admin_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_roles ALTER COLUMN id SET DEFAULT nextval('public.admin_roles_id_seq'::regclass);


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: admin_users_roles_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users_roles_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_users_roles_lnk_id_seq'::regclass);


--
-- Name: audit_hardware_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_hardware_events ALTER COLUMN id SET DEFAULT nextval('public.audit_hardware_events_id_seq'::regclass);


--
-- Name: bar_shifts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts ALTER COLUMN id SET DEFAULT nextval('public.bar_shifts_id_seq'::regclass);


--
-- Name: bar_shifts_closed_by_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_closed_by_lnk ALTER COLUMN id SET DEFAULT nextval('public.bar_shifts_closed_by_lnk_id_seq'::regclass);


--
-- Name: bar_shifts_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.bar_shifts_fk_user_lnk_id_seq'::regclass);


--
-- Name: bar_shifts_opened_by_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_opened_by_lnk ALTER COLUMN id SET DEFAULT nextval('public.bar_shifts_opened_by_lnk_id_seq'::regclass);


--
-- Name: checkout_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts ALTER COLUMN id SET DEFAULT nextval('public.checkout_attempts_id_seq'::regclass);


--
-- Name: checkout_attempts_fk_order_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_order_lnk ALTER COLUMN id SET DEFAULT nextval('public.checkout_attempts_fk_order_lnk_id_seq'::regclass);


--
-- Name: checkout_attempts_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.checkout_attempts_fk_user_lnk_id_seq'::regclass);


--
-- Name: ct_idempotency_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ct_idempotency_keys ALTER COLUMN id SET DEFAULT nextval('public.ct_idempotency_keys_id_seq'::regclass);


--
-- Name: customer_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages ALTER COLUMN id SET DEFAULT nextval('public.customer_messages_id_seq'::regclass);


--
-- Name: customer_messages_fk_order_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_order_lnk ALTER COLUMN id SET DEFAULT nextval('public.customer_messages_fk_order_lnk_id_seq'::regclass);


--
-- Name: customer_messages_fk_time_proposal_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_time_proposal_lnk ALTER COLUMN id SET DEFAULT nextval('public.customer_messages_fk_time_proposal_lnk_id_seq'::regclass);


--
-- Name: customer_messages_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.customer_messages_fk_user_lnk_id_seq'::regclass);


--
-- Name: element_ingredients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients ALTER COLUMN id SET DEFAULT nextval('public.element_ingredients_id_seq'::regclass);


--
-- Name: element_ingredients_fk_element_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_element_lnk ALTER COLUMN id SET DEFAULT nextval('public.element_ingredients_fk_element_lnk_id_seq'::regclass);


--
-- Name: element_ingredients_fk_ingredient_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_ingredient_lnk ALTER COLUMN id SET DEFAULT nextval('public.element_ingredients_fk_ingredient_lnk_id_seq'::regclass);


--
-- Name: elements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements ALTER COLUMN id SET DEFAULT nextval('public.elements_id_seq'::regclass);


--
-- Name: elements_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.elements_fk_user_lnk_id_seq'::regclass);


--
-- Name: feature_definitions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_definitions ALTER COLUMN id SET DEFAULT nextval('public.feature_definitions_id_seq'::regclass);


--
-- Name: feature_rollout_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollout_events ALTER COLUMN id SET DEFAULT nextval('public.feature_rollout_events_id_seq'::regclass);


--
-- Name: feature_rollout_owners id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollout_owners ALTER COLUMN id SET DEFAULT nextval('public.feature_rollout_owners_id_seq'::regclass);


--
-- Name: feature_rollouts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollouts ALTER COLUMN id SET DEFAULT nextval('public.feature_rollouts_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: files_folder_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files_folder_lnk ALTER COLUMN id SET DEFAULT nextval('public.files_folder_lnk_id_seq'::regclass);


--
-- Name: files_related_mph id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files_related_mph ALTER COLUMN id SET DEFAULT nextval('public.files_related_mph_id_seq'::regclass);


--
-- Name: fiscal_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts ALTER COLUMN id SET DEFAULT nextval('public.fiscal_attempts_id_seq'::regclass);


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_checkout_attempt_lnk ALTER COLUMN id SET DEFAULT nextval('public.fiscal_attempts_fk_checkout_attempt_lnk_id_seq'::regclass);


--
-- Name: fiscal_attempts_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.fiscal_attempts_fk_user_lnk_id_seq'::regclass);


--
-- Name: fiscal_correction_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts ALTER COLUMN id SET DEFAULT nextval('public.fiscal_correction_attempts_id_seq'::regclass);


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_checkout_attempt_lnk ALTER COLUMN id SET DEFAULT nextval('public.fiscal_correction_attempts_fk_checkout_attempt_lnk_id_seq'::regclass);


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_fiscal_attempt_lnk ALTER COLUMN id SET DEFAULT nextval('public.fiscal_correction_attempts_fk_fiscal_attempt_lnk_id_seq'::regclass);


--
-- Name: fiscal_correction_attempts_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.fiscal_correction_attempts_fk_user_lnk_id_seq'::regclass);


--
-- Name: hardware_endpoints id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints ALTER COLUMN id SET DEFAULT nextval('public.hardware_endpoints_id_seq'::regclass);


--
-- Name: hardware_endpoints_fk_pos_device_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_pos_device_lnk ALTER COLUMN id SET DEFAULT nextval('public.hardware_endpoints_fk_pos_device_lnk_id_seq'::regclass);


--
-- Name: hardware_endpoints_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.hardware_endpoints_fk_user_lnk_id_seq'::regclass);


--
-- Name: hardware_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs ALTER COLUMN id SET DEFAULT nextval('public.hardware_jobs_id_seq'::regclass);


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_checkout_attempt_lnk ALTER COLUMN id SET DEFAULT nextval('public.hardware_jobs_fk_checkout_attempt_lnk_id_seq'::regclass);


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_hardware_endpoint_lnk ALTER COLUMN id SET DEFAULT nextval('public.hardware_jobs_fk_hardware_endpoint_lnk_id_seq'::regclass);


--
-- Name: hardware_jobs_fk_pos_device_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_pos_device_lnk ALTER COLUMN id SET DEFAULT nextval('public.hardware_jobs_fk_pos_device_lnk_id_seq'::regclass);


--
-- Name: hardware_jobs_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.hardware_jobs_fk_user_lnk_id_seq'::regclass);


--
-- Name: i18n_locale id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18n_locale ALTER COLUMN id SET DEFAULT nextval('public.i18n_locale_id_seq'::regclass);


--
-- Name: ingredients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients ALTER COLUMN id SET DEFAULT nextval('public.ingredients_id_seq'::regclass);


--
-- Name: ingredients_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.ingredients_fk_user_lnk_id_seq'::regclass);


--
-- Name: inventory_alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts ALTER COLUMN id SET DEFAULT nextval('public.inventory_alerts_id_seq'::regclass);


--
-- Name: inventory_alerts_acknowledged_by_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_acknowledged_by_lnk ALTER COLUMN id SET DEFAULT nextval('public.inventory_alerts_acknowledged_by_lnk_id_seq'::regclass);


--
-- Name: inventory_alerts_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.inventory_alerts_fk_user_lnk_id_seq'::regclass);


--
-- Name: inventory_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_id_seq'::regclass);


--
-- Name: inventory_movements_fk_bar_shift_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_bar_shift_lnk ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_fk_bar_shift_lnk_id_seq'::regclass);


--
-- Name: inventory_movements_fk_ingredient_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_ingredient_lnk ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_fk_ingredient_lnk_id_seq'::regclass);


--
-- Name: inventory_movements_fk_order_item_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_item_lnk ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_fk_order_item_lnk_id_seq'::regclass);


--
-- Name: inventory_movements_fk_order_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_lnk ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_fk_order_lnk_id_seq'::regclass);


--
-- Name: inventory_movements_fk_restock_order_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_restock_order_lnk ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_fk_restock_order_lnk_id_seq'::regclass);


--
-- Name: inventory_movements_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_fk_user_lnk_id_seq'::regclass);


--
-- Name: menu_element_stats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats ALTER COLUMN id SET DEFAULT nextval('public.menu_element_stats_id_seq'::regclass);


--
-- Name: menu_element_stats_fk_element_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_element_lnk ALTER COLUMN id SET DEFAULT nextval('public.menu_element_stats_fk_element_lnk_id_seq'::regclass);


--
-- Name: menu_element_stats_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.menu_element_stats_fk_user_lnk_id_seq'::regclass);


--
-- Name: menu_import_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs ALTER COLUMN id SET DEFAULT nextval('public.menu_import_jobs_id_seq'::regclass);


--
-- Name: menu_import_jobs_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.menu_import_jobs_fk_user_lnk_id_seq'::regclass);


--
-- Name: menu_import_leases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_leases ALTER COLUMN id SET DEFAULT nextval('public.menu_import_leases_id_seq'::regclass);


--
-- Name: menus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus ALTER COLUMN id SET DEFAULT nextval('public.menus_id_seq'::regclass);


--
-- Name: menus_fk_elements_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_elements_lnk ALTER COLUMN id SET DEFAULT nextval('public.menus_fk_elements_lnk_id_seq'::regclass);


--
-- Name: menus_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.menus_fk_user_lnk_id_seq'::regclass);


--
-- Name: order_archives id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives ALTER COLUMN id SET DEFAULT nextval('public.order_archives_id_seq'::regclass);


--
-- Name: order_archives_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.order_archives_fk_user_lnk_id_seq'::regclass);


--
-- Name: order_item_addons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons ALTER COLUMN id SET DEFAULT nextval('public.order_item_addons_id_seq'::regclass);


--
-- Name: order_item_addons_fk_ingredient_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_ingredient_lnk ALTER COLUMN id SET DEFAULT nextval('public.order_item_addons_fk_ingredient_lnk_id_seq'::regclass);


--
-- Name: order_item_addons_fk_order_item_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_order_item_lnk ALTER COLUMN id SET DEFAULT nextval('public.order_item_addons_fk_order_item_lnk_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: order_items_fk_element_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_element_lnk ALTER COLUMN id SET DEFAULT nextval('public.order_items_fk_element_lnk_id_seq'::regclass);


--
-- Name: order_items_fk_order_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_order_lnk ALTER COLUMN id SET DEFAULT nextval('public.order_items_fk_order_lnk_id_seq'::regclass);


--
-- Name: order_realtime_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_realtime_events ALTER COLUMN id SET DEFAULT nextval('public.order_realtime_events_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: orders_fk_table_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_table_lnk ALTER COLUMN id SET DEFAULT nextval('public.orders_fk_table_lnk_id_seq'::regclass);


--
-- Name: orders_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.orders_fk_user_lnk_id_seq'::regclass);


--
-- Name: owner_feature_grant_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_feature_grant_events ALTER COLUMN id SET DEFAULT nextval('public.owner_feature_grant_events_id_seq'::regclass);


--
-- Name: owner_feature_grants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_feature_grants ALTER COLUMN id SET DEFAULT nextval('public.owner_feature_grants_id_seq'::regclass);


--
-- Name: payment_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts ALTER COLUMN id SET DEFAULT nextval('public.payment_attempts_id_seq'::regclass);


--
-- Name: payment_attempts_fk_checkout_attempt_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_checkout_attempt_lnk ALTER COLUMN id SET DEFAULT nextval('public.payment_attempts_fk_checkout_attempt_lnk_id_seq'::regclass);


--
-- Name: payment_attempts_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.payment_attempts_fk_user_lnk_id_seq'::regclass);


--
-- Name: pos_devices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices ALTER COLUMN id SET DEFAULT nextval('public.pos_devices_id_seq'::regclass);


--
-- Name: pos_devices_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.pos_devices_fk_user_lnk_id_seq'::regclass);


--
-- Name: pos_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs ALTER COLUMN id SET DEFAULT nextval('public.pos_jobs_id_seq'::regclass);


--
-- Name: pos_jobs_fk_device_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_device_lnk ALTER COLUMN id SET DEFAULT nextval('public.pos_jobs_fk_device_lnk_id_seq'::regclass);


--
-- Name: pos_jobs_fk_order_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_order_lnk ALTER COLUMN id SET DEFAULT nextval('public.pos_jobs_fk_order_lnk_id_seq'::regclass);


--
-- Name: pos_jobs_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.pos_jobs_fk_user_lnk_id_seq'::regclass);


--
-- Name: pos_pairing_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens ALTER COLUMN id SET DEFAULT nextval('public.pos_pairing_tokens_id_seq'::regclass);


--
-- Name: pos_pairing_tokens_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.pos_pairing_tokens_fk_user_lnk_id_seq'::regclass);


--
-- Name: reservations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations ALTER COLUMN id SET DEFAULT nextval('public.reservations_id_seq'::regclass);


--
-- Name: reservations_fk_order_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_order_lnk ALTER COLUMN id SET DEFAULT nextval('public.reservations_fk_order_lnk_id_seq'::regclass);


--
-- Name: reservations_fk_table_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_table_lnk ALTER COLUMN id SET DEFAULT nextval('public.reservations_fk_table_lnk_id_seq'::regclass);


--
-- Name: reservations_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.reservations_fk_user_lnk_id_seq'::regclass);


--
-- Name: restaurant_category_routing id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_category_routing ALTER COLUMN id SET DEFAULT nextval('public.restaurant_category_routing_id_seq'::regclass);


--
-- Name: restaurant_daily_stats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats ALTER COLUMN id SET DEFAULT nextval('public.restaurant_daily_stats_id_seq'::regclass);


--
-- Name: restaurant_daily_stats_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.restaurant_daily_stats_fk_user_lnk_id_seq'::regclass);


--
-- Name: restaurant_printer_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs ALTER COLUMN id SET DEFAULT nextval('public.restaurant_printer_configs_id_seq'::regclass);


--
-- Name: restaurant_printer_configs_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.restaurant_printer_configs_fk_user_lnk_id_seq'::regclass);


--
-- Name: restaurant_staff id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_staff ALTER COLUMN id SET DEFAULT nextval('public.restaurant_staff_id_seq'::regclass);


--
-- Name: restock_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders ALTER COLUMN id SET DEFAULT nextval('public.restock_orders_id_seq'::regclass);


--
-- Name: restock_orders_fk_ingredient_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_ingredient_lnk ALTER COLUMN id SET DEFAULT nextval('public.restock_orders_fk_ingredient_lnk_id_seq'::regclass);


--
-- Name: restock_orders_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.restock_orders_fk_user_lnk_id_seq'::regclass);


--
-- Name: strapi_ai_localization_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs ALTER COLUMN id SET DEFAULT nextval('public.strapi_ai_localization_jobs_id_seq'::regclass);


--
-- Name: strapi_ai_metadata_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_ai_metadata_jobs ALTER COLUMN id SET DEFAULT nextval('public.strapi_ai_metadata_jobs_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_api_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_tokens_id_seq'::regclass);


--
-- Name: strapi_api_tokens_admin_user_owner_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens_admin_user_owner_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_tokens_admin_user_owner_lnk_id_seq'::regclass);


--
-- Name: strapi_core_store_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_core_store_settings ALTER COLUMN id SET DEFAULT nextval('public.strapi_core_store_settings_id_seq'::regclass);


--
-- Name: strapi_database_schema id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_database_schema ALTER COLUMN id SET DEFAULT nextval('public.strapi_database_schema_id_seq'::regclass);


--
-- Name: strapi_history_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_history_versions ALTER COLUMN id SET DEFAULT nextval('public.strapi_history_versions_id_seq'::regclass);


--
-- Name: strapi_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_migrations ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_id_seq'::regclass);


--
-- Name: strapi_migrations_internal id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_migrations_internal ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_internal_id_seq'::regclass);


--
-- Name: strapi_release_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_id_seq'::regclass);


--
-- Name: strapi_release_actions_release_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_release_lnk_id_seq'::regclass);


--
-- Name: strapi_releases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_releases ALTER COLUMN id SET DEFAULT nextval('public.strapi_releases_id_seq'::regclass);


--
-- Name: strapi_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_sessions ALTER COLUMN id SET DEFAULT nextval('public.strapi_sessions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_transfer_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_tokens_id_seq'::regclass);


--
-- Name: strapi_webhooks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_webhooks ALTER COLUMN id SET DEFAULT nextval('public.strapi_webhooks_id_seq'::regclass);


--
-- Name: strapi_workflows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_id_seq'::regclass);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_permissions_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_permissions_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_workflow_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_workflow_lnk_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: suppliers_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.suppliers_fk_user_lnk_id_seq'::regclass);


--
-- Name: sync_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events ALTER COLUMN id SET DEFAULT nextval('public.sync_events_id_seq'::regclass);


--
-- Name: sync_events_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.sync_events_fk_user_lnk_id_seq'::regclass);


--
-- Name: table_order_access_points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_access_points ALTER COLUMN id SET DEFAULT nextval('public.table_order_access_points_id_seq'::regclass);


--
-- Name: table_order_commands id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_commands ALTER COLUMN id SET DEFAULT nextval('public.table_order_commands_id_seq'::regclass);


--
-- Name: table_order_participants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_participants ALTER COLUMN id SET DEFAULT nextval('public.table_order_participants_id_seq'::regclass);


--
-- Name: table_order_rate_limits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_rate_limits ALTER COLUMN id SET DEFAULT nextval('public.table_order_rate_limits_id_seq'::regclass);


--
-- Name: table_order_realtime_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_realtime_events ALTER COLUMN id SET DEFAULT nextval('public.table_order_realtime_events_id_seq'::regclass);


--
-- Name: table_order_service_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_service_requests ALTER COLUMN id SET DEFAULT nextval('public.table_order_service_requests_id_seq'::regclass);


--
-- Name: table_order_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_sessions ALTER COLUMN id SET DEFAULT nextval('public.table_order_sessions_id_seq'::regclass);


--
-- Name: tables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables ALTER COLUMN id SET DEFAULT nextval('public.tables_id_seq'::regclass);


--
-- Name: tables_fk_origins_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_origins_lnk ALTER COLUMN id SET DEFAULT nextval('public.tables_fk_origins_lnk_id_seq'::regclass);


--
-- Name: tables_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.tables_fk_user_lnk_id_seq'::regclass);


--
-- Name: tables_fk_zone_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_zone_lnk ALTER COLUMN id SET DEFAULT nextval('public.tables_fk_zone_lnk_id_seq'::regclass);


--
-- Name: takeaway_time_proposals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals ALTER COLUMN id SET DEFAULT nextval('public.takeaway_time_proposals_id_seq'::regclass);


--
-- Name: takeaway_time_proposals_fk_order_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_order_lnk ALTER COLUMN id SET DEFAULT nextval('public.takeaway_time_proposals_fk_order_lnk_id_seq'::regclass);


--
-- Name: takeaway_time_proposals_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.takeaway_time_proposals_fk_user_lnk_id_seq'::regclass);


--
-- Name: up_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_id_seq'::regclass);


--
-- Name: up_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_role_lnk_id_seq'::regclass);


--
-- Name: up_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_roles ALTER COLUMN id SET DEFAULT nextval('public.up_roles_id_seq'::regclass);


--
-- Name: up_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users ALTER COLUMN id SET DEFAULT nextval('public.up_users_id_seq'::regclass);


--
-- Name: up_users_fk_owner_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_fk_owner_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_users_fk_owner_lnk_id_seq'::regclass);


--
-- Name: up_users_role_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_users_role_lnk_id_seq'::regclass);


--
-- Name: upload_folders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_id_seq'::regclass);


--
-- Name: upload_folders_parent_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders_parent_lnk ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_parent_lnk_id_seq'::regclass);


--
-- Name: website_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs ALTER COLUMN id SET DEFAULT nextval('public.website_configs_id_seq'::regclass);


--
-- Name: website_configs_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.website_configs_fk_user_lnk_id_seq'::regclass);


--
-- Name: zones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones ALTER COLUMN id SET DEFAULT nextval('public.zones_id_seq'::regclass);


--
-- Name: zones_fk_user_lnk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones_fk_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.zones_fk_user_lnk_id_seq'::regclass);


--
-- Name: admin_permissions_api_token_lnk admin_permissions_api_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_api_token_lnk
    ADD CONSTRAINT admin_permissions_api_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_api_token_lnk admin_permissions_api_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_api_token_lnk
    ADD CONSTRAINT admin_permissions_api_token_lnk_uq UNIQUE (permission_id, api_token_id);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: admin_roles admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: audit_hardware_events audit_hardware_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_hardware_events
    ADD CONSTRAINT audit_hardware_events_pkey PRIMARY KEY (id);


--
-- Name: bar_shifts_closed_by_lnk bar_shifts_closed_by_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_closed_by_lnk
    ADD CONSTRAINT bar_shifts_closed_by_lnk_pkey PRIMARY KEY (id);


--
-- Name: bar_shifts_closed_by_lnk bar_shifts_closed_by_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_closed_by_lnk
    ADD CONSTRAINT bar_shifts_closed_by_lnk_uq UNIQUE (bar_shift_id, user_id);


--
-- Name: bar_shifts_fk_user_lnk bar_shifts_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_fk_user_lnk
    ADD CONSTRAINT bar_shifts_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: bar_shifts_fk_user_lnk bar_shifts_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_fk_user_lnk
    ADD CONSTRAINT bar_shifts_fk_user_lnk_uq UNIQUE (bar_shift_id, user_id);


--
-- Name: bar_shifts_opened_by_lnk bar_shifts_opened_by_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_opened_by_lnk
    ADD CONSTRAINT bar_shifts_opened_by_lnk_pkey PRIMARY KEY (id);


--
-- Name: bar_shifts_opened_by_lnk bar_shifts_opened_by_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_opened_by_lnk
    ADD CONSTRAINT bar_shifts_opened_by_lnk_uq UNIQUE (bar_shift_id, user_id);


--
-- Name: bar_shifts bar_shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts
    ADD CONSTRAINT bar_shifts_pkey PRIMARY KEY (id);


--
-- Name: checkout_attempts_fk_order_lnk checkout_attempts_fk_order_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_order_lnk
    ADD CONSTRAINT checkout_attempts_fk_order_lnk_pkey PRIMARY KEY (id);


--
-- Name: checkout_attempts_fk_order_lnk checkout_attempts_fk_order_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_order_lnk
    ADD CONSTRAINT checkout_attempts_fk_order_lnk_uq UNIQUE (checkout_attempt_id, order_id);


--
-- Name: checkout_attempts_fk_user_lnk checkout_attempts_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_user_lnk
    ADD CONSTRAINT checkout_attempts_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: checkout_attempts_fk_user_lnk checkout_attempts_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_user_lnk
    ADD CONSTRAINT checkout_attempts_fk_user_lnk_uq UNIQUE (checkout_attempt_id, user_id);


--
-- Name: checkout_attempts checkout_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts
    ADD CONSTRAINT checkout_attempts_pkey PRIMARY KEY (id);


--
-- Name: ct_idempotency_keys ct_idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ct_idempotency_keys
    ADD CONSTRAINT ct_idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: ct_idempotency_keys ct_idempotency_keys_scope_key_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ct_idempotency_keys
    ADD CONSTRAINT ct_idempotency_keys_scope_key_uq UNIQUE (scope, key);


--
-- Name: customer_messages customer_messages_event_key_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages
    ADD CONSTRAINT customer_messages_event_key_uq UNIQUE (event_key);


--
-- Name: customer_messages_fk_order_lnk customer_messages_fk_order_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_order_lnk
    ADD CONSTRAINT customer_messages_fk_order_lnk_pkey PRIMARY KEY (id);


--
-- Name: customer_messages_fk_order_lnk customer_messages_fk_order_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_order_lnk
    ADD CONSTRAINT customer_messages_fk_order_lnk_uq UNIQUE (customer_message_id, order_id);


--
-- Name: customer_messages_fk_time_proposal_lnk customer_messages_fk_time_proposal_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_time_proposal_lnk
    ADD CONSTRAINT customer_messages_fk_time_proposal_lnk_pkey PRIMARY KEY (id);


--
-- Name: customer_messages_fk_time_proposal_lnk customer_messages_fk_time_proposal_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_time_proposal_lnk
    ADD CONSTRAINT customer_messages_fk_time_proposal_lnk_uq UNIQUE (customer_message_id, takeaway_time_proposal_id);


--
-- Name: customer_messages_fk_user_lnk customer_messages_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_user_lnk
    ADD CONSTRAINT customer_messages_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: customer_messages_fk_user_lnk customer_messages_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_user_lnk
    ADD CONSTRAINT customer_messages_fk_user_lnk_uq UNIQUE (customer_message_id, user_id);


--
-- Name: customer_messages customer_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages
    ADD CONSTRAINT customer_messages_pkey PRIMARY KEY (id);


--
-- Name: element_ingredients_fk_element_lnk element_ingredients_fk_element_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_element_lnk
    ADD CONSTRAINT element_ingredients_fk_element_lnk_pkey PRIMARY KEY (id);


--
-- Name: element_ingredients_fk_element_lnk element_ingredients_fk_element_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_element_lnk
    ADD CONSTRAINT element_ingredients_fk_element_lnk_uq UNIQUE (element_ingredient_id, element_id);


--
-- Name: element_ingredients_fk_ingredient_lnk element_ingredients_fk_ingredient_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_ingredient_lnk
    ADD CONSTRAINT element_ingredients_fk_ingredient_lnk_pkey PRIMARY KEY (id);


--
-- Name: element_ingredients_fk_ingredient_lnk element_ingredients_fk_ingredient_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_ingredient_lnk
    ADD CONSTRAINT element_ingredients_fk_ingredient_lnk_uq UNIQUE (element_ingredient_id, ingredient_id);


--
-- Name: element_ingredients element_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients
    ADD CONSTRAINT element_ingredients_pkey PRIMARY KEY (id);


--
-- Name: element_ingredients element_ingredients_table_order_public_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients
    ADD CONSTRAINT element_ingredients_table_order_public_id_unique UNIQUE (table_order_public_id);


--
-- Name: elements_fk_user_lnk elements_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_fk_user_lnk
    ADD CONSTRAINT elements_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: elements_fk_user_lnk elements_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_fk_user_lnk
    ADD CONSTRAINT elements_fk_user_lnk_uq UNIQUE (element_id, user_id);


--
-- Name: elements elements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_pkey PRIMARY KEY (id);


--
-- Name: elements elements_table_order_public_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_table_order_public_id_unique UNIQUE (table_order_public_id);


--
-- Name: feature_definitions feature_definitions_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_definitions
    ADD CONSTRAINT feature_definitions_code_unique UNIQUE (code);


--
-- Name: feature_definitions feature_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_definitions
    ADD CONSTRAINT feature_definitions_pkey PRIMARY KEY (id);


--
-- Name: feature_rollout_events feature_rollout_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollout_events
    ADD CONSTRAINT feature_rollout_events_pkey PRIMARY KEY (id);


--
-- Name: feature_rollout_owners feature_rollout_owners_feature_code_owner_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollout_owners
    ADD CONSTRAINT feature_rollout_owners_feature_code_owner_id_unique UNIQUE (feature_code, owner_id);


--
-- Name: feature_rollout_owners feature_rollout_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollout_owners
    ADD CONSTRAINT feature_rollout_owners_pkey PRIMARY KEY (id);


--
-- Name: feature_rollouts feature_rollouts_feature_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollouts
    ADD CONSTRAINT feature_rollouts_feature_code_unique UNIQUE (feature_code);


--
-- Name: feature_rollouts feature_rollouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollouts
    ADD CONSTRAINT feature_rollouts_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_uq UNIQUE (file_id, folder_id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: files_related_mph files_related_mph_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_pkey PRIMARY KEY (id);


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk fiscal_attempts_fk_checkout_attempt_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT fiscal_attempts_fk_checkout_attempt_lnk_pkey PRIMARY KEY (id);


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk fiscal_attempts_fk_checkout_attempt_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT fiscal_attempts_fk_checkout_attempt_lnk_uq UNIQUE (fiscal_attempt_id, checkout_attempt_id);


--
-- Name: fiscal_attempts_fk_user_lnk fiscal_attempts_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_user_lnk
    ADD CONSTRAINT fiscal_attempts_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: fiscal_attempts_fk_user_lnk fiscal_attempts_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_user_lnk
    ADD CONSTRAINT fiscal_attempts_fk_user_lnk_uq UNIQUE (fiscal_attempt_id, user_id);


--
-- Name: fiscal_attempts fiscal_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts
    ADD CONSTRAINT fiscal_attempts_pkey PRIMARY KEY (id);


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk fiscal_correction_attempts_fk_checkout_attempt_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_checkout_attempt_lnk_pkey PRIMARY KEY (id);


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk fiscal_correction_attempts_fk_checkout_attempt_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_checkout_attempt_lnk_uq UNIQUE (fiscal_correction_attempt_id, checkout_attempt_id);


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk fiscal_correction_attempts_fk_fiscal_attempt_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_fiscal_attempt_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_fiscal_attempt_lnk_pkey PRIMARY KEY (id);


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk fiscal_correction_attempts_fk_fiscal_attempt_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_fiscal_attempt_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_fiscal_attempt_lnk_uq UNIQUE (fiscal_correction_attempt_id, fiscal_attempt_id);


--
-- Name: fiscal_correction_attempts_fk_user_lnk fiscal_correction_attempts_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_user_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: fiscal_correction_attempts_fk_user_lnk fiscal_correction_attempts_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_user_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_user_lnk_uq UNIQUE (fiscal_correction_attempt_id, user_id);


--
-- Name: fiscal_correction_attempts fiscal_correction_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts
    ADD CONSTRAINT fiscal_correction_attempts_pkey PRIMARY KEY (id);


--
-- Name: hardware_endpoints_fk_pos_device_lnk hardware_endpoints_fk_pos_device_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_pos_device_lnk
    ADD CONSTRAINT hardware_endpoints_fk_pos_device_lnk_pkey PRIMARY KEY (id);


--
-- Name: hardware_endpoints_fk_pos_device_lnk hardware_endpoints_fk_pos_device_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_pos_device_lnk
    ADD CONSTRAINT hardware_endpoints_fk_pos_device_lnk_uq UNIQUE (hardware_endpoint_id, pos_device_id);


--
-- Name: hardware_endpoints_fk_user_lnk hardware_endpoints_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_user_lnk
    ADD CONSTRAINT hardware_endpoints_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: hardware_endpoints_fk_user_lnk hardware_endpoints_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_user_lnk
    ADD CONSTRAINT hardware_endpoints_fk_user_lnk_uq UNIQUE (hardware_endpoint_id, user_id);


--
-- Name: hardware_endpoints hardware_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints
    ADD CONSTRAINT hardware_endpoints_pkey PRIMARY KEY (id);


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk hardware_jobs_fk_checkout_attempt_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_checkout_attempt_lnk
    ADD CONSTRAINT hardware_jobs_fk_checkout_attempt_lnk_pkey PRIMARY KEY (id);


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk hardware_jobs_fk_checkout_attempt_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_checkout_attempt_lnk
    ADD CONSTRAINT hardware_jobs_fk_checkout_attempt_lnk_uq UNIQUE (hardware_job_id, checkout_attempt_id);


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk hardware_jobs_fk_hardware_endpoint_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_hardware_endpoint_lnk
    ADD CONSTRAINT hardware_jobs_fk_hardware_endpoint_lnk_pkey PRIMARY KEY (id);


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk hardware_jobs_fk_hardware_endpoint_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_hardware_endpoint_lnk
    ADD CONSTRAINT hardware_jobs_fk_hardware_endpoint_lnk_uq UNIQUE (hardware_job_id, hardware_endpoint_id);


--
-- Name: hardware_jobs_fk_pos_device_lnk hardware_jobs_fk_pos_device_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_pos_device_lnk
    ADD CONSTRAINT hardware_jobs_fk_pos_device_lnk_pkey PRIMARY KEY (id);


--
-- Name: hardware_jobs_fk_pos_device_lnk hardware_jobs_fk_pos_device_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_pos_device_lnk
    ADD CONSTRAINT hardware_jobs_fk_pos_device_lnk_uq UNIQUE (hardware_job_id, pos_device_id);


--
-- Name: hardware_jobs_fk_user_lnk hardware_jobs_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_user_lnk
    ADD CONSTRAINT hardware_jobs_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: hardware_jobs_fk_user_lnk hardware_jobs_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_user_lnk
    ADD CONSTRAINT hardware_jobs_fk_user_lnk_uq UNIQUE (hardware_job_id, user_id);


--
-- Name: hardware_jobs hardware_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs
    ADD CONSTRAINT hardware_jobs_pkey PRIMARY KEY (id);


--
-- Name: i18n_locale i18n_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_pkey PRIMARY KEY (id);


--
-- Name: pos_jobs idx_pos_jobs_event_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs
    ADD CONSTRAINT idx_pos_jobs_event_id_unique UNIQUE (event_id);


--
-- Name: ingredients_fk_user_lnk ingredients_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_fk_user_lnk
    ADD CONSTRAINT ingredients_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: ingredients_fk_user_lnk ingredients_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_fk_user_lnk
    ADD CONSTRAINT ingredients_fk_user_lnk_uq UNIQUE (ingredient_id, user_id);


--
-- Name: ingredients ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_pkey PRIMARY KEY (id);


--
-- Name: ingredients ingredients_table_order_public_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_table_order_public_id_unique UNIQUE (table_order_public_id);


--
-- Name: inventory_alerts_acknowledged_by_lnk inventory_alerts_acknowledged_by_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_acknowledged_by_lnk
    ADD CONSTRAINT inventory_alerts_acknowledged_by_lnk_pkey PRIMARY KEY (id);


--
-- Name: inventory_alerts_acknowledged_by_lnk inventory_alerts_acknowledged_by_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_acknowledged_by_lnk
    ADD CONSTRAINT inventory_alerts_acknowledged_by_lnk_uq UNIQUE (inventory_alert_id, user_id);


--
-- Name: inventory_alerts_fk_user_lnk inventory_alerts_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_fk_user_lnk
    ADD CONSTRAINT inventory_alerts_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: inventory_alerts_fk_user_lnk inventory_alerts_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_fk_user_lnk
    ADD CONSTRAINT inventory_alerts_fk_user_lnk_uq UNIQUE (inventory_alert_id, user_id);


--
-- Name: inventory_alerts inventory_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts
    ADD CONSTRAINT inventory_alerts_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements_fk_bar_shift_lnk inventory_movements_fk_bar_shift_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_bar_shift_lnk
    ADD CONSTRAINT inventory_movements_fk_bar_shift_lnk_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements_fk_bar_shift_lnk inventory_movements_fk_bar_shift_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_bar_shift_lnk
    ADD CONSTRAINT inventory_movements_fk_bar_shift_lnk_uq UNIQUE (inventory_movement_id, bar_shift_id);


--
-- Name: inventory_movements_fk_ingredient_lnk inventory_movements_fk_ingredient_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_ingredient_lnk
    ADD CONSTRAINT inventory_movements_fk_ingredient_lnk_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements_fk_ingredient_lnk inventory_movements_fk_ingredient_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_ingredient_lnk
    ADD CONSTRAINT inventory_movements_fk_ingredient_lnk_uq UNIQUE (inventory_movement_id, ingredient_id);


--
-- Name: inventory_movements_fk_order_item_lnk inventory_movements_fk_order_item_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_item_lnk
    ADD CONSTRAINT inventory_movements_fk_order_item_lnk_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements_fk_order_item_lnk inventory_movements_fk_order_item_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_item_lnk
    ADD CONSTRAINT inventory_movements_fk_order_item_lnk_uq UNIQUE (inventory_movement_id, order_item_id);


--
-- Name: inventory_movements_fk_order_lnk inventory_movements_fk_order_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_lnk
    ADD CONSTRAINT inventory_movements_fk_order_lnk_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements_fk_order_lnk inventory_movements_fk_order_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_lnk
    ADD CONSTRAINT inventory_movements_fk_order_lnk_uq UNIQUE (inventory_movement_id, order_id);


--
-- Name: inventory_movements_fk_restock_order_lnk inventory_movements_fk_restock_order_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_restock_order_lnk
    ADD CONSTRAINT inventory_movements_fk_restock_order_lnk_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements_fk_restock_order_lnk inventory_movements_fk_restock_order_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_restock_order_lnk
    ADD CONSTRAINT inventory_movements_fk_restock_order_lnk_uq UNIQUE (inventory_movement_id, restock_order_id);


--
-- Name: inventory_movements_fk_user_lnk inventory_movements_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_user_lnk
    ADD CONSTRAINT inventory_movements_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements_fk_user_lnk inventory_movements_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_user_lnk
    ADD CONSTRAINT inventory_movements_fk_user_lnk_uq UNIQUE (inventory_movement_id, user_id);


--
-- Name: inventory_movements inventory_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_pkey PRIMARY KEY (id);


--
-- Name: menu_element_stats_fk_element_lnk menu_element_stats_fk_element_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_element_lnk
    ADD CONSTRAINT menu_element_stats_fk_element_lnk_pkey PRIMARY KEY (id);


--
-- Name: menu_element_stats_fk_element_lnk menu_element_stats_fk_element_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_element_lnk
    ADD CONSTRAINT menu_element_stats_fk_element_lnk_uq UNIQUE (menu_element_stat_id, element_id);


--
-- Name: menu_element_stats_fk_user_lnk menu_element_stats_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_user_lnk
    ADD CONSTRAINT menu_element_stats_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: menu_element_stats_fk_user_lnk menu_element_stats_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_user_lnk
    ADD CONSTRAINT menu_element_stats_fk_user_lnk_uq UNIQUE (menu_element_stat_id, user_id);


--
-- Name: menu_element_stats menu_element_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats
    ADD CONSTRAINT menu_element_stats_pkey PRIMARY KEY (id);


--
-- Name: menu_import_jobs_fk_user_lnk menu_import_jobs_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs_fk_user_lnk
    ADD CONSTRAINT menu_import_jobs_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: menu_import_jobs_fk_user_lnk menu_import_jobs_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs_fk_user_lnk
    ADD CONSTRAINT menu_import_jobs_fk_user_lnk_uq UNIQUE (menu_import_job_id, user_id);


--
-- Name: menu_import_jobs menu_import_jobs_idempotency_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs
    ADD CONSTRAINT menu_import_jobs_idempotency_uq UNIQUE (idempotency_key);


--
-- Name: menu_import_jobs menu_import_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs
    ADD CONSTRAINT menu_import_jobs_pkey PRIMARY KEY (id);


--
-- Name: menu_import_leases menu_import_leases_lane_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_leases
    ADD CONSTRAINT menu_import_leases_lane_uq UNIQUE (lane);


--
-- Name: menu_import_leases menu_import_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_leases
    ADD CONSTRAINT menu_import_leases_pkey PRIMARY KEY (id);


--
-- Name: menus_fk_elements_lnk menus_fk_elements_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_elements_lnk
    ADD CONSTRAINT menus_fk_elements_lnk_pkey PRIMARY KEY (id);


--
-- Name: menus_fk_elements_lnk menus_fk_elements_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_elements_lnk
    ADD CONSTRAINT menus_fk_elements_lnk_uq UNIQUE (menu_id, element_id);


--
-- Name: menus_fk_user_lnk menus_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_user_lnk
    ADD CONSTRAINT menus_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: menus_fk_user_lnk menus_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_user_lnk
    ADD CONSTRAINT menus_fk_user_lnk_uq UNIQUE (menu_id, user_id);


--
-- Name: menus menus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_pkey PRIMARY KEY (id);


--
-- Name: order_archives_fk_user_lnk order_archives_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives_fk_user_lnk
    ADD CONSTRAINT order_archives_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: order_archives_fk_user_lnk order_archives_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives_fk_user_lnk
    ADD CONSTRAINT order_archives_fk_user_lnk_uq UNIQUE (order_archive_id, user_id);


--
-- Name: order_archives order_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives
    ADD CONSTRAINT order_archives_pkey PRIMARY KEY (id);


--
-- Name: order_item_addons_fk_ingredient_lnk order_item_addons_fk_ingredient_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_ingredient_lnk
    ADD CONSTRAINT order_item_addons_fk_ingredient_lnk_pkey PRIMARY KEY (id);


--
-- Name: order_item_addons_fk_ingredient_lnk order_item_addons_fk_ingredient_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_ingredient_lnk
    ADD CONSTRAINT order_item_addons_fk_ingredient_lnk_uq UNIQUE (order_item_addon_id, ingredient_id);


--
-- Name: order_item_addons_fk_order_item_lnk order_item_addons_fk_order_item_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_order_item_lnk
    ADD CONSTRAINT order_item_addons_fk_order_item_lnk_pkey PRIMARY KEY (id);


--
-- Name: order_item_addons_fk_order_item_lnk order_item_addons_fk_order_item_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_order_item_lnk
    ADD CONSTRAINT order_item_addons_fk_order_item_lnk_uq UNIQUE (order_item_addon_id, order_item_id);


--
-- Name: order_item_addons order_item_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons
    ADD CONSTRAINT order_item_addons_pkey PRIMARY KEY (id);


--
-- Name: order_items_fk_element_lnk order_items_fk_element_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_element_lnk
    ADD CONSTRAINT order_items_fk_element_lnk_pkey PRIMARY KEY (id);


--
-- Name: order_items_fk_element_lnk order_items_fk_element_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_element_lnk
    ADD CONSTRAINT order_items_fk_element_lnk_uq UNIQUE (order_item_id, element_id);


--
-- Name: order_items_fk_order_lnk order_items_fk_order_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_order_lnk
    ADD CONSTRAINT order_items_fk_order_lnk_pkey PRIMARY KEY (id);


--
-- Name: order_items_fk_order_lnk order_items_fk_order_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_order_lnk
    ADD CONSTRAINT order_items_fk_order_lnk_uq UNIQUE (order_item_id, order_id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_table_order_public_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_table_order_public_id_unique UNIQUE (table_order_public_id);


--
-- Name: order_realtime_events order_realtime_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_realtime_events
    ADD CONSTRAINT order_realtime_events_pkey PRIMARY KEY (id);


--
-- Name: orders_fk_table_lnk orders_fk_table_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_table_lnk
    ADD CONSTRAINT orders_fk_table_lnk_pkey PRIMARY KEY (id);


--
-- Name: orders_fk_table_lnk orders_fk_table_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_table_lnk
    ADD CONSTRAINT orders_fk_table_lnk_uq UNIQUE (order_id, table_id);


--
-- Name: orders_fk_user_lnk orders_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_user_lnk
    ADD CONSTRAINT orders_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: orders_fk_user_lnk orders_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_user_lnk
    ADD CONSTRAINT orders_fk_user_lnk_uq UNIQUE (order_id, user_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_takeaway_idempotency_key_hash_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_takeaway_idempotency_key_hash_uq UNIQUE (takeaway_idempotency_key_hash);


--
-- Name: owner_feature_grant_events owner_feature_grant_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_feature_grant_events
    ADD CONSTRAINT owner_feature_grant_events_pkey PRIMARY KEY (id);


--
-- Name: owner_feature_grants owner_feature_grants_owner_feature_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_feature_grants
    ADD CONSTRAINT owner_feature_grants_owner_feature_unique UNIQUE (owner_id, feature_code);


--
-- Name: owner_feature_grants owner_feature_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_feature_grants
    ADD CONSTRAINT owner_feature_grants_pkey PRIMARY KEY (id);


--
-- Name: payment_attempts_fk_checkout_attempt_lnk payment_attempts_fk_checkout_attempt_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT payment_attempts_fk_checkout_attempt_lnk_pkey PRIMARY KEY (id);


--
-- Name: payment_attempts_fk_checkout_attempt_lnk payment_attempts_fk_checkout_attempt_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT payment_attempts_fk_checkout_attempt_lnk_uq UNIQUE (payment_attempt_id, checkout_attempt_id);


--
-- Name: payment_attempts_fk_user_lnk payment_attempts_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_user_lnk
    ADD CONSTRAINT payment_attempts_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: payment_attempts_fk_user_lnk payment_attempts_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_user_lnk
    ADD CONSTRAINT payment_attempts_fk_user_lnk_uq UNIQUE (payment_attempt_id, user_id);


--
-- Name: payment_attempts payment_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts
    ADD CONSTRAINT payment_attempts_pkey PRIMARY KEY (id);


--
-- Name: pos_devices_fk_user_lnk pos_devices_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices_fk_user_lnk
    ADD CONSTRAINT pos_devices_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: pos_devices_fk_user_lnk pos_devices_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices_fk_user_lnk
    ADD CONSTRAINT pos_devices_fk_user_lnk_uq UNIQUE (pos_device_id, user_id);


--
-- Name: pos_devices pos_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices
    ADD CONSTRAINT pos_devices_pkey PRIMARY KEY (id);


--
-- Name: pos_jobs_fk_device_lnk pos_jobs_fk_device_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_device_lnk
    ADD CONSTRAINT pos_jobs_fk_device_lnk_pkey PRIMARY KEY (id);


--
-- Name: pos_jobs_fk_device_lnk pos_jobs_fk_device_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_device_lnk
    ADD CONSTRAINT pos_jobs_fk_device_lnk_uq UNIQUE (pos_job_id, pos_device_id);


--
-- Name: pos_jobs_fk_order_lnk pos_jobs_fk_order_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_order_lnk
    ADD CONSTRAINT pos_jobs_fk_order_lnk_pkey PRIMARY KEY (id);


--
-- Name: pos_jobs_fk_order_lnk pos_jobs_fk_order_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_order_lnk
    ADD CONSTRAINT pos_jobs_fk_order_lnk_uq UNIQUE (pos_job_id, order_id);


--
-- Name: pos_jobs_fk_user_lnk pos_jobs_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_user_lnk
    ADD CONSTRAINT pos_jobs_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: pos_jobs_fk_user_lnk pos_jobs_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_user_lnk
    ADD CONSTRAINT pos_jobs_fk_user_lnk_uq UNIQUE (pos_job_id, user_id);


--
-- Name: pos_jobs pos_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs
    ADD CONSTRAINT pos_jobs_pkey PRIMARY KEY (id);


--
-- Name: pos_pairing_tokens_fk_user_lnk pos_pairing_tokens_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens_fk_user_lnk
    ADD CONSTRAINT pos_pairing_tokens_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: pos_pairing_tokens_fk_user_lnk pos_pairing_tokens_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens_fk_user_lnk
    ADD CONSTRAINT pos_pairing_tokens_fk_user_lnk_uq UNIQUE (pos_pairing_token_id, user_id);


--
-- Name: pos_pairing_tokens pos_pairing_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens
    ADD CONSTRAINT pos_pairing_tokens_pkey PRIMARY KEY (id);


--
-- Name: reservations_fk_order_lnk reservations_fk_order_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_order_lnk
    ADD CONSTRAINT reservations_fk_order_lnk_pkey PRIMARY KEY (id);


--
-- Name: reservations_fk_order_lnk reservations_fk_order_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_order_lnk
    ADD CONSTRAINT reservations_fk_order_lnk_uq UNIQUE (reservation_id, order_id);


--
-- Name: reservations_fk_table_lnk reservations_fk_table_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_table_lnk
    ADD CONSTRAINT reservations_fk_table_lnk_pkey PRIMARY KEY (id);


--
-- Name: reservations_fk_table_lnk reservations_fk_table_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_table_lnk
    ADD CONSTRAINT reservations_fk_table_lnk_uq UNIQUE (reservation_id, table_id);


--
-- Name: reservations_fk_user_lnk reservations_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_user_lnk
    ADD CONSTRAINT reservations_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: reservations_fk_user_lnk reservations_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_user_lnk
    ADD CONSTRAINT reservations_fk_user_lnk_uq UNIQUE (reservation_id, user_id);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: restaurant_category_routing restaurant_category_routing_owner_category_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_category_routing
    ADD CONSTRAINT restaurant_category_routing_owner_category_unique UNIQUE (owner_id, category_key);


--
-- Name: restaurant_category_routing restaurant_category_routing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_category_routing
    ADD CONSTRAINT restaurant_category_routing_pkey PRIMARY KEY (id);


--
-- Name: restaurant_daily_stats_fk_user_lnk restaurant_daily_stats_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats_fk_user_lnk
    ADD CONSTRAINT restaurant_daily_stats_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: restaurant_daily_stats_fk_user_lnk restaurant_daily_stats_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats_fk_user_lnk
    ADD CONSTRAINT restaurant_daily_stats_fk_user_lnk_uq UNIQUE (restaurant_daily_stat_id, user_id);


--
-- Name: restaurant_daily_stats restaurant_daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats
    ADD CONSTRAINT restaurant_daily_stats_pkey PRIMARY KEY (id);


--
-- Name: restaurant_printer_configs_fk_user_lnk restaurant_printer_configs_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs_fk_user_lnk
    ADD CONSTRAINT restaurant_printer_configs_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: restaurant_printer_configs_fk_user_lnk restaurant_printer_configs_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs_fk_user_lnk
    ADD CONSTRAINT restaurant_printer_configs_fk_user_lnk_uq UNIQUE (restaurant_printer_config_id, user_id);


--
-- Name: restaurant_printer_configs restaurant_printer_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs
    ADD CONSTRAINT restaurant_printer_configs_pkey PRIMARY KEY (id);


--
-- Name: restaurant_staff restaurant_staff_owner_user_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_staff
    ADD CONSTRAINT restaurant_staff_owner_user_unique UNIQUE (owner_id, user_id);


--
-- Name: restaurant_staff restaurant_staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_staff
    ADD CONSTRAINT restaurant_staff_pkey PRIMARY KEY (id);


--
-- Name: restock_orders_fk_ingredient_lnk restock_orders_fk_ingredient_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_ingredient_lnk
    ADD CONSTRAINT restock_orders_fk_ingredient_lnk_pkey PRIMARY KEY (id);


--
-- Name: restock_orders_fk_ingredient_lnk restock_orders_fk_ingredient_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_ingredient_lnk
    ADD CONSTRAINT restock_orders_fk_ingredient_lnk_uq UNIQUE (restock_order_id, ingredient_id);


--
-- Name: restock_orders_fk_user_lnk restock_orders_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_user_lnk
    ADD CONSTRAINT restock_orders_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: restock_orders_fk_user_lnk restock_orders_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_user_lnk
    ADD CONSTRAINT restock_orders_fk_user_lnk_uq UNIQUE (restock_order_id, user_id);


--
-- Name: restock_orders restock_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders
    ADD CONSTRAINT restock_orders_pkey PRIMARY KEY (id);


--
-- Name: strapi_ai_localization_jobs strapi_ai_localization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs
    ADD CONSTRAINT strapi_ai_localization_jobs_pkey PRIMARY KEY (id);


--
-- Name: strapi_ai_metadata_jobs strapi_ai_metadata_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_ai_metadata_jobs
    ADD CONSTRAINT strapi_ai_metadata_jobs_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_uq UNIQUE (api_token_permission_id, api_token_id);


--
-- Name: strapi_api_tokens_admin_user_owner_lnk strapi_api_tokens_admin_user_owner_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens_admin_user_owner_lnk
    ADD CONSTRAINT strapi_api_tokens_admin_user_owner_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_tokens_admin_user_owner_lnk strapi_api_tokens_admin_user_owner_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens_admin_user_owner_lnk
    ADD CONSTRAINT strapi_api_tokens_admin_user_owner_lnk_uq UNIQUE (api_token_id, user_id);


--
-- Name: strapi_api_tokens strapi_api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_core_store_settings strapi_core_store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_core_store_settings
    ADD CONSTRAINT strapi_core_store_settings_pkey PRIMARY KEY (id);


--
-- Name: strapi_database_schema strapi_database_schema_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_database_schema
    ADD CONSTRAINT strapi_database_schema_pkey PRIMARY KEY (id);


--
-- Name: strapi_history_versions strapi_history_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations_internal strapi_migrations_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_migrations_internal
    ADD CONSTRAINT strapi_migrations_internal_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations strapi_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_migrations
    ADD CONSTRAINT strapi_migrations_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions strapi_release_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_uq UNIQUE (release_action_id, release_id);


--
-- Name: strapi_releases strapi_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_pkey PRIMARY KEY (id);


--
-- Name: strapi_sessions strapi_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_uq UNIQUE (transfer_token_permission_id, transfer_token_id);


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_webhooks strapi_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_webhooks
    ADD CONSTRAINT strapi_webhooks_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows strapi_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_uq UNIQUE (workflow_id, workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_uq UNIQUE (workflow_stage_id, permission_id);


--
-- Name: strapi_workflows_stages strapi_workflows_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_uq UNIQUE (workflow_stage_id, workflow_id);


--
-- Name: suppliers_fk_user_lnk suppliers_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers_fk_user_lnk
    ADD CONSTRAINT suppliers_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: suppliers_fk_user_lnk suppliers_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers_fk_user_lnk
    ADD CONSTRAINT suppliers_fk_user_lnk_uq UNIQUE (supplier_id, user_id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: sync_events_fk_user_lnk sync_events_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events_fk_user_lnk
    ADD CONSTRAINT sync_events_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: sync_events_fk_user_lnk sync_events_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events_fk_user_lnk
    ADD CONSTRAINT sync_events_fk_user_lnk_uq UNIQUE (sync_event_id, user_id);


--
-- Name: sync_events sync_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events
    ADD CONSTRAINT sync_events_pkey PRIMARY KEY (id);


--
-- Name: table_order_access_points table_order_access_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_access_points
    ADD CONSTRAINT table_order_access_points_pkey PRIMARY KEY (id);


--
-- Name: table_order_access_points table_order_access_points_public_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_access_points
    ADD CONSTRAINT table_order_access_points_public_id_unique UNIQUE (public_id);


--
-- Name: table_order_commands table_order_commands_participant_id_operation_id_hash_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_commands
    ADD CONSTRAINT table_order_commands_participant_id_operation_id_hash_unique UNIQUE (participant_id, operation_id_hash);


--
-- Name: table_order_commands table_order_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_commands
    ADD CONSTRAINT table_order_commands_pkey PRIMARY KEY (id);


--
-- Name: table_order_participants table_order_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_participants
    ADD CONSTRAINT table_order_participants_pkey PRIMARY KEY (id);


--
-- Name: table_order_participants table_order_participants_token_hash_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_participants
    ADD CONSTRAINT table_order_participants_token_hash_unique UNIQUE (token_hash);


--
-- Name: table_order_rate_limits table_order_rate_limits_bucket_window_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_rate_limits
    ADD CONSTRAINT table_order_rate_limits_bucket_window_unique UNIQUE (bucket_key, window_start);


--
-- Name: table_order_rate_limits table_order_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_rate_limits
    ADD CONSTRAINT table_order_rate_limits_pkey PRIMARY KEY (id);


--
-- Name: table_order_realtime_events table_order_realtime_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_realtime_events
    ADD CONSTRAINT table_order_realtime_events_pkey PRIMARY KEY (id);


--
-- Name: table_order_service_requests table_order_service_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_service_requests
    ADD CONSTRAINT table_order_service_requests_pkey PRIMARY KEY (id);


--
-- Name: table_order_service_requests table_order_service_requests_public_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_service_requests
    ADD CONSTRAINT table_order_service_requests_public_id_unique UNIQUE (public_id);


--
-- Name: table_order_sessions table_order_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_sessions
    ADD CONSTRAINT table_order_sessions_pkey PRIMARY KEY (id);


--
-- Name: table_order_sessions table_order_sessions_public_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_sessions
    ADD CONSTRAINT table_order_sessions_public_id_unique UNIQUE (public_id);


--
-- Name: tables_fk_origins_lnk tables_fk_origins_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_origins_lnk
    ADD CONSTRAINT tables_fk_origins_lnk_pkey PRIMARY KEY (id);


--
-- Name: tables_fk_origins_lnk tables_fk_origins_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_origins_lnk
    ADD CONSTRAINT tables_fk_origins_lnk_uq UNIQUE (table_id, inv_table_id);


--
-- Name: tables_fk_user_lnk tables_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_user_lnk
    ADD CONSTRAINT tables_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: tables_fk_user_lnk tables_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_user_lnk
    ADD CONSTRAINT tables_fk_user_lnk_uq UNIQUE (table_id, user_id);


--
-- Name: tables_fk_zone_lnk tables_fk_zone_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_zone_lnk
    ADD CONSTRAINT tables_fk_zone_lnk_pkey PRIMARY KEY (id);


--
-- Name: tables_fk_zone_lnk tables_fk_zone_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_zone_lnk
    ADD CONSTRAINT tables_fk_zone_lnk_uq UNIQUE (table_id, zone_id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: takeaway_time_proposals takeaway_proposal_nonce_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals
    ADD CONSTRAINT takeaway_proposal_nonce_uq UNIQUE (response_nonce);


--
-- Name: takeaway_time_proposals takeaway_proposal_order_version_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals
    ADD CONSTRAINT takeaway_proposal_order_version_uq UNIQUE (order_document_id, version);


--
-- Name: takeaway_time_proposals_fk_order_lnk takeaway_time_proposals_fk_order_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_order_lnk
    ADD CONSTRAINT takeaway_time_proposals_fk_order_lnk_pkey PRIMARY KEY (id);


--
-- Name: takeaway_time_proposals_fk_order_lnk takeaway_time_proposals_fk_order_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_order_lnk
    ADD CONSTRAINT takeaway_time_proposals_fk_order_lnk_uq UNIQUE (takeaway_time_proposal_id, order_id);


--
-- Name: takeaway_time_proposals_fk_user_lnk takeaway_time_proposals_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_user_lnk
    ADD CONSTRAINT takeaway_time_proposals_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: takeaway_time_proposals_fk_user_lnk takeaway_time_proposals_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_user_lnk
    ADD CONSTRAINT takeaway_time_proposals_fk_user_lnk_uq UNIQUE (takeaway_time_proposal_id, user_id);


--
-- Name: takeaway_time_proposals takeaway_time_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals
    ADD CONSTRAINT takeaway_time_proposals_pkey PRIMARY KEY (id);


--
-- Name: up_permissions up_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: up_roles up_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_pkey PRIMARY KEY (id);


--
-- Name: up_users_fk_owner_lnk up_users_fk_owner_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_fk_owner_lnk
    ADD CONSTRAINT up_users_fk_owner_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_users_fk_owner_lnk up_users_fk_owner_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_fk_owner_lnk
    ADD CONSTRAINT up_users_fk_owner_lnk_uq UNIQUE (user_id, inv_user_id);


--
-- Name: up_users up_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_pkey PRIMARY KEY (id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_uq UNIQUE (folder_id, inv_folder_id);


--
-- Name: upload_folders upload_folders_path_id_index; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_id_index UNIQUE (path_id);


--
-- Name: upload_folders upload_folders_path_index; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_index UNIQUE (path);


--
-- Name: upload_folders upload_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_pkey PRIMARY KEY (id);


--
-- Name: website_configs_fk_user_lnk website_configs_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs_fk_user_lnk
    ADD CONSTRAINT website_configs_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: website_configs_fk_user_lnk website_configs_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs_fk_user_lnk
    ADD CONSTRAINT website_configs_fk_user_lnk_uq UNIQUE (website_config_id, user_id);


--
-- Name: website_configs website_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs
    ADD CONSTRAINT website_configs_pkey PRIMARY KEY (id);


--
-- Name: zones_fk_user_lnk zones_fk_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones_fk_user_lnk
    ADD CONSTRAINT zones_fk_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: zones_fk_user_lnk zones_fk_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones_fk_user_lnk
    ADD CONSTRAINT zones_fk_user_lnk_uq UNIQUE (zone_id, user_id);


--
-- Name: zones zones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones
    ADD CONSTRAINT zones_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_api_token_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_api_token_lnk_fk ON public.admin_permissions_api_token_lnk USING btree (permission_id);


--
-- Name: admin_permissions_api_token_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_api_token_lnk_ifk ON public.admin_permissions_api_token_lnk USING btree (api_token_id);


--
-- Name: admin_permissions_api_token_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_api_token_lnk_oifk ON public.admin_permissions_api_token_lnk USING btree (permission_ord);


--
-- Name: admin_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_created_by_id_fk ON public.admin_permissions USING btree (created_by_id);


--
-- Name: admin_permissions_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_documents_idx ON public.admin_permissions USING btree (document_id, locale, published_at);


--
-- Name: admin_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_role_lnk_fk ON public.admin_permissions_role_lnk USING btree (permission_id);


--
-- Name: admin_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_role_lnk_ifk ON public.admin_permissions_role_lnk USING btree (role_id);


--
-- Name: admin_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_role_lnk_oifk ON public.admin_permissions_role_lnk USING btree (permission_ord);


--
-- Name: admin_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_permissions_updated_by_id_fk ON public.admin_permissions USING btree (updated_by_id);


--
-- Name: admin_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_roles_created_by_id_fk ON public.admin_roles USING btree (created_by_id);


--
-- Name: admin_roles_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_roles_documents_idx ON public.admin_roles USING btree (document_id, locale, published_at);


--
-- Name: admin_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_roles_updated_by_id_fk ON public.admin_roles USING btree (updated_by_id);


--
-- Name: admin_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_users_created_by_id_fk ON public.admin_users USING btree (created_by_id);


--
-- Name: admin_users_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_users_documents_idx ON public.admin_users USING btree (document_id, locale, published_at);


--
-- Name: admin_users_roles_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_users_roles_lnk_fk ON public.admin_users_roles_lnk USING btree (user_id);


--
-- Name: admin_users_roles_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_users_roles_lnk_ifk ON public.admin_users_roles_lnk USING btree (role_id);


--
-- Name: admin_users_roles_lnk_ofk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_users_roles_lnk_ofk ON public.admin_users_roles_lnk USING btree (role_ord);


--
-- Name: admin_users_roles_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_users_roles_lnk_oifk ON public.admin_users_roles_lnk USING btree (user_ord);


--
-- Name: admin_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_users_updated_by_id_fk ON public.admin_users USING btree (updated_by_id);


--
-- Name: audit_hardware_events_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_hardware_events_created_by_id_fk ON public.audit_hardware_events USING btree (created_by_id);


--
-- Name: audit_hardware_events_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_hardware_events_documents_idx ON public.audit_hardware_events USING btree (document_id, locale, published_at);


--
-- Name: audit_hardware_events_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_hardware_events_updated_by_id_fk ON public.audit_hardware_events USING btree (updated_by_id);


--
-- Name: bar_shifts_closed_by_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_closed_by_lnk_fk ON public.bar_shifts_closed_by_lnk USING btree (bar_shift_id);


--
-- Name: bar_shifts_closed_by_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_closed_by_lnk_ifk ON public.bar_shifts_closed_by_lnk USING btree (user_id);


--
-- Name: bar_shifts_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_created_by_id_fk ON public.bar_shifts USING btree (created_by_id);


--
-- Name: bar_shifts_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_documents_idx ON public.bar_shifts USING btree (document_id, locale, published_at);


--
-- Name: bar_shifts_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_fk_user_lnk_fk ON public.bar_shifts_fk_user_lnk USING btree (bar_shift_id);


--
-- Name: bar_shifts_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_fk_user_lnk_ifk ON public.bar_shifts_fk_user_lnk USING btree (user_id);


--
-- Name: bar_shifts_opened_by_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_opened_by_lnk_fk ON public.bar_shifts_opened_by_lnk USING btree (bar_shift_id);


--
-- Name: bar_shifts_opened_by_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_opened_by_lnk_ifk ON public.bar_shifts_opened_by_lnk USING btree (user_id);


--
-- Name: bar_shifts_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bar_shifts_updated_by_id_fk ON public.bar_shifts USING btree (updated_by_id);


--
-- Name: checkout_attempts_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_attempts_created_by_id_fk ON public.checkout_attempts USING btree (created_by_id);


--
-- Name: checkout_attempts_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_attempts_documents_idx ON public.checkout_attempts USING btree (document_id, locale, published_at);


--
-- Name: checkout_attempts_fk_order_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_attempts_fk_order_lnk_fk ON public.checkout_attempts_fk_order_lnk USING btree (checkout_attempt_id);


--
-- Name: checkout_attempts_fk_order_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_attempts_fk_order_lnk_ifk ON public.checkout_attempts_fk_order_lnk USING btree (order_id);


--
-- Name: checkout_attempts_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_attempts_fk_user_lnk_fk ON public.checkout_attempts_fk_user_lnk USING btree (checkout_attempt_id);


--
-- Name: checkout_attempts_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_attempts_fk_user_lnk_ifk ON public.checkout_attempts_fk_user_lnk USING btree (user_id);


--
-- Name: checkout_attempts_status_expires_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_attempts_status_expires_idx ON public.checkout_attempts USING btree (status, expires_at);


--
-- Name: checkout_attempts_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_attempts_updated_by_id_fk ON public.checkout_attempts USING btree (updated_by_id);


--
-- Name: ct_idempotency_keys_claim_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ct_idempotency_keys_claim_idx ON public.ct_idempotency_keys USING btree (state, claimed_at);


--
-- Name: ct_idempotency_keys_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ct_idempotency_keys_expires_at_idx ON public.ct_idempotency_keys USING btree (expires_at);


--
-- Name: customer_messages_claim_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_claim_idx ON public.customer_messages USING btree (status, claimed_at);


--
-- Name: customer_messages_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_created_by_id_fk ON public.customer_messages USING btree (created_by_id);


--
-- Name: customer_messages_delivery_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_delivery_idx ON public.customer_messages USING btree (status, next_attempt_at);


--
-- Name: customer_messages_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_documents_idx ON public.customer_messages USING btree (document_id, locale, published_at);


--
-- Name: customer_messages_fk_order_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_fk_order_lnk_fk ON public.customer_messages_fk_order_lnk USING btree (customer_message_id);


--
-- Name: customer_messages_fk_order_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_fk_order_lnk_ifk ON public.customer_messages_fk_order_lnk USING btree (order_id);


--
-- Name: customer_messages_fk_time_proposal_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_fk_time_proposal_lnk_fk ON public.customer_messages_fk_time_proposal_lnk USING btree (customer_message_id);


--
-- Name: customer_messages_fk_time_proposal_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_fk_time_proposal_lnk_ifk ON public.customer_messages_fk_time_proposal_lnk USING btree (takeaway_time_proposal_id);


--
-- Name: customer_messages_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_fk_user_lnk_fk ON public.customer_messages_fk_user_lnk USING btree (customer_message_id);


--
-- Name: customer_messages_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_fk_user_lnk_ifk ON public.customer_messages_fk_user_lnk USING btree (user_id);


--
-- Name: customer_messages_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_order_idx ON public.customer_messages USING btree (order_document_id);


--
-- Name: customer_messages_proposal_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_proposal_idx ON public.customer_messages USING btree (proposal_document_id, status);


--
-- Name: customer_messages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_messages_updated_by_id_fk ON public.customer_messages USING btree (updated_by_id);


--
-- Name: element_ingredients_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_created_by_id_fk ON public.element_ingredients USING btree (created_by_id);


--
-- Name: element_ingredients_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_documents_idx ON public.element_ingredients USING btree (document_id, locale, published_at);


--
-- Name: element_ingredients_fk_element_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_fk_element_lnk_fk ON public.element_ingredients_fk_element_lnk USING btree (element_ingredient_id);


--
-- Name: element_ingredients_fk_element_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_fk_element_lnk_ifk ON public.element_ingredients_fk_element_lnk USING btree (element_id);


--
-- Name: element_ingredients_fk_element_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_fk_element_lnk_oifk ON public.element_ingredients_fk_element_lnk USING btree (element_ingredient_ord);


--
-- Name: element_ingredients_fk_ingredient_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_fk_ingredient_lnk_fk ON public.element_ingredients_fk_ingredient_lnk USING btree (element_ingredient_id);


--
-- Name: element_ingredients_fk_ingredient_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_fk_ingredient_lnk_ifk ON public.element_ingredients_fk_ingredient_lnk USING btree (ingredient_id);


--
-- Name: element_ingredients_fk_ingredient_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_fk_ingredient_lnk_oifk ON public.element_ingredients_fk_ingredient_lnk USING btree (element_ingredient_ord);


--
-- Name: element_ingredients_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX element_ingredients_updated_by_id_fk ON public.element_ingredients USING btree (updated_by_id);


--
-- Name: elements_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX elements_created_by_id_fk ON public.elements USING btree (created_by_id);


--
-- Name: elements_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX elements_documents_idx ON public.elements USING btree (document_id, locale, published_at);


--
-- Name: elements_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX elements_fk_user_lnk_fk ON public.elements_fk_user_lnk USING btree (element_id);


--
-- Name: elements_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX elements_fk_user_lnk_ifk ON public.elements_fk_user_lnk USING btree (user_id);


--
-- Name: elements_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX elements_updated_by_id_fk ON public.elements USING btree (updated_by_id);


--
-- Name: feature_rollout_events_feature_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feature_rollout_events_feature_idx ON public.feature_rollout_events USING btree (feature_code, created_at);


--
-- Name: files_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_created_by_id_fk ON public.files USING btree (created_by_id);


--
-- Name: files_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_documents_idx ON public.files USING btree (document_id, locale, published_at);


--
-- Name: files_folder_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_folder_lnk_fk ON public.files_folder_lnk USING btree (file_id);


--
-- Name: files_folder_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_folder_lnk_ifk ON public.files_folder_lnk USING btree (folder_id);


--
-- Name: files_folder_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_folder_lnk_oifk ON public.files_folder_lnk USING btree (file_ord);


--
-- Name: files_related_mph_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_related_mph_fk ON public.files_related_mph USING btree (file_id);


--
-- Name: files_related_mph_idix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_related_mph_idix ON public.files_related_mph USING btree (related_id);


--
-- Name: files_related_mph_oidx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_related_mph_oidx ON public.files_related_mph USING btree ("order");


--
-- Name: files_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX files_updated_by_id_fk ON public.files USING btree (updated_by_id);


--
-- Name: fiscal_attempts_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_attempts_created_by_id_fk ON public.fiscal_attempts USING btree (created_by_id);


--
-- Name: fiscal_attempts_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_attempts_documents_idx ON public.fiscal_attempts USING btree (document_id, locale, published_at);


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_attempts_fk_checkout_attempt_lnk_fk ON public.fiscal_attempts_fk_checkout_attempt_lnk USING btree (fiscal_attempt_id);


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_attempts_fk_checkout_attempt_lnk_ifk ON public.fiscal_attempts_fk_checkout_attempt_lnk USING btree (checkout_attempt_id);


--
-- Name: fiscal_attempts_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_attempts_fk_user_lnk_fk ON public.fiscal_attempts_fk_user_lnk USING btree (fiscal_attempt_id);


--
-- Name: fiscal_attempts_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_attempts_fk_user_lnk_ifk ON public.fiscal_attempts_fk_user_lnk USING btree (user_id);


--
-- Name: fiscal_attempts_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_attempts_updated_by_id_fk ON public.fiscal_attempts USING btree (updated_by_id);


--
-- Name: fiscal_correction_attempts_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_created_by_id_fk ON public.fiscal_correction_attempts USING btree (created_by_id);


--
-- Name: fiscal_correction_attempts_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_documents_idx ON public.fiscal_correction_attempts USING btree (document_id, locale, published_at);


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_fk_checkout_attempt_lnk_fk ON public.fiscal_correction_attempts_fk_checkout_attempt_lnk USING btree (fiscal_correction_attempt_id);


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_fk_checkout_attempt_lnk_ifk ON public.fiscal_correction_attempts_fk_checkout_attempt_lnk USING btree (checkout_attempt_id);


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_fk_fiscal_attempt_lnk_fk ON public.fiscal_correction_attempts_fk_fiscal_attempt_lnk USING btree (fiscal_correction_attempt_id);


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_fk_fiscal_attempt_lnk_ifk ON public.fiscal_correction_attempts_fk_fiscal_attempt_lnk USING btree (fiscal_attempt_id);


--
-- Name: fiscal_correction_attempts_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_fk_user_lnk_fk ON public.fiscal_correction_attempts_fk_user_lnk USING btree (fiscal_correction_attempt_id);


--
-- Name: fiscal_correction_attempts_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_fk_user_lnk_ifk ON public.fiscal_correction_attempts_fk_user_lnk USING btree (user_id);


--
-- Name: fiscal_correction_attempts_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_correction_attempts_updated_by_id_fk ON public.fiscal_correction_attempts USING btree (updated_by_id);


--
-- Name: hardware_endpoints_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_endpoints_created_by_id_fk ON public.hardware_endpoints USING btree (created_by_id);


--
-- Name: hardware_endpoints_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_endpoints_documents_idx ON public.hardware_endpoints USING btree (document_id, locale, published_at);


--
-- Name: hardware_endpoints_fk_pos_device_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_endpoints_fk_pos_device_lnk_fk ON public.hardware_endpoints_fk_pos_device_lnk USING btree (hardware_endpoint_id);


--
-- Name: hardware_endpoints_fk_pos_device_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_endpoints_fk_pos_device_lnk_ifk ON public.hardware_endpoints_fk_pos_device_lnk USING btree (pos_device_id);


--
-- Name: hardware_endpoints_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_endpoints_fk_user_lnk_fk ON public.hardware_endpoints_fk_user_lnk USING btree (hardware_endpoint_id);


--
-- Name: hardware_endpoints_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_endpoints_fk_user_lnk_ifk ON public.hardware_endpoints_fk_user_lnk USING btree (user_id);


--
-- Name: hardware_endpoints_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_endpoints_updated_by_id_fk ON public.hardware_endpoints USING btree (updated_by_id);


--
-- Name: hardware_jobs_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_created_by_id_fk ON public.hardware_jobs USING btree (created_by_id);


--
-- Name: hardware_jobs_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_documents_idx ON public.hardware_jobs USING btree (document_id, locale, published_at);


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_fk_checkout_attempt_lnk_fk ON public.hardware_jobs_fk_checkout_attempt_lnk USING btree (hardware_job_id);


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_fk_checkout_attempt_lnk_ifk ON public.hardware_jobs_fk_checkout_attempt_lnk USING btree (checkout_attempt_id);


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_fk_hardware_endpoint_lnk_fk ON public.hardware_jobs_fk_hardware_endpoint_lnk USING btree (hardware_job_id);


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_fk_hardware_endpoint_lnk_ifk ON public.hardware_jobs_fk_hardware_endpoint_lnk USING btree (hardware_endpoint_id);


--
-- Name: hardware_jobs_fk_pos_device_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_fk_pos_device_lnk_fk ON public.hardware_jobs_fk_pos_device_lnk USING btree (hardware_job_id);


--
-- Name: hardware_jobs_fk_pos_device_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_fk_pos_device_lnk_ifk ON public.hardware_jobs_fk_pos_device_lnk USING btree (pos_device_id);


--
-- Name: hardware_jobs_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_fk_user_lnk_fk ON public.hardware_jobs_fk_user_lnk USING btree (hardware_job_id);


--
-- Name: hardware_jobs_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_fk_user_lnk_ifk ON public.hardware_jobs_fk_user_lnk USING btree (user_id);


--
-- Name: hardware_jobs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hardware_jobs_updated_by_id_fk ON public.hardware_jobs USING btree (updated_by_id);


--
-- Name: i18n_locale_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX i18n_locale_created_by_id_fk ON public.i18n_locale USING btree (created_by_id);


--
-- Name: i18n_locale_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX i18n_locale_documents_idx ON public.i18n_locale USING btree (document_id, locale, published_at);


--
-- Name: i18n_locale_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX i18n_locale_updated_by_id_fk ON public.i18n_locale USING btree (updated_by_id);


--
-- Name: idx_order_items_lnk_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_lnk_item ON public.order_items_fk_order_lnk USING btree (order_item_id);


--
-- Name: idx_order_items_lnk_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_lnk_order ON public.order_items_fk_order_lnk USING btree (order_id);


--
-- Name: idx_orders_takeaway_release_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_takeaway_release_due ON public.orders USING btree (service_type, status, takeaway_status, kitchen_release_at);


--
-- Name: idx_orders_user_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_user_order ON public.orders_fk_user_lnk USING btree (user_id, order_id);


--
-- Name: ingredients_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_created_by_id_fk ON public.ingredients USING btree (created_by_id);


--
-- Name: ingredients_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_documents_idx ON public.ingredients USING btree (document_id, locale, published_at);


--
-- Name: ingredients_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_fk_user_lnk_fk ON public.ingredients_fk_user_lnk USING btree (ingredient_id);


--
-- Name: ingredients_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_fk_user_lnk_ifk ON public.ingredients_fk_user_lnk USING btree (user_id);


--
-- Name: ingredients_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ingredients_updated_by_id_fk ON public.ingredients USING btree (updated_by_id);


--
-- Name: inventory_alerts_acknowledged_by_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_alerts_acknowledged_by_lnk_fk ON public.inventory_alerts_acknowledged_by_lnk USING btree (inventory_alert_id);


--
-- Name: inventory_alerts_acknowledged_by_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_alerts_acknowledged_by_lnk_ifk ON public.inventory_alerts_acknowledged_by_lnk USING btree (user_id);


--
-- Name: inventory_alerts_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_alerts_created_by_id_fk ON public.inventory_alerts USING btree (created_by_id);


--
-- Name: inventory_alerts_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_alerts_documents_idx ON public.inventory_alerts USING btree (document_id, locale, published_at);


--
-- Name: inventory_alerts_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_alerts_fk_user_lnk_fk ON public.inventory_alerts_fk_user_lnk USING btree (inventory_alert_id);


--
-- Name: inventory_alerts_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_alerts_fk_user_lnk_ifk ON public.inventory_alerts_fk_user_lnk USING btree (user_id);


--
-- Name: inventory_alerts_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_alerts_updated_by_id_fk ON public.inventory_alerts USING btree (updated_by_id);


--
-- Name: inventory_movements_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_created_by_id_fk ON public.inventory_movements USING btree (created_by_id);


--
-- Name: inventory_movements_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_documents_idx ON public.inventory_movements USING btree (document_id, locale, published_at);


--
-- Name: inventory_movements_fk_bar_shift_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_bar_shift_lnk_fk ON public.inventory_movements_fk_bar_shift_lnk USING btree (inventory_movement_id);


--
-- Name: inventory_movements_fk_bar_shift_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_bar_shift_lnk_ifk ON public.inventory_movements_fk_bar_shift_lnk USING btree (bar_shift_id);


--
-- Name: inventory_movements_fk_ingredient_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_ingredient_lnk_fk ON public.inventory_movements_fk_ingredient_lnk USING btree (inventory_movement_id);


--
-- Name: inventory_movements_fk_ingredient_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_ingredient_lnk_ifk ON public.inventory_movements_fk_ingredient_lnk USING btree (ingredient_id);


--
-- Name: inventory_movements_fk_order_item_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_order_item_lnk_fk ON public.inventory_movements_fk_order_item_lnk USING btree (inventory_movement_id);


--
-- Name: inventory_movements_fk_order_item_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_order_item_lnk_ifk ON public.inventory_movements_fk_order_item_lnk USING btree (order_item_id);


--
-- Name: inventory_movements_fk_order_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_order_lnk_fk ON public.inventory_movements_fk_order_lnk USING btree (inventory_movement_id);


--
-- Name: inventory_movements_fk_order_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_order_lnk_ifk ON public.inventory_movements_fk_order_lnk USING btree (order_id);


--
-- Name: inventory_movements_fk_restock_order_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_restock_order_lnk_fk ON public.inventory_movements_fk_restock_order_lnk USING btree (inventory_movement_id);


--
-- Name: inventory_movements_fk_restock_order_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_restock_order_lnk_ifk ON public.inventory_movements_fk_restock_order_lnk USING btree (restock_order_id);


--
-- Name: inventory_movements_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_user_lnk_fk ON public.inventory_movements_fk_user_lnk USING btree (inventory_movement_id);


--
-- Name: inventory_movements_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_fk_user_lnk_ifk ON public.inventory_movements_fk_user_lnk USING btree (user_id);


--
-- Name: inventory_movements_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_updated_by_id_fk ON public.inventory_movements USING btree (updated_by_id);


--
-- Name: menu_element_stats_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_element_stats_created_by_id_fk ON public.menu_element_stats USING btree (created_by_id);


--
-- Name: menu_element_stats_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_element_stats_documents_idx ON public.menu_element_stats USING btree (document_id, locale, published_at);


--
-- Name: menu_element_stats_fk_element_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_element_stats_fk_element_lnk_fk ON public.menu_element_stats_fk_element_lnk USING btree (menu_element_stat_id);


--
-- Name: menu_element_stats_fk_element_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_element_stats_fk_element_lnk_ifk ON public.menu_element_stats_fk_element_lnk USING btree (element_id);


--
-- Name: menu_element_stats_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_element_stats_fk_user_lnk_fk ON public.menu_element_stats_fk_user_lnk USING btree (menu_element_stat_id);


--
-- Name: menu_element_stats_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_element_stats_fk_user_lnk_ifk ON public.menu_element_stats_fk_user_lnk USING btree (user_id);


--
-- Name: menu_element_stats_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_element_stats_updated_by_id_fk ON public.menu_element_stats USING btree (updated_by_id);


--
-- Name: menu_import_jobs_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_created_by_id_fk ON public.menu_import_jobs USING btree (created_by_id);


--
-- Name: menu_import_jobs_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_documents_idx ON public.menu_import_jobs USING btree (document_id, locale, published_at);


--
-- Name: menu_import_jobs_file_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_file_hash_idx ON public.menu_import_jobs USING btree (file_hash);


--
-- Name: menu_import_jobs_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_fk_user_lnk_fk ON public.menu_import_jobs_fk_user_lnk USING btree (menu_import_job_id);


--
-- Name: menu_import_jobs_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_fk_user_lnk_ifk ON public.menu_import_jobs_fk_user_lnk USING btree (user_id);


--
-- Name: menu_import_jobs_owner_status_completed_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_owner_status_completed_id_idx ON public.menu_import_jobs USING btree (owner_id, status, completed_at, id);


--
-- Name: menu_import_jobs_owner_status_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_owner_status_id_idx ON public.menu_import_jobs USING btree (owner_id, status, id);


--
-- Name: menu_import_jobs_queue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_queue_idx ON public.menu_import_jobs USING btree (status, next_attempt_at);


--
-- Name: menu_import_jobs_recovery_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_recovery_idx ON public.menu_import_jobs USING btree (status, lease_expires_at);


--
-- Name: menu_import_jobs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_jobs_updated_by_id_fk ON public.menu_import_jobs USING btree (updated_by_id);


--
-- Name: menu_import_leases_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_leases_created_by_id_fk ON public.menu_import_leases USING btree (created_by_id);


--
-- Name: menu_import_leases_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_leases_documents_idx ON public.menu_import_leases USING btree (document_id, locale, published_at);


--
-- Name: menu_import_leases_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_import_leases_updated_by_id_fk ON public.menu_import_leases USING btree (updated_by_id);


--
-- Name: menus_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menus_created_by_id_fk ON public.menus USING btree (created_by_id);


--
-- Name: menus_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menus_documents_idx ON public.menus USING btree (document_id, locale, published_at);


--
-- Name: menus_fk_elements_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menus_fk_elements_lnk_fk ON public.menus_fk_elements_lnk USING btree (menu_id);


--
-- Name: menus_fk_elements_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menus_fk_elements_lnk_ifk ON public.menus_fk_elements_lnk USING btree (element_id);


--
-- Name: menus_fk_elements_lnk_ofk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menus_fk_elements_lnk_ofk ON public.menus_fk_elements_lnk USING btree (element_ord);


--
-- Name: menus_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menus_fk_user_lnk_fk ON public.menus_fk_user_lnk USING btree (menu_id);


--
-- Name: menus_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menus_fk_user_lnk_ifk ON public.menus_fk_user_lnk USING btree (user_id);


--
-- Name: menus_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menus_updated_by_id_fk ON public.menus USING btree (updated_by_id);


--
-- Name: order_archives_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_archives_created_by_id_fk ON public.order_archives USING btree (created_by_id);


--
-- Name: order_archives_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_archives_documents_idx ON public.order_archives USING btree (document_id, locale, published_at);


--
-- Name: order_archives_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_archives_fk_user_lnk_fk ON public.order_archives_fk_user_lnk USING btree (order_archive_id);


--
-- Name: order_archives_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_archives_fk_user_lnk_ifk ON public.order_archives_fk_user_lnk USING btree (user_id);


--
-- Name: order_archives_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_archives_updated_by_id_fk ON public.order_archives USING btree (updated_by_id);


--
-- Name: order_item_addons_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_item_addons_created_by_id_fk ON public.order_item_addons USING btree (created_by_id);


--
-- Name: order_item_addons_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_item_addons_documents_idx ON public.order_item_addons USING btree (document_id, locale, published_at);


--
-- Name: order_item_addons_fk_ingredient_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_item_addons_fk_ingredient_lnk_fk ON public.order_item_addons_fk_ingredient_lnk USING btree (order_item_addon_id);


--
-- Name: order_item_addons_fk_ingredient_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_item_addons_fk_ingredient_lnk_ifk ON public.order_item_addons_fk_ingredient_lnk USING btree (ingredient_id);


--
-- Name: order_item_addons_fk_order_item_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_item_addons_fk_order_item_lnk_fk ON public.order_item_addons_fk_order_item_lnk USING btree (order_item_addon_id);


--
-- Name: order_item_addons_fk_order_item_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_item_addons_fk_order_item_lnk_ifk ON public.order_item_addons_fk_order_item_lnk USING btree (order_item_id);


--
-- Name: order_item_addons_fk_order_item_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_item_addons_fk_order_item_lnk_oifk ON public.order_item_addons_fk_order_item_lnk USING btree (order_item_addon_ord);


--
-- Name: order_item_addons_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_item_addons_updated_by_id_fk ON public.order_item_addons USING btree (updated_by_id);


--
-- Name: order_items_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_created_by_id_fk ON public.order_items USING btree (created_by_id);


--
-- Name: order_items_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_documents_idx ON public.order_items USING btree (document_id, locale, published_at);


--
-- Name: order_items_fk_element_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_fk_element_lnk_fk ON public.order_items_fk_element_lnk USING btree (order_item_id);


--
-- Name: order_items_fk_element_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_fk_element_lnk_ifk ON public.order_items_fk_element_lnk USING btree (element_id);


--
-- Name: order_items_fk_order_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_fk_order_lnk_fk ON public.order_items_fk_order_lnk USING btree (order_item_id);


--
-- Name: order_items_fk_order_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_fk_order_lnk_ifk ON public.order_items_fk_order_lnk USING btree (order_id);


--
-- Name: order_items_fk_order_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_fk_order_lnk_oifk ON public.order_items_fk_order_lnk USING btree (order_item_ord);


--
-- Name: order_items_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_updated_by_id_fk ON public.order_items USING btree (updated_by_id);


--
-- Name: order_realtime_events_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_realtime_events_user_created_idx ON public.order_realtime_events USING btree (user_id, created_at DESC);


--
-- Name: orders_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_created_by_id_fk ON public.orders USING btree (created_by_id);


--
-- Name: orders_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_documents_idx ON public.orders USING btree (document_id, locale, published_at);


--
-- Name: orders_fk_table_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_fk_table_lnk_fk ON public.orders_fk_table_lnk USING btree (order_id);


--
-- Name: orders_fk_table_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_fk_table_lnk_ifk ON public.orders_fk_table_lnk USING btree (table_id);


--
-- Name: orders_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_fk_user_lnk_fk ON public.orders_fk_user_lnk USING btree (order_id);


--
-- Name: orders_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_fk_user_lnk_ifk ON public.orders_fk_user_lnk USING btree (user_id);


--
-- Name: orders_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_updated_by_id_fk ON public.orders USING btree (updated_by_id);


--
-- Name: owner_feature_grants_code_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX owner_feature_grants_code_status_idx ON public.owner_feature_grants USING btree (feature_code, status);


--
-- Name: owner_feature_grants_owner_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX owner_feature_grants_owner_status_idx ON public.owner_feature_grants USING btree (owner_id, status);


--
-- Name: payment_attempts_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_attempts_created_by_id_fk ON public.payment_attempts USING btree (created_by_id);


--
-- Name: payment_attempts_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_attempts_documents_idx ON public.payment_attempts USING btree (document_id, locale, published_at);


--
-- Name: payment_attempts_fk_checkout_attempt_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_attempts_fk_checkout_attempt_lnk_fk ON public.payment_attempts_fk_checkout_attempt_lnk USING btree (payment_attempt_id);


--
-- Name: payment_attempts_fk_checkout_attempt_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_attempts_fk_checkout_attempt_lnk_ifk ON public.payment_attempts_fk_checkout_attempt_lnk USING btree (checkout_attempt_id);


--
-- Name: payment_attempts_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_attempts_fk_user_lnk_fk ON public.payment_attempts_fk_user_lnk USING btree (payment_attempt_id);


--
-- Name: payment_attempts_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_attempts_fk_user_lnk_ifk ON public.payment_attempts_fk_user_lnk USING btree (user_id);


--
-- Name: payment_attempts_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_attempts_updated_by_id_fk ON public.payment_attempts USING btree (updated_by_id);


--
-- Name: pos_devices_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_devices_created_by_id_fk ON public.pos_devices USING btree (created_by_id);


--
-- Name: pos_devices_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_devices_documents_idx ON public.pos_devices USING btree (document_id, locale, published_at);


--
-- Name: pos_devices_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_devices_fk_user_lnk_fk ON public.pos_devices_fk_user_lnk USING btree (pos_device_id);


--
-- Name: pos_devices_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_devices_fk_user_lnk_ifk ON public.pos_devices_fk_user_lnk USING btree (user_id);


--
-- Name: pos_devices_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_devices_updated_by_id_fk ON public.pos_devices USING btree (updated_by_id);


--
-- Name: pos_jobs_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_created_by_id_fk ON public.pos_jobs USING btree (created_by_id);


--
-- Name: pos_jobs_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_documents_idx ON public.pos_jobs USING btree (document_id, locale, published_at);


--
-- Name: pos_jobs_fk_device_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_fk_device_lnk_fk ON public.pos_jobs_fk_device_lnk USING btree (pos_job_id);


--
-- Name: pos_jobs_fk_device_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_fk_device_lnk_ifk ON public.pos_jobs_fk_device_lnk USING btree (pos_device_id);


--
-- Name: pos_jobs_fk_order_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_fk_order_lnk_fk ON public.pos_jobs_fk_order_lnk USING btree (pos_job_id);


--
-- Name: pos_jobs_fk_order_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_fk_order_lnk_ifk ON public.pos_jobs_fk_order_lnk USING btree (order_id);


--
-- Name: pos_jobs_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_fk_user_lnk_fk ON public.pos_jobs_fk_user_lnk USING btree (pos_job_id);


--
-- Name: pos_jobs_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_fk_user_lnk_ifk ON public.pos_jobs_fk_user_lnk USING btree (user_id);


--
-- Name: pos_jobs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_jobs_updated_by_id_fk ON public.pos_jobs USING btree (updated_by_id);


--
-- Name: pos_pairing_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_pairing_tokens_created_by_id_fk ON public.pos_pairing_tokens USING btree (created_by_id);


--
-- Name: pos_pairing_tokens_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_pairing_tokens_documents_idx ON public.pos_pairing_tokens USING btree (document_id, locale, published_at);


--
-- Name: pos_pairing_tokens_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_pairing_tokens_fk_user_lnk_fk ON public.pos_pairing_tokens_fk_user_lnk USING btree (pos_pairing_token_id);


--
-- Name: pos_pairing_tokens_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_pairing_tokens_fk_user_lnk_ifk ON public.pos_pairing_tokens_fk_user_lnk USING btree (user_id);


--
-- Name: pos_pairing_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pos_pairing_tokens_updated_by_id_fk ON public.pos_pairing_tokens USING btree (updated_by_id);


--
-- Name: reservations_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_created_by_id_fk ON public.reservations USING btree (created_by_id);


--
-- Name: reservations_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_documents_idx ON public.reservations USING btree (document_id, locale, published_at);


--
-- Name: reservations_fk_order_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_fk_order_lnk_fk ON public.reservations_fk_order_lnk USING btree (reservation_id);


--
-- Name: reservations_fk_order_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_fk_order_lnk_ifk ON public.reservations_fk_order_lnk USING btree (order_id);


--
-- Name: reservations_fk_table_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_fk_table_lnk_fk ON public.reservations_fk_table_lnk USING btree (reservation_id);


--
-- Name: reservations_fk_table_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_fk_table_lnk_ifk ON public.reservations_fk_table_lnk USING btree (table_id);


--
-- Name: reservations_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_fk_user_lnk_fk ON public.reservations_fk_user_lnk USING btree (reservation_id);


--
-- Name: reservations_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_fk_user_lnk_ifk ON public.reservations_fk_user_lnk USING btree (user_id);


--
-- Name: reservations_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reservations_updated_by_id_fk ON public.reservations USING btree (updated_by_id);


--
-- Name: restaurant_category_routing_owner_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_category_routing_owner_role_idx ON public.restaurant_category_routing USING btree (owner_id, staff_role);


--
-- Name: restaurant_daily_stats_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_daily_stats_created_by_id_fk ON public.restaurant_daily_stats USING btree (created_by_id);


--
-- Name: restaurant_daily_stats_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_daily_stats_documents_idx ON public.restaurant_daily_stats USING btree (document_id, locale, published_at);


--
-- Name: restaurant_daily_stats_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_daily_stats_fk_user_lnk_fk ON public.restaurant_daily_stats_fk_user_lnk USING btree (restaurant_daily_stat_id);


--
-- Name: restaurant_daily_stats_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_daily_stats_fk_user_lnk_ifk ON public.restaurant_daily_stats_fk_user_lnk USING btree (user_id);


--
-- Name: restaurant_daily_stats_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_daily_stats_updated_by_id_fk ON public.restaurant_daily_stats USING btree (updated_by_id);


--
-- Name: restaurant_printer_configs_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_printer_configs_created_by_id_fk ON public.restaurant_printer_configs USING btree (created_by_id);


--
-- Name: restaurant_printer_configs_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_printer_configs_documents_idx ON public.restaurant_printer_configs USING btree (document_id, locale, published_at);


--
-- Name: restaurant_printer_configs_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_printer_configs_fk_user_lnk_fk ON public.restaurant_printer_configs_fk_user_lnk USING btree (restaurant_printer_config_id);


--
-- Name: restaurant_printer_configs_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_printer_configs_fk_user_lnk_ifk ON public.restaurant_printer_configs_fk_user_lnk USING btree (user_id);


--
-- Name: restaurant_printer_configs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_printer_configs_updated_by_id_fk ON public.restaurant_printer_configs USING btree (updated_by_id);


--
-- Name: restaurant_staff_owner_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_staff_owner_role_idx ON public.restaurant_staff USING btree (owner_id, role) WHERE (active = true);


--
-- Name: restaurant_staff_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restaurant_staff_user_idx ON public.restaurant_staff USING btree (user_id) WHERE (active = true);


--
-- Name: restock_orders_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restock_orders_created_by_id_fk ON public.restock_orders USING btree (created_by_id);


--
-- Name: restock_orders_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restock_orders_documents_idx ON public.restock_orders USING btree (document_id, locale, published_at);


--
-- Name: restock_orders_fk_ingredient_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restock_orders_fk_ingredient_lnk_fk ON public.restock_orders_fk_ingredient_lnk USING btree (restock_order_id);


--
-- Name: restock_orders_fk_ingredient_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restock_orders_fk_ingredient_lnk_ifk ON public.restock_orders_fk_ingredient_lnk USING btree (ingredient_id);


--
-- Name: restock_orders_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restock_orders_fk_user_lnk_fk ON public.restock_orders_fk_user_lnk USING btree (restock_order_id);


--
-- Name: restock_orders_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restock_orders_fk_user_lnk_ifk ON public.restock_orders_fk_user_lnk USING btree (user_id);


--
-- Name: restock_orders_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX restock_orders_updated_by_id_fk ON public.restock_orders USING btree (updated_by_id);


--
-- Name: strapi_api_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_token_permissions_created_by_id_fk ON public.strapi_api_token_permissions USING btree (created_by_id);


--
-- Name: strapi_api_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_token_permissions_documents_idx ON public.strapi_api_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_token_permissions_token_lnk_fk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_id);


--
-- Name: strapi_api_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_token_permissions_token_lnk_ifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_id);


--
-- Name: strapi_api_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_token_permissions_token_lnk_oifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_ord);


--
-- Name: strapi_api_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_token_permissions_updated_by_id_fk ON public.strapi_api_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_api_tokens_admin_user_owner_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_tokens_admin_user_owner_lnk_fk ON public.strapi_api_tokens_admin_user_owner_lnk USING btree (api_token_id);


--
-- Name: strapi_api_tokens_admin_user_owner_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_tokens_admin_user_owner_lnk_ifk ON public.strapi_api_tokens_admin_user_owner_lnk USING btree (user_id);


--
-- Name: strapi_api_tokens_admin_user_owner_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_tokens_admin_user_owner_lnk_oifk ON public.strapi_api_tokens_admin_user_owner_lnk USING btree (api_token_ord);


--
-- Name: strapi_api_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_tokens_created_by_id_fk ON public.strapi_api_tokens USING btree (created_by_id);


--
-- Name: strapi_api_tokens_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_tokens_documents_idx ON public.strapi_api_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_api_tokens_updated_by_id_fk ON public.strapi_api_tokens USING btree (updated_by_id);


--
-- Name: strapi_history_versions_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_history_versions_created_by_id_fk ON public.strapi_history_versions USING btree (created_by_id);


--
-- Name: strapi_release_actions_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_release_actions_created_by_id_fk ON public.strapi_release_actions USING btree (created_by_id);


--
-- Name: strapi_release_actions_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_release_actions_documents_idx ON public.strapi_release_actions USING btree (document_id, locale, published_at);


--
-- Name: strapi_release_actions_release_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_release_actions_release_lnk_fk ON public.strapi_release_actions_release_lnk USING btree (release_action_id);


--
-- Name: strapi_release_actions_release_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_release_actions_release_lnk_ifk ON public.strapi_release_actions_release_lnk USING btree (release_id);


--
-- Name: strapi_release_actions_release_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_release_actions_release_lnk_oifk ON public.strapi_release_actions_release_lnk USING btree (release_action_ord);


--
-- Name: strapi_release_actions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_release_actions_updated_by_id_fk ON public.strapi_release_actions USING btree (updated_by_id);


--
-- Name: strapi_releases_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_releases_created_by_id_fk ON public.strapi_releases USING btree (created_by_id);


--
-- Name: strapi_releases_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_releases_documents_idx ON public.strapi_releases USING btree (document_id, locale, published_at);


--
-- Name: strapi_releases_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_releases_updated_by_id_fk ON public.strapi_releases USING btree (updated_by_id);


--
-- Name: strapi_sessions_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_sessions_created_by_id_fk ON public.strapi_sessions USING btree (created_by_id);


--
-- Name: strapi_sessions_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_sessions_documents_idx ON public.strapi_sessions USING btree (document_id, locale, published_at);


--
-- Name: strapi_sessions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_sessions_updated_by_id_fk ON public.strapi_sessions USING btree (updated_by_id);


--
-- Name: strapi_transfer_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_token_permissions_created_by_id_fk ON public.strapi_transfer_token_permissions USING btree (created_by_id);


--
-- Name: strapi_transfer_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_token_permissions_documents_idx ON public.strapi_transfer_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_fk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_ifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_oifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_ord);


--
-- Name: strapi_transfer_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_token_permissions_updated_by_id_fk ON public.strapi_transfer_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_transfer_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_tokens_created_by_id_fk ON public.strapi_transfer_tokens USING btree (created_by_id);


--
-- Name: strapi_transfer_tokens_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_tokens_documents_idx ON public.strapi_transfer_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_transfer_tokens_updated_by_id_fk ON public.strapi_transfer_tokens USING btree (updated_by_id);


--
-- Name: strapi_workflows_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_created_by_id_fk ON public.strapi_workflows USING btree (created_by_id);


--
-- Name: strapi_workflows_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_documents_idx ON public.strapi_workflows USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_fk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_ifk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_created_by_id_fk ON public.strapi_workflows_stages USING btree (created_by_id);


--
-- Name: strapi_workflows_stages_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_documents_idx ON public.strapi_workflows_stages USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stages_permissions_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_fk ON public.strapi_workflows_stages_permissions_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ifk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ofk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ofk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_ord);


--
-- Name: strapi_workflows_stages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_updated_by_id_fk ON public.strapi_workflows_stages USING btree (updated_by_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_fk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_ifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_oifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_ord);


--
-- Name: strapi_workflows_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX strapi_workflows_updated_by_id_fk ON public.strapi_workflows USING btree (updated_by_id);


--
-- Name: suppliers_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppliers_created_by_id_fk ON public.suppliers USING btree (created_by_id);


--
-- Name: suppliers_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppliers_documents_idx ON public.suppliers USING btree (document_id, locale, published_at);


--
-- Name: suppliers_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppliers_fk_user_lnk_fk ON public.suppliers_fk_user_lnk USING btree (supplier_id);


--
-- Name: suppliers_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppliers_fk_user_lnk_ifk ON public.suppliers_fk_user_lnk USING btree (user_id);


--
-- Name: suppliers_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppliers_updated_by_id_fk ON public.suppliers USING btree (updated_by_id);


--
-- Name: sync_events_applied_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sync_events_applied_at_idx ON public.sync_events USING btree (applied_at);


--
-- Name: sync_events_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sync_events_created_by_id_fk ON public.sync_events USING btree (created_by_id);


--
-- Name: sync_events_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sync_events_documents_idx ON public.sync_events USING btree (document_id, locale, published_at);


--
-- Name: sync_events_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sync_events_fk_user_lnk_fk ON public.sync_events_fk_user_lnk USING btree (sync_event_id);


--
-- Name: sync_events_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sync_events_fk_user_lnk_ifk ON public.sync_events_fk_user_lnk USING btree (user_id);


--
-- Name: sync_events_hlc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sync_events_hlc_idx ON public.sync_events USING btree (hlc);


--
-- Name: sync_events_order_doc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sync_events_order_doc_idx ON public.sync_events USING btree (order_document_id);


--
-- Name: sync_events_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sync_events_updated_by_id_fk ON public.sync_events USING btree (updated_by_id);


--
-- Name: table_order_access_points_bound_table_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_access_points_bound_table_id_index ON public.table_order_access_points USING btree (bound_table_id);


--
-- Name: table_order_access_points_owner_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_access_points_owner_id_index ON public.table_order_access_points USING btree (owner_id);


--
-- Name: table_order_access_points_signing_kid_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_access_points_signing_kid_index ON public.table_order_access_points USING btree (signing_kid);


--
-- Name: table_order_access_points_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_access_points_status_index ON public.table_order_access_points USING btree (status);


--
-- Name: table_order_commands_session_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_commands_session_id_index ON public.table_order_commands USING btree (session_id);


--
-- Name: table_order_commands_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_commands_state_idx ON public.table_order_commands USING btree (state, created_at);


--
-- Name: table_order_participants_owner_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_participants_owner_id_index ON public.table_order_participants USING btree (owner_id);


--
-- Name: table_order_participants_session_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_participants_session_id_index ON public.table_order_participants USING btree (session_id);


--
-- Name: table_order_participants_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_participants_status_index ON public.table_order_participants USING btree (status);


--
-- Name: table_order_rate_limits_expires_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_rate_limits_expires_idx ON public.table_order_rate_limits USING btree (expires_at);


--
-- Name: table_order_realtime_events_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_realtime_events_session_idx ON public.table_order_realtime_events USING btree (session_public_id, created_at DESC);


--
-- Name: table_order_realtime_events_session_public_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_realtime_events_session_public_id_index ON public.table_order_realtime_events USING btree (session_public_id);


--
-- Name: table_order_sessions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_sessions_expires_at_index ON public.table_order_sessions USING btree (expires_at);


--
-- Name: table_order_sessions_order_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_sessions_order_id_index ON public.table_order_sessions USING btree (order_id);


--
-- Name: table_order_sessions_owner_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_sessions_owner_id_index ON public.table_order_sessions USING btree (owner_id);


--
-- Name: table_order_sessions_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_sessions_status_index ON public.table_order_sessions USING btree (status);


--
-- Name: table_order_sessions_table_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX table_order_sessions_table_id_index ON public.table_order_sessions USING btree (table_id);


--
-- Name: tables_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_created_by_id_fk ON public.tables USING btree (created_by_id);


--
-- Name: tables_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_documents_idx ON public.tables USING btree (document_id, locale, published_at);


--
-- Name: tables_fk_origins_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_origins_lnk_fk ON public.tables_fk_origins_lnk USING btree (table_id);


--
-- Name: tables_fk_origins_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_origins_lnk_ifk ON public.tables_fk_origins_lnk USING btree (inv_table_id);


--
-- Name: tables_fk_origins_lnk_ofk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_origins_lnk_ofk ON public.tables_fk_origins_lnk USING btree (table_ord);


--
-- Name: tables_fk_origins_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_origins_lnk_oifk ON public.tables_fk_origins_lnk USING btree (inv_table_ord);


--
-- Name: tables_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_user_lnk_fk ON public.tables_fk_user_lnk USING btree (table_id);


--
-- Name: tables_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_user_lnk_ifk ON public.tables_fk_user_lnk USING btree (user_id);


--
-- Name: tables_fk_zone_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_zone_lnk_fk ON public.tables_fk_zone_lnk USING btree (table_id);


--
-- Name: tables_fk_zone_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_zone_lnk_ifk ON public.tables_fk_zone_lnk USING btree (zone_id);


--
-- Name: tables_fk_zone_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_fk_zone_lnk_oifk ON public.tables_fk_zone_lnk USING btree (table_ord);


--
-- Name: tables_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_updated_by_id_fk ON public.tables USING btree (updated_by_id);


--
-- Name: takeaway_proposal_expiry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_proposal_expiry_idx ON public.takeaway_time_proposals USING btree (status, expires_at);


--
-- Name: takeaway_proposal_order_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_proposal_order_status_idx ON public.takeaway_time_proposals USING btree (order_document_id, status);


--
-- Name: takeaway_proposal_schedule_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_proposal_schedule_idx ON public.takeaway_time_proposals USING btree (status, proposed_pickup_at);


--
-- Name: takeaway_time_proposals_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_time_proposals_created_by_id_fk ON public.takeaway_time_proposals USING btree (created_by_id);


--
-- Name: takeaway_time_proposals_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_time_proposals_documents_idx ON public.takeaway_time_proposals USING btree (document_id, locale, published_at);


--
-- Name: takeaway_time_proposals_fk_order_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_time_proposals_fk_order_lnk_fk ON public.takeaway_time_proposals_fk_order_lnk USING btree (takeaway_time_proposal_id);


--
-- Name: takeaway_time_proposals_fk_order_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_time_proposals_fk_order_lnk_ifk ON public.takeaway_time_proposals_fk_order_lnk USING btree (order_id);


--
-- Name: takeaway_time_proposals_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_time_proposals_fk_user_lnk_fk ON public.takeaway_time_proposals_fk_user_lnk USING btree (takeaway_time_proposal_id);


--
-- Name: takeaway_time_proposals_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_time_proposals_fk_user_lnk_ifk ON public.takeaway_time_proposals_fk_user_lnk USING btree (user_id);


--
-- Name: takeaway_time_proposals_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX takeaway_time_proposals_updated_by_id_fk ON public.takeaway_time_proposals USING btree (updated_by_id);


--
-- Name: tosr_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tosr_order_idx ON public.table_order_service_requests USING btree (order_id);


--
-- Name: tosr_owner_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tosr_owner_status_idx ON public.table_order_service_requests USING btree (owner_id, status);


--
-- Name: tosr_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tosr_session_idx ON public.table_order_service_requests USING btree (session_id);


--
-- Name: up_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_permissions_created_by_id_fk ON public.up_permissions USING btree (created_by_id);


--
-- Name: up_permissions_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_permissions_documents_idx ON public.up_permissions USING btree (document_id, locale, published_at);


--
-- Name: up_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_permissions_role_lnk_fk ON public.up_permissions_role_lnk USING btree (permission_id);


--
-- Name: up_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_permissions_role_lnk_ifk ON public.up_permissions_role_lnk USING btree (role_id);


--
-- Name: up_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_permissions_role_lnk_oifk ON public.up_permissions_role_lnk USING btree (permission_ord);


--
-- Name: up_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_permissions_updated_by_id_fk ON public.up_permissions USING btree (updated_by_id);


--
-- Name: up_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_roles_created_by_id_fk ON public.up_roles USING btree (created_by_id);


--
-- Name: up_roles_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_roles_documents_idx ON public.up_roles USING btree (document_id, locale, published_at);


--
-- Name: up_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_roles_updated_by_id_fk ON public.up_roles USING btree (updated_by_id);


--
-- Name: up_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_created_by_id_fk ON public.up_users USING btree (created_by_id);


--
-- Name: up_users_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_documents_idx ON public.up_users USING btree (document_id, locale, published_at);


--
-- Name: up_users_fk_owner_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_fk_owner_lnk_fk ON public.up_users_fk_owner_lnk USING btree (user_id);


--
-- Name: up_users_fk_owner_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_fk_owner_lnk_ifk ON public.up_users_fk_owner_lnk USING btree (inv_user_id);


--
-- Name: up_users_fk_owner_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_fk_owner_lnk_oifk ON public.up_users_fk_owner_lnk USING btree (user_ord);


--
-- Name: up_users_role_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_role_lnk_fk ON public.up_users_role_lnk USING btree (user_id);


--
-- Name: up_users_role_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_role_lnk_ifk ON public.up_users_role_lnk USING btree (role_id);


--
-- Name: up_users_role_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_role_lnk_oifk ON public.up_users_role_lnk USING btree (user_ord);


--
-- Name: up_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX up_users_updated_by_id_fk ON public.up_users USING btree (updated_by_id);


--
-- Name: upload_files_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_files_created_at_index ON public.files USING btree (created_at);


--
-- Name: upload_files_ext_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_files_ext_index ON public.files USING btree (ext);


--
-- Name: upload_files_folder_path_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_files_folder_path_index ON public.files USING btree (folder_path);


--
-- Name: upload_files_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_files_name_index ON public.files USING btree (name);


--
-- Name: upload_files_size_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_files_size_index ON public.files USING btree (size);


--
-- Name: upload_files_updated_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_files_updated_at_index ON public.files USING btree (updated_at);


--
-- Name: upload_folders_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_folders_created_by_id_fk ON public.upload_folders USING btree (created_by_id);


--
-- Name: upload_folders_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_folders_documents_idx ON public.upload_folders USING btree (document_id, locale, published_at);


--
-- Name: upload_folders_parent_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_folders_parent_lnk_fk ON public.upload_folders_parent_lnk USING btree (folder_id);


--
-- Name: upload_folders_parent_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_folders_parent_lnk_ifk ON public.upload_folders_parent_lnk USING btree (inv_folder_id);


--
-- Name: upload_folders_parent_lnk_oifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_folders_parent_lnk_oifk ON public.upload_folders_parent_lnk USING btree (folder_ord);


--
-- Name: upload_folders_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX upload_folders_updated_by_id_fk ON public.upload_folders USING btree (updated_by_id);


--
-- Name: website_configs_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX website_configs_created_by_id_fk ON public.website_configs USING btree (created_by_id);


--
-- Name: website_configs_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX website_configs_documents_idx ON public.website_configs USING btree (document_id, locale, published_at);


--
-- Name: website_configs_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX website_configs_fk_user_lnk_fk ON public.website_configs_fk_user_lnk USING btree (website_config_id);


--
-- Name: website_configs_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX website_configs_fk_user_lnk_ifk ON public.website_configs_fk_user_lnk USING btree (user_id);


--
-- Name: website_configs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX website_configs_updated_by_id_fk ON public.website_configs USING btree (updated_by_id);


--
-- Name: zones_created_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX zones_created_by_id_fk ON public.zones USING btree (created_by_id);


--
-- Name: zones_documents_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX zones_documents_idx ON public.zones USING btree (document_id, locale, published_at);


--
-- Name: zones_fk_user_lnk_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX zones_fk_user_lnk_fk ON public.zones_fk_user_lnk USING btree (zone_id);


--
-- Name: zones_fk_user_lnk_ifk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX zones_fk_user_lnk_ifk ON public.zones_fk_user_lnk USING btree (user_id);


--
-- Name: zones_updated_by_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX zones_updated_by_id_fk ON public.zones USING btree (updated_by_id);


--
-- Name: elements_fk_user_lnk elements_category_routing_after_link; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER elements_category_routing_after_link AFTER INSERT ON public.elements_fk_user_lnk FOR EACH ROW EXECUTE FUNCTION public.route_category_from_element_link();


--
-- Name: elements elements_category_routing_after_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER elements_category_routing_after_update AFTER UPDATE OF category ON public.elements FOR EACH ROW EXECUTE FUNCTION public.route_category_from_element_update();


--
-- Name: order_items_fk_order_lnk order_items_order_link_realtime_event_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_items_order_link_realtime_event_trigger AFTER INSERT OR DELETE OR UPDATE ON public.order_items_fk_order_lnk FOR EACH ROW EXECUTE FUNCTION public.emit_order_realtime_event();


--
-- Name: order_items order_items_realtime_event_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER order_items_realtime_event_trigger AFTER INSERT OR DELETE OR UPDATE ON public.order_items FOR EACH ROW EXECUTE FUNCTION public.emit_order_realtime_event();


--
-- Name: orders orders_realtime_event_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_realtime_event_trigger AFTER INSERT OR DELETE OR UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.emit_order_realtime_event();


--
-- Name: orders_fk_user_lnk orders_user_link_realtime_event_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_user_link_realtime_event_trigger AFTER INSERT OR DELETE OR UPDATE ON public.orders_fk_user_lnk FOR EACH ROW EXECUTE FUNCTION public.emit_order_realtime_event();


--
-- Name: reservations reservations_realtime_event_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reservations_realtime_event_trigger AFTER INSERT OR DELETE OR UPDATE ON public.reservations FOR EACH ROW EXECUTE FUNCTION public.emit_order_realtime_event();


--
-- Name: reservations_fk_user_lnk reservations_user_link_realtime_event_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reservations_user_link_realtime_event_trigger AFTER INSERT OR DELETE OR UPDATE ON public.reservations_fk_user_lnk FOR EACH ROW EXECUTE FUNCTION public.emit_order_realtime_event();


--
-- Name: restaurant_category_routing restaurant_category_routing_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER restaurant_category_routing_set_updated_at BEFORE UPDATE ON public.restaurant_category_routing FOR EACH ROW EXECUTE FUNCTION public.set_restaurant_staff_updated_at();


--
-- Name: restaurant_staff restaurant_staff_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER restaurant_staff_set_updated_at BEFORE UPDATE ON public.restaurant_staff FOR EACH ROW EXECUTE FUNCTION public.set_restaurant_staff_updated_at();


--
-- Name: tables tables_realtime_event_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tables_realtime_event_trigger AFTER INSERT OR DELETE OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.emit_order_realtime_event();


--
-- Name: tables_fk_user_lnk tables_user_link_realtime_event_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tables_user_link_realtime_event_trigger AFTER INSERT OR DELETE OR UPDATE ON public.tables_fk_user_lnk FOR EACH ROW EXECUTE FUNCTION public.emit_order_realtime_event();


--
-- Name: tables_fk_user_lnk trg_tables_unique_number_link; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_unique_number_link BEFORE INSERT OR UPDATE ON public.tables_fk_user_lnk FOR EACH ROW EXECUTE FUNCTION public.enforce_unique_table_number_per_owner();


--
-- Name: tables trg_tables_unique_number_on_renumber; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_unique_number_on_renumber BEFORE UPDATE OF number ON public.tables FOR EACH ROW EXECUTE FUNCTION public.enforce_unique_table_number_on_renumber();


--
-- Name: up_users up_users_sync_staff_after_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER up_users_sync_staff_after_insert AFTER INSERT ON public.up_users FOR EACH ROW EXECUTE FUNCTION public.sync_owner_staff_accounts_trigger();


--
-- Name: up_users up_users_sync_staff_after_subscription_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER up_users_sync_staff_after_subscription_update AFTER UPDATE OF password, subscription_status, subscription_plan, subscription_current_period_end, end_subscription, feature_grants_version ON public.up_users FOR EACH ROW WHEN (((COALESCE(new.staff_role, 'owner'::character varying))::text = 'owner'::text)) EXECUTE FUNCTION public.sync_owner_staff_accounts_trigger();


--
-- Name: admin_permissions_api_token_lnk admin_permissions_api_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_api_token_lnk
    ADD CONSTRAINT admin_permissions_api_token_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: admin_permissions_api_token_lnk admin_permissions_api_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_api_token_lnk
    ADD CONSTRAINT admin_permissions_api_token_lnk_ifk FOREIGN KEY (api_token_id) REFERENCES public.strapi_api_tokens(id) ON DELETE CASCADE;


--
-- Name: admin_permissions admin_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_permissions admin_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users admin_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_fk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_users admin_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: audit_hardware_events audit_hardware_events_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_hardware_events
    ADD CONSTRAINT audit_hardware_events_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: audit_hardware_events audit_hardware_events_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_hardware_events
    ADD CONSTRAINT audit_hardware_events_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: bar_shifts_closed_by_lnk bar_shifts_closed_by_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_closed_by_lnk
    ADD CONSTRAINT bar_shifts_closed_by_lnk_fk FOREIGN KEY (bar_shift_id) REFERENCES public.bar_shifts(id) ON DELETE CASCADE;


--
-- Name: bar_shifts_closed_by_lnk bar_shifts_closed_by_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_closed_by_lnk
    ADD CONSTRAINT bar_shifts_closed_by_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: bar_shifts bar_shifts_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts
    ADD CONSTRAINT bar_shifts_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: bar_shifts_fk_user_lnk bar_shifts_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_fk_user_lnk
    ADD CONSTRAINT bar_shifts_fk_user_lnk_fk FOREIGN KEY (bar_shift_id) REFERENCES public.bar_shifts(id) ON DELETE CASCADE;


--
-- Name: bar_shifts_fk_user_lnk bar_shifts_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_fk_user_lnk
    ADD CONSTRAINT bar_shifts_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: bar_shifts_opened_by_lnk bar_shifts_opened_by_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_opened_by_lnk
    ADD CONSTRAINT bar_shifts_opened_by_lnk_fk FOREIGN KEY (bar_shift_id) REFERENCES public.bar_shifts(id) ON DELETE CASCADE;


--
-- Name: bar_shifts_opened_by_lnk bar_shifts_opened_by_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts_opened_by_lnk
    ADD CONSTRAINT bar_shifts_opened_by_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: bar_shifts bar_shifts_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bar_shifts
    ADD CONSTRAINT bar_shifts_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: checkout_attempts checkout_attempts_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts
    ADD CONSTRAINT checkout_attempts_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: checkout_attempts_fk_order_lnk checkout_attempts_fk_order_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_order_lnk
    ADD CONSTRAINT checkout_attempts_fk_order_lnk_fk FOREIGN KEY (checkout_attempt_id) REFERENCES public.checkout_attempts(id) ON DELETE CASCADE;


--
-- Name: checkout_attempts_fk_order_lnk checkout_attempts_fk_order_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_order_lnk
    ADD CONSTRAINT checkout_attempts_fk_order_lnk_ifk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: checkout_attempts_fk_user_lnk checkout_attempts_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_user_lnk
    ADD CONSTRAINT checkout_attempts_fk_user_lnk_fk FOREIGN KEY (checkout_attempt_id) REFERENCES public.checkout_attempts(id) ON DELETE CASCADE;


--
-- Name: checkout_attempts_fk_user_lnk checkout_attempts_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts_fk_user_lnk
    ADD CONSTRAINT checkout_attempts_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: checkout_attempts checkout_attempts_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_attempts
    ADD CONSTRAINT checkout_attempts_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: customer_messages customer_messages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages
    ADD CONSTRAINT customer_messages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: customer_messages_fk_order_lnk customer_messages_fk_order_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_order_lnk
    ADD CONSTRAINT customer_messages_fk_order_lnk_fk FOREIGN KEY (customer_message_id) REFERENCES public.customer_messages(id) ON DELETE CASCADE;


--
-- Name: customer_messages_fk_order_lnk customer_messages_fk_order_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_order_lnk
    ADD CONSTRAINT customer_messages_fk_order_lnk_ifk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: customer_messages_fk_time_proposal_lnk customer_messages_fk_time_proposal_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_time_proposal_lnk
    ADD CONSTRAINT customer_messages_fk_time_proposal_lnk_fk FOREIGN KEY (customer_message_id) REFERENCES public.customer_messages(id) ON DELETE CASCADE;


--
-- Name: customer_messages_fk_time_proposal_lnk customer_messages_fk_time_proposal_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_time_proposal_lnk
    ADD CONSTRAINT customer_messages_fk_time_proposal_lnk_ifk FOREIGN KEY (takeaway_time_proposal_id) REFERENCES public.takeaway_time_proposals(id) ON DELETE CASCADE;


--
-- Name: customer_messages_fk_user_lnk customer_messages_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_user_lnk
    ADD CONSTRAINT customer_messages_fk_user_lnk_fk FOREIGN KEY (customer_message_id) REFERENCES public.customer_messages(id) ON DELETE CASCADE;


--
-- Name: customer_messages_fk_user_lnk customer_messages_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages_fk_user_lnk
    ADD CONSTRAINT customer_messages_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: customer_messages customer_messages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_messages
    ADD CONSTRAINT customer_messages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: element_ingredients element_ingredients_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients
    ADD CONSTRAINT element_ingredients_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: element_ingredients_fk_element_lnk element_ingredients_fk_element_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_element_lnk
    ADD CONSTRAINT element_ingredients_fk_element_lnk_fk FOREIGN KEY (element_ingredient_id) REFERENCES public.element_ingredients(id) ON DELETE CASCADE;


--
-- Name: element_ingredients_fk_element_lnk element_ingredients_fk_element_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_element_lnk
    ADD CONSTRAINT element_ingredients_fk_element_lnk_ifk FOREIGN KEY (element_id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: element_ingredients_fk_ingredient_lnk element_ingredients_fk_ingredient_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_ingredient_lnk
    ADD CONSTRAINT element_ingredients_fk_ingredient_lnk_fk FOREIGN KEY (element_ingredient_id) REFERENCES public.element_ingredients(id) ON DELETE CASCADE;


--
-- Name: element_ingredients_fk_ingredient_lnk element_ingredients_fk_ingredient_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients_fk_ingredient_lnk
    ADD CONSTRAINT element_ingredients_fk_ingredient_lnk_ifk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON DELETE CASCADE;


--
-- Name: element_ingredients element_ingredients_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.element_ingredients
    ADD CONSTRAINT element_ingredients_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: elements elements_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: elements_fk_user_lnk elements_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_fk_user_lnk
    ADD CONSTRAINT elements_fk_user_lnk_fk FOREIGN KEY (element_id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: elements_fk_user_lnk elements_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_fk_user_lnk
    ADD CONSTRAINT elements_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: elements elements_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: feature_rollout_owners feature_rollout_owners_owner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_rollout_owners
    ADD CONSTRAINT feature_rollout_owners_owner_id_foreign FOREIGN KEY (owner_id) REFERENCES public.up_users(id);


--
-- Name: files files_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files_folder_lnk files_folder_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files_folder_lnk files_folder_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_ifk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: files_related_mph files_related_mph_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files files_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: fiscal_attempts fiscal_attempts_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts
    ADD CONSTRAINT fiscal_attempts_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk fiscal_attempts_fk_checkout_attempt_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT fiscal_attempts_fk_checkout_attempt_lnk_fk FOREIGN KEY (fiscal_attempt_id) REFERENCES public.fiscal_attempts(id) ON DELETE CASCADE;


--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk fiscal_attempts_fk_checkout_attempt_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT fiscal_attempts_fk_checkout_attempt_lnk_ifk FOREIGN KEY (checkout_attempt_id) REFERENCES public.checkout_attempts(id) ON DELETE CASCADE;


--
-- Name: fiscal_attempts_fk_user_lnk fiscal_attempts_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_user_lnk
    ADD CONSTRAINT fiscal_attempts_fk_user_lnk_fk FOREIGN KEY (fiscal_attempt_id) REFERENCES public.fiscal_attempts(id) ON DELETE CASCADE;


--
-- Name: fiscal_attempts_fk_user_lnk fiscal_attempts_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts_fk_user_lnk
    ADD CONSTRAINT fiscal_attempts_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: fiscal_attempts fiscal_attempts_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_attempts
    ADD CONSTRAINT fiscal_attempts_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: fiscal_correction_attempts fiscal_correction_attempts_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts
    ADD CONSTRAINT fiscal_correction_attempts_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk fiscal_correction_attempts_fk_checkout_attempt_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_checkout_attempt_lnk_fk FOREIGN KEY (fiscal_correction_attempt_id) REFERENCES public.fiscal_correction_attempts(id) ON DELETE CASCADE;


--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk fiscal_correction_attempts_fk_checkout_attempt_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_checkout_attempt_lnk_ifk FOREIGN KEY (checkout_attempt_id) REFERENCES public.checkout_attempts(id) ON DELETE CASCADE;


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk fiscal_correction_attempts_fk_fiscal_attempt_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_fiscal_attempt_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_fiscal_attempt_lnk_fk FOREIGN KEY (fiscal_correction_attempt_id) REFERENCES public.fiscal_correction_attempts(id) ON DELETE CASCADE;


--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk fiscal_correction_attempts_fk_fiscal_attempt_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_fiscal_attempt_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_fiscal_attempt_lnk_ifk FOREIGN KEY (fiscal_attempt_id) REFERENCES public.fiscal_attempts(id) ON DELETE CASCADE;


--
-- Name: fiscal_correction_attempts_fk_user_lnk fiscal_correction_attempts_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_user_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_user_lnk_fk FOREIGN KEY (fiscal_correction_attempt_id) REFERENCES public.fiscal_correction_attempts(id) ON DELETE CASCADE;


--
-- Name: fiscal_correction_attempts_fk_user_lnk fiscal_correction_attempts_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts_fk_user_lnk
    ADD CONSTRAINT fiscal_correction_attempts_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: fiscal_correction_attempts fiscal_correction_attempts_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_correction_attempts
    ADD CONSTRAINT fiscal_correction_attempts_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: hardware_endpoints hardware_endpoints_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints
    ADD CONSTRAINT hardware_endpoints_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: hardware_endpoints_fk_pos_device_lnk hardware_endpoints_fk_pos_device_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_pos_device_lnk
    ADD CONSTRAINT hardware_endpoints_fk_pos_device_lnk_fk FOREIGN KEY (hardware_endpoint_id) REFERENCES public.hardware_endpoints(id) ON DELETE CASCADE;


--
-- Name: hardware_endpoints_fk_pos_device_lnk hardware_endpoints_fk_pos_device_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_pos_device_lnk
    ADD CONSTRAINT hardware_endpoints_fk_pos_device_lnk_ifk FOREIGN KEY (pos_device_id) REFERENCES public.pos_devices(id) ON DELETE CASCADE;


--
-- Name: hardware_endpoints_fk_user_lnk hardware_endpoints_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_user_lnk
    ADD CONSTRAINT hardware_endpoints_fk_user_lnk_fk FOREIGN KEY (hardware_endpoint_id) REFERENCES public.hardware_endpoints(id) ON DELETE CASCADE;


--
-- Name: hardware_endpoints_fk_user_lnk hardware_endpoints_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints_fk_user_lnk
    ADD CONSTRAINT hardware_endpoints_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: hardware_endpoints hardware_endpoints_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_endpoints
    ADD CONSTRAINT hardware_endpoints_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: hardware_jobs hardware_jobs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs
    ADD CONSTRAINT hardware_jobs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk hardware_jobs_fk_checkout_attempt_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_checkout_attempt_lnk
    ADD CONSTRAINT hardware_jobs_fk_checkout_attempt_lnk_fk FOREIGN KEY (hardware_job_id) REFERENCES public.hardware_jobs(id) ON DELETE CASCADE;


--
-- Name: hardware_jobs_fk_checkout_attempt_lnk hardware_jobs_fk_checkout_attempt_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_checkout_attempt_lnk
    ADD CONSTRAINT hardware_jobs_fk_checkout_attempt_lnk_ifk FOREIGN KEY (checkout_attempt_id) REFERENCES public.checkout_attempts(id) ON DELETE CASCADE;


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk hardware_jobs_fk_hardware_endpoint_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_hardware_endpoint_lnk
    ADD CONSTRAINT hardware_jobs_fk_hardware_endpoint_lnk_fk FOREIGN KEY (hardware_job_id) REFERENCES public.hardware_jobs(id) ON DELETE CASCADE;


--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk hardware_jobs_fk_hardware_endpoint_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_hardware_endpoint_lnk
    ADD CONSTRAINT hardware_jobs_fk_hardware_endpoint_lnk_ifk FOREIGN KEY (hardware_endpoint_id) REFERENCES public.hardware_endpoints(id) ON DELETE CASCADE;


--
-- Name: hardware_jobs_fk_pos_device_lnk hardware_jobs_fk_pos_device_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_pos_device_lnk
    ADD CONSTRAINT hardware_jobs_fk_pos_device_lnk_fk FOREIGN KEY (hardware_job_id) REFERENCES public.hardware_jobs(id) ON DELETE CASCADE;


--
-- Name: hardware_jobs_fk_pos_device_lnk hardware_jobs_fk_pos_device_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_pos_device_lnk
    ADD CONSTRAINT hardware_jobs_fk_pos_device_lnk_ifk FOREIGN KEY (pos_device_id) REFERENCES public.pos_devices(id) ON DELETE CASCADE;


--
-- Name: hardware_jobs_fk_user_lnk hardware_jobs_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_user_lnk
    ADD CONSTRAINT hardware_jobs_fk_user_lnk_fk FOREIGN KEY (hardware_job_id) REFERENCES public.hardware_jobs(id) ON DELETE CASCADE;


--
-- Name: hardware_jobs_fk_user_lnk hardware_jobs_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs_fk_user_lnk
    ADD CONSTRAINT hardware_jobs_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: hardware_jobs hardware_jobs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hardware_jobs
    ADD CONSTRAINT hardware_jobs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: ingredients ingredients_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: ingredients_fk_user_lnk ingredients_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_fk_user_lnk
    ADD CONSTRAINT ingredients_fk_user_lnk_fk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON DELETE CASCADE;


--
-- Name: ingredients_fk_user_lnk ingredients_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients_fk_user_lnk
    ADD CONSTRAINT ingredients_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: ingredients ingredients_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: inventory_alerts_acknowledged_by_lnk inventory_alerts_acknowledged_by_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_acknowledged_by_lnk
    ADD CONSTRAINT inventory_alerts_acknowledged_by_lnk_fk FOREIGN KEY (inventory_alert_id) REFERENCES public.inventory_alerts(id) ON DELETE CASCADE;


--
-- Name: inventory_alerts_acknowledged_by_lnk inventory_alerts_acknowledged_by_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_acknowledged_by_lnk
    ADD CONSTRAINT inventory_alerts_acknowledged_by_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: inventory_alerts inventory_alerts_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts
    ADD CONSTRAINT inventory_alerts_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: inventory_alerts_fk_user_lnk inventory_alerts_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_fk_user_lnk
    ADD CONSTRAINT inventory_alerts_fk_user_lnk_fk FOREIGN KEY (inventory_alert_id) REFERENCES public.inventory_alerts(id) ON DELETE CASCADE;


--
-- Name: inventory_alerts_fk_user_lnk inventory_alerts_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts_fk_user_lnk
    ADD CONSTRAINT inventory_alerts_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: inventory_alerts inventory_alerts_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_alerts
    ADD CONSTRAINT inventory_alerts_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: inventory_movements inventory_movements_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: inventory_movements_fk_bar_shift_lnk inventory_movements_fk_bar_shift_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_bar_shift_lnk
    ADD CONSTRAINT inventory_movements_fk_bar_shift_lnk_fk FOREIGN KEY (inventory_movement_id) REFERENCES public.inventory_movements(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_bar_shift_lnk inventory_movements_fk_bar_shift_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_bar_shift_lnk
    ADD CONSTRAINT inventory_movements_fk_bar_shift_lnk_ifk FOREIGN KEY (bar_shift_id) REFERENCES public.bar_shifts(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_ingredient_lnk inventory_movements_fk_ingredient_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_ingredient_lnk
    ADD CONSTRAINT inventory_movements_fk_ingredient_lnk_fk FOREIGN KEY (inventory_movement_id) REFERENCES public.inventory_movements(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_ingredient_lnk inventory_movements_fk_ingredient_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_ingredient_lnk
    ADD CONSTRAINT inventory_movements_fk_ingredient_lnk_ifk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_order_item_lnk inventory_movements_fk_order_item_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_item_lnk
    ADD CONSTRAINT inventory_movements_fk_order_item_lnk_fk FOREIGN KEY (inventory_movement_id) REFERENCES public.inventory_movements(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_order_item_lnk inventory_movements_fk_order_item_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_item_lnk
    ADD CONSTRAINT inventory_movements_fk_order_item_lnk_ifk FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_order_lnk inventory_movements_fk_order_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_lnk
    ADD CONSTRAINT inventory_movements_fk_order_lnk_fk FOREIGN KEY (inventory_movement_id) REFERENCES public.inventory_movements(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_order_lnk inventory_movements_fk_order_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_order_lnk
    ADD CONSTRAINT inventory_movements_fk_order_lnk_ifk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_restock_order_lnk inventory_movements_fk_restock_order_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_restock_order_lnk
    ADD CONSTRAINT inventory_movements_fk_restock_order_lnk_fk FOREIGN KEY (inventory_movement_id) REFERENCES public.inventory_movements(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_restock_order_lnk inventory_movements_fk_restock_order_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_restock_order_lnk
    ADD CONSTRAINT inventory_movements_fk_restock_order_lnk_ifk FOREIGN KEY (restock_order_id) REFERENCES public.restock_orders(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_user_lnk inventory_movements_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_user_lnk
    ADD CONSTRAINT inventory_movements_fk_user_lnk_fk FOREIGN KEY (inventory_movement_id) REFERENCES public.inventory_movements(id) ON DELETE CASCADE;


--
-- Name: inventory_movements_fk_user_lnk inventory_movements_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements_fk_user_lnk
    ADD CONSTRAINT inventory_movements_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: inventory_movements inventory_movements_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: menu_element_stats menu_element_stats_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats
    ADD CONSTRAINT menu_element_stats_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: menu_element_stats_fk_element_lnk menu_element_stats_fk_element_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_element_lnk
    ADD CONSTRAINT menu_element_stats_fk_element_lnk_fk FOREIGN KEY (menu_element_stat_id) REFERENCES public.menu_element_stats(id) ON DELETE CASCADE;


--
-- Name: menu_element_stats_fk_element_lnk menu_element_stats_fk_element_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_element_lnk
    ADD CONSTRAINT menu_element_stats_fk_element_lnk_ifk FOREIGN KEY (element_id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: menu_element_stats_fk_user_lnk menu_element_stats_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_user_lnk
    ADD CONSTRAINT menu_element_stats_fk_user_lnk_fk FOREIGN KEY (menu_element_stat_id) REFERENCES public.menu_element_stats(id) ON DELETE CASCADE;


--
-- Name: menu_element_stats_fk_user_lnk menu_element_stats_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats_fk_user_lnk
    ADD CONSTRAINT menu_element_stats_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: menu_element_stats menu_element_stats_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_element_stats
    ADD CONSTRAINT menu_element_stats_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: menu_import_jobs menu_import_jobs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs
    ADD CONSTRAINT menu_import_jobs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: menu_import_jobs_fk_user_lnk menu_import_jobs_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs_fk_user_lnk
    ADD CONSTRAINT menu_import_jobs_fk_user_lnk_fk FOREIGN KEY (menu_import_job_id) REFERENCES public.menu_import_jobs(id) ON DELETE CASCADE;


--
-- Name: menu_import_jobs_fk_user_lnk menu_import_jobs_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs_fk_user_lnk
    ADD CONSTRAINT menu_import_jobs_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: menu_import_jobs menu_import_jobs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_jobs
    ADD CONSTRAINT menu_import_jobs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: menu_import_leases menu_import_leases_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_leases
    ADD CONSTRAINT menu_import_leases_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: menu_import_leases menu_import_leases_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_import_leases
    ADD CONSTRAINT menu_import_leases_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: menus menus_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: menus_fk_elements_lnk menus_fk_elements_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_elements_lnk
    ADD CONSTRAINT menus_fk_elements_lnk_fk FOREIGN KEY (menu_id) REFERENCES public.menus(id) ON DELETE CASCADE;


--
-- Name: menus_fk_elements_lnk menus_fk_elements_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_elements_lnk
    ADD CONSTRAINT menus_fk_elements_lnk_ifk FOREIGN KEY (element_id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: menus_fk_user_lnk menus_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_user_lnk
    ADD CONSTRAINT menus_fk_user_lnk_fk FOREIGN KEY (menu_id) REFERENCES public.menus(id) ON DELETE CASCADE;


--
-- Name: menus_fk_user_lnk menus_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_fk_user_lnk
    ADD CONSTRAINT menus_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: menus menus_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: order_archives order_archives_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives
    ADD CONSTRAINT order_archives_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: order_archives_fk_user_lnk order_archives_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives_fk_user_lnk
    ADD CONSTRAINT order_archives_fk_user_lnk_fk FOREIGN KEY (order_archive_id) REFERENCES public.order_archives(id) ON DELETE CASCADE;


--
-- Name: order_archives_fk_user_lnk order_archives_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives_fk_user_lnk
    ADD CONSTRAINT order_archives_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: order_archives order_archives_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_archives
    ADD CONSTRAINT order_archives_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: order_item_addons order_item_addons_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons
    ADD CONSTRAINT order_item_addons_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: order_item_addons_fk_ingredient_lnk order_item_addons_fk_ingredient_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_ingredient_lnk
    ADD CONSTRAINT order_item_addons_fk_ingredient_lnk_fk FOREIGN KEY (order_item_addon_id) REFERENCES public.order_item_addons(id) ON DELETE CASCADE;


--
-- Name: order_item_addons_fk_ingredient_lnk order_item_addons_fk_ingredient_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_ingredient_lnk
    ADD CONSTRAINT order_item_addons_fk_ingredient_lnk_ifk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON DELETE CASCADE;


--
-- Name: order_item_addons_fk_order_item_lnk order_item_addons_fk_order_item_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_order_item_lnk
    ADD CONSTRAINT order_item_addons_fk_order_item_lnk_fk FOREIGN KEY (order_item_addon_id) REFERENCES public.order_item_addons(id) ON DELETE CASCADE;


--
-- Name: order_item_addons_fk_order_item_lnk order_item_addons_fk_order_item_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons_fk_order_item_lnk
    ADD CONSTRAINT order_item_addons_fk_order_item_lnk_ifk FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: order_item_addons order_item_addons_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons
    ADD CONSTRAINT order_item_addons_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: order_items order_items_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: order_items_fk_element_lnk order_items_fk_element_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_element_lnk
    ADD CONSTRAINT order_items_fk_element_lnk_fk FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: order_items_fk_element_lnk order_items_fk_element_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_element_lnk
    ADD CONSTRAINT order_items_fk_element_lnk_ifk FOREIGN KEY (element_id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: order_items_fk_order_lnk order_items_fk_order_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_order_lnk
    ADD CONSTRAINT order_items_fk_order_lnk_fk FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: order_items_fk_order_lnk order_items_fk_order_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items_fk_order_lnk
    ADD CONSTRAINT order_items_fk_order_lnk_ifk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: orders orders_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: orders_fk_table_lnk orders_fk_table_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_table_lnk
    ADD CONSTRAINT orders_fk_table_lnk_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders_fk_table_lnk orders_fk_table_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_table_lnk
    ADD CONSTRAINT orders_fk_table_lnk_ifk FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: orders_fk_user_lnk orders_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_user_lnk
    ADD CONSTRAINT orders_fk_user_lnk_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders_fk_user_lnk orders_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders_fk_user_lnk
    ADD CONSTRAINT orders_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: orders orders_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: owner_feature_grant_events owner_feature_grant_events_actor_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_feature_grant_events
    ADD CONSTRAINT owner_feature_grant_events_actor_id_foreign FOREIGN KEY (actor_id) REFERENCES public.up_users(id) ON DELETE SET NULL;


--
-- Name: owner_feature_grant_events owner_feature_grant_events_owner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_feature_grant_events
    ADD CONSTRAINT owner_feature_grant_events_owner_id_foreign FOREIGN KEY (owner_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: owner_feature_grants owner_feature_grants_owner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_feature_grants
    ADD CONSTRAINT owner_feature_grants_owner_id_foreign FOREIGN KEY (owner_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: payment_attempts payment_attempts_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts
    ADD CONSTRAINT payment_attempts_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: payment_attempts_fk_checkout_attempt_lnk payment_attempts_fk_checkout_attempt_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT payment_attempts_fk_checkout_attempt_lnk_fk FOREIGN KEY (payment_attempt_id) REFERENCES public.payment_attempts(id) ON DELETE CASCADE;


--
-- Name: payment_attempts_fk_checkout_attempt_lnk payment_attempts_fk_checkout_attempt_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_checkout_attempt_lnk
    ADD CONSTRAINT payment_attempts_fk_checkout_attempt_lnk_ifk FOREIGN KEY (checkout_attempt_id) REFERENCES public.checkout_attempts(id) ON DELETE CASCADE;


--
-- Name: payment_attempts_fk_user_lnk payment_attempts_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_user_lnk
    ADD CONSTRAINT payment_attempts_fk_user_lnk_fk FOREIGN KEY (payment_attempt_id) REFERENCES public.payment_attempts(id) ON DELETE CASCADE;


--
-- Name: payment_attempts_fk_user_lnk payment_attempts_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts_fk_user_lnk
    ADD CONSTRAINT payment_attempts_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: payment_attempts payment_attempts_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_attempts
    ADD CONSTRAINT payment_attempts_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pos_devices pos_devices_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices
    ADD CONSTRAINT pos_devices_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pos_devices_fk_user_lnk pos_devices_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices_fk_user_lnk
    ADD CONSTRAINT pos_devices_fk_user_lnk_fk FOREIGN KEY (pos_device_id) REFERENCES public.pos_devices(id) ON DELETE CASCADE;


--
-- Name: pos_devices_fk_user_lnk pos_devices_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices_fk_user_lnk
    ADD CONSTRAINT pos_devices_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: pos_devices pos_devices_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_devices
    ADD CONSTRAINT pos_devices_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pos_jobs pos_jobs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs
    ADD CONSTRAINT pos_jobs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pos_jobs_fk_device_lnk pos_jobs_fk_device_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_device_lnk
    ADD CONSTRAINT pos_jobs_fk_device_lnk_fk FOREIGN KEY (pos_job_id) REFERENCES public.pos_jobs(id) ON DELETE CASCADE;


--
-- Name: pos_jobs_fk_device_lnk pos_jobs_fk_device_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_device_lnk
    ADD CONSTRAINT pos_jobs_fk_device_lnk_ifk FOREIGN KEY (pos_device_id) REFERENCES public.pos_devices(id) ON DELETE CASCADE;


--
-- Name: pos_jobs_fk_order_lnk pos_jobs_fk_order_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_order_lnk
    ADD CONSTRAINT pos_jobs_fk_order_lnk_fk FOREIGN KEY (pos_job_id) REFERENCES public.pos_jobs(id) ON DELETE CASCADE;


--
-- Name: pos_jobs_fk_order_lnk pos_jobs_fk_order_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_order_lnk
    ADD CONSTRAINT pos_jobs_fk_order_lnk_ifk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: pos_jobs_fk_user_lnk pos_jobs_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_user_lnk
    ADD CONSTRAINT pos_jobs_fk_user_lnk_fk FOREIGN KEY (pos_job_id) REFERENCES public.pos_jobs(id) ON DELETE CASCADE;


--
-- Name: pos_jobs_fk_user_lnk pos_jobs_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs_fk_user_lnk
    ADD CONSTRAINT pos_jobs_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: pos_jobs pos_jobs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_jobs
    ADD CONSTRAINT pos_jobs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pos_pairing_tokens pos_pairing_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens
    ADD CONSTRAINT pos_pairing_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pos_pairing_tokens_fk_user_lnk pos_pairing_tokens_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens_fk_user_lnk
    ADD CONSTRAINT pos_pairing_tokens_fk_user_lnk_fk FOREIGN KEY (pos_pairing_token_id) REFERENCES public.pos_pairing_tokens(id) ON DELETE CASCADE;


--
-- Name: pos_pairing_tokens_fk_user_lnk pos_pairing_tokens_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens_fk_user_lnk
    ADD CONSTRAINT pos_pairing_tokens_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: pos_pairing_tokens pos_pairing_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_pairing_tokens
    ADD CONSTRAINT pos_pairing_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: reservations reservations_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: reservations_fk_order_lnk reservations_fk_order_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_order_lnk
    ADD CONSTRAINT reservations_fk_order_lnk_fk FOREIGN KEY (reservation_id) REFERENCES public.reservations(id) ON DELETE CASCADE;


--
-- Name: reservations_fk_order_lnk reservations_fk_order_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_order_lnk
    ADD CONSTRAINT reservations_fk_order_lnk_ifk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: reservations_fk_table_lnk reservations_fk_table_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_table_lnk
    ADD CONSTRAINT reservations_fk_table_lnk_fk FOREIGN KEY (reservation_id) REFERENCES public.reservations(id) ON DELETE CASCADE;


--
-- Name: reservations_fk_table_lnk reservations_fk_table_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_table_lnk
    ADD CONSTRAINT reservations_fk_table_lnk_ifk FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: reservations_fk_user_lnk reservations_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_user_lnk
    ADD CONSTRAINT reservations_fk_user_lnk_fk FOREIGN KEY (reservation_id) REFERENCES public.reservations(id) ON DELETE CASCADE;


--
-- Name: reservations_fk_user_lnk reservations_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations_fk_user_lnk
    ADD CONSTRAINT reservations_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: reservations reservations_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: restaurant_category_routing restaurant_category_routing_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_category_routing
    ADD CONSTRAINT restaurant_category_routing_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: restaurant_daily_stats restaurant_daily_stats_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats
    ADD CONSTRAINT restaurant_daily_stats_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: restaurant_daily_stats_fk_user_lnk restaurant_daily_stats_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats_fk_user_lnk
    ADD CONSTRAINT restaurant_daily_stats_fk_user_lnk_fk FOREIGN KEY (restaurant_daily_stat_id) REFERENCES public.restaurant_daily_stats(id) ON DELETE CASCADE;


--
-- Name: restaurant_daily_stats_fk_user_lnk restaurant_daily_stats_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats_fk_user_lnk
    ADD CONSTRAINT restaurant_daily_stats_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: restaurant_daily_stats restaurant_daily_stats_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_daily_stats
    ADD CONSTRAINT restaurant_daily_stats_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: restaurant_printer_configs restaurant_printer_configs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs
    ADD CONSTRAINT restaurant_printer_configs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: restaurant_printer_configs_fk_user_lnk restaurant_printer_configs_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs_fk_user_lnk
    ADD CONSTRAINT restaurant_printer_configs_fk_user_lnk_fk FOREIGN KEY (restaurant_printer_config_id) REFERENCES public.restaurant_printer_configs(id) ON DELETE CASCADE;


--
-- Name: restaurant_printer_configs_fk_user_lnk restaurant_printer_configs_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs_fk_user_lnk
    ADD CONSTRAINT restaurant_printer_configs_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: restaurant_printer_configs restaurant_printer_configs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_printer_configs
    ADD CONSTRAINT restaurant_printer_configs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: restaurant_staff restaurant_staff_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_staff
    ADD CONSTRAINT restaurant_staff_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: restaurant_staff restaurant_staff_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_staff
    ADD CONSTRAINT restaurant_staff_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: restock_orders restock_orders_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders
    ADD CONSTRAINT restock_orders_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: restock_orders_fk_ingredient_lnk restock_orders_fk_ingredient_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_ingredient_lnk
    ADD CONSTRAINT restock_orders_fk_ingredient_lnk_fk FOREIGN KEY (restock_order_id) REFERENCES public.restock_orders(id) ON DELETE CASCADE;


--
-- Name: restock_orders_fk_ingredient_lnk restock_orders_fk_ingredient_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_ingredient_lnk
    ADD CONSTRAINT restock_orders_fk_ingredient_lnk_ifk FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON DELETE CASCADE;


--
-- Name: restock_orders_fk_user_lnk restock_orders_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_user_lnk
    ADD CONSTRAINT restock_orders_fk_user_lnk_fk FOREIGN KEY (restock_order_id) REFERENCES public.restock_orders(id) ON DELETE CASCADE;


--
-- Name: restock_orders_fk_user_lnk restock_orders_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders_fk_user_lnk
    ADD CONSTRAINT restock_orders_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: restock_orders restock_orders_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restock_orders
    ADD CONSTRAINT restock_orders_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_fk FOREIGN KEY (api_token_permission_id) REFERENCES public.strapi_api_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_ifk FOREIGN KEY (api_token_id) REFERENCES public.strapi_api_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens_admin_user_owner_lnk strapi_api_tokens_admin_user_owner_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens_admin_user_owner_lnk
    ADD CONSTRAINT strapi_api_tokens_admin_user_owner_lnk_fk FOREIGN KEY (api_token_id) REFERENCES public.strapi_api_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_api_tokens_admin_user_owner_lnk strapi_api_tokens_admin_user_owner_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens_admin_user_owner_lnk
    ADD CONSTRAINT strapi_api_tokens_admin_user_owner_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- Name: strapi_api_tokens strapi_api_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_history_versions strapi_history_versions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions strapi_release_actions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_fk FOREIGN KEY (release_action_id) REFERENCES public.strapi_release_actions(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_ifk FOREIGN KEY (release_id) REFERENCES public.strapi_releases(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions strapi_release_actions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_fk FOREIGN KEY (transfer_token_permission_id) REFERENCES public.strapi_transfer_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_ifk FOREIGN KEY (transfer_token_id) REFERENCES public.strapi_transfer_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows strapi_workflows_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_fk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_ifk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_ifk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_ifk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows strapi_workflows_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: suppliers suppliers_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: suppliers_fk_user_lnk suppliers_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers_fk_user_lnk
    ADD CONSTRAINT suppliers_fk_user_lnk_fk FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE CASCADE;


--
-- Name: suppliers_fk_user_lnk suppliers_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers_fk_user_lnk
    ADD CONSTRAINT suppliers_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: suppliers suppliers_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: sync_events sync_events_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events
    ADD CONSTRAINT sync_events_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: sync_events_fk_user_lnk sync_events_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events_fk_user_lnk
    ADD CONSTRAINT sync_events_fk_user_lnk_fk FOREIGN KEY (sync_event_id) REFERENCES public.sync_events(id) ON DELETE CASCADE;


--
-- Name: sync_events_fk_user_lnk sync_events_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events_fk_user_lnk
    ADD CONSTRAINT sync_events_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: sync_events sync_events_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_events
    ADD CONSTRAINT sync_events_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: table_order_access_points table_order_access_points_bound_table_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_access_points
    ADD CONSTRAINT table_order_access_points_bound_table_id_foreign FOREIGN KEY (bound_table_id) REFERENCES public.tables(id) ON DELETE SET NULL;


--
-- Name: table_order_access_points table_order_access_points_owner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_access_points
    ADD CONSTRAINT table_order_access_points_owner_id_foreign FOREIGN KEY (owner_id) REFERENCES public.up_users(id);


--
-- Name: table_order_commands table_order_commands_participant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_commands
    ADD CONSTRAINT table_order_commands_participant_id_foreign FOREIGN KEY (participant_id) REFERENCES public.table_order_participants(id);


--
-- Name: table_order_commands table_order_commands_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_commands
    ADD CONSTRAINT table_order_commands_session_id_foreign FOREIGN KEY (session_id) REFERENCES public.table_order_sessions(id);


--
-- Name: table_order_participants table_order_participants_access_point_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_participants
    ADD CONSTRAINT table_order_participants_access_point_id_foreign FOREIGN KEY (access_point_id) REFERENCES public.table_order_access_points(id);


--
-- Name: table_order_participants table_order_participants_owner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_participants
    ADD CONSTRAINT table_order_participants_owner_id_foreign FOREIGN KEY (owner_id) REFERENCES public.up_users(id);


--
-- Name: table_order_participants table_order_participants_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_participants
    ADD CONSTRAINT table_order_participants_session_id_foreign FOREIGN KEY (session_id) REFERENCES public.table_order_sessions(id);


--
-- Name: table_order_service_requests table_order_service_requests_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_service_requests
    ADD CONSTRAINT table_order_service_requests_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: table_order_service_requests table_order_service_requests_owner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_service_requests
    ADD CONSTRAINT table_order_service_requests_owner_id_foreign FOREIGN KEY (owner_id) REFERENCES public.up_users(id);


--
-- Name: table_order_service_requests table_order_service_requests_participant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_service_requests
    ADD CONSTRAINT table_order_service_requests_participant_id_foreign FOREIGN KEY (participant_id) REFERENCES public.table_order_participants(id) ON DELETE SET NULL;


--
-- Name: table_order_service_requests table_order_service_requests_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_service_requests
    ADD CONSTRAINT table_order_service_requests_session_id_foreign FOREIGN KEY (session_id) REFERENCES public.table_order_sessions(id);


--
-- Name: table_order_service_requests table_order_service_requests_table_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_service_requests
    ADD CONSTRAINT table_order_service_requests_table_id_foreign FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE SET NULL;


--
-- Name: table_order_sessions table_order_sessions_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_sessions
    ADD CONSTRAINT table_order_sessions_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: table_order_sessions table_order_sessions_owner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_sessions
    ADD CONSTRAINT table_order_sessions_owner_id_foreign FOREIGN KEY (owner_id) REFERENCES public.up_users(id);


--
-- Name: table_order_sessions table_order_sessions_table_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_order_sessions
    ADD CONSTRAINT table_order_sessions_table_id_foreign FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE SET NULL;


--
-- Name: tables tables_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: tables_fk_origins_lnk tables_fk_origins_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_origins_lnk
    ADD CONSTRAINT tables_fk_origins_lnk_fk FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: tables_fk_origins_lnk tables_fk_origins_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_origins_lnk
    ADD CONSTRAINT tables_fk_origins_lnk_ifk FOREIGN KEY (inv_table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: tables_fk_user_lnk tables_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_user_lnk
    ADD CONSTRAINT tables_fk_user_lnk_fk FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: tables_fk_user_lnk tables_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_user_lnk
    ADD CONSTRAINT tables_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: tables_fk_zone_lnk tables_fk_zone_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_zone_lnk
    ADD CONSTRAINT tables_fk_zone_lnk_fk FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: tables_fk_zone_lnk tables_fk_zone_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables_fk_zone_lnk
    ADD CONSTRAINT tables_fk_zone_lnk_ifk FOREIGN KEY (zone_id) REFERENCES public.zones(id) ON DELETE CASCADE;


--
-- Name: tables tables_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: takeaway_time_proposals takeaway_time_proposals_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals
    ADD CONSTRAINT takeaway_time_proposals_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: takeaway_time_proposals_fk_order_lnk takeaway_time_proposals_fk_order_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_order_lnk
    ADD CONSTRAINT takeaway_time_proposals_fk_order_lnk_fk FOREIGN KEY (takeaway_time_proposal_id) REFERENCES public.takeaway_time_proposals(id) ON DELETE CASCADE;


--
-- Name: takeaway_time_proposals_fk_order_lnk takeaway_time_proposals_fk_order_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_order_lnk
    ADD CONSTRAINT takeaway_time_proposals_fk_order_lnk_ifk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: takeaway_time_proposals_fk_user_lnk takeaway_time_proposals_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_user_lnk
    ADD CONSTRAINT takeaway_time_proposals_fk_user_lnk_fk FOREIGN KEY (takeaway_time_proposal_id) REFERENCES public.takeaway_time_proposals(id) ON DELETE CASCADE;


--
-- Name: takeaway_time_proposals_fk_user_lnk takeaway_time_proposals_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals_fk_user_lnk
    ADD CONSTRAINT takeaway_time_proposals_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: takeaway_time_proposals takeaway_time_proposals_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.takeaway_time_proposals
    ADD CONSTRAINT takeaway_time_proposals_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions up_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.up_permissions(id) ON DELETE CASCADE;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_permissions up_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users up_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users_fk_owner_lnk up_users_fk_owner_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_fk_owner_lnk
    ADD CONSTRAINT up_users_fk_owner_lnk_fk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: up_users_fk_owner_lnk up_users_fk_owner_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_fk_owner_lnk
    ADD CONSTRAINT up_users_fk_owner_lnk_ifk FOREIGN KEY (inv_user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: up_users_role_lnk up_users_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_fk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: up_users_role_lnk up_users_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_users up_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders upload_folders_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_fk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_ifk FOREIGN KEY (inv_folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders upload_folders_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: website_configs website_configs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs
    ADD CONSTRAINT website_configs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: website_configs_fk_user_lnk website_configs_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs_fk_user_lnk
    ADD CONSTRAINT website_configs_fk_user_lnk_fk FOREIGN KEY (website_config_id) REFERENCES public.website_configs(id) ON DELETE CASCADE;


--
-- Name: website_configs_fk_user_lnk website_configs_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs_fk_user_lnk
    ADD CONSTRAINT website_configs_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: website_configs website_configs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_configs
    ADD CONSTRAINT website_configs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: zones zones_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones
    ADD CONSTRAINT zones_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: zones_fk_user_lnk zones_fk_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones_fk_user_lnk
    ADD CONSTRAINT zones_fk_user_lnk_fk FOREIGN KEY (zone_id) REFERENCES public.zones(id) ON DELETE CASCADE;


--
-- Name: zones_fk_user_lnk zones_fk_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones_fk_user_lnk
    ADD CONSTRAINT zones_fk_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: zones zones_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zones
    ADD CONSTRAINT zones_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_permissions_api_token_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_permissions_api_token_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_permissions_role_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_permissions_role_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_users_roles_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.admin_users_roles_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_hardware_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_hardware_events ENABLE ROW LEVEL SECURITY;

--
-- Name: bar_shifts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bar_shifts ENABLE ROW LEVEL SECURITY;

--
-- Name: bar_shifts_closed_by_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bar_shifts_closed_by_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: bar_shifts_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bar_shifts_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: bar_shifts_opened_by_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bar_shifts_opened_by_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: checkout_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.checkout_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: checkout_attempts_fk_order_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.checkout_attempts_fk_order_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: checkout_attempts_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.checkout_attempts_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: ct_idempotency_keys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ct_idempotency_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: element_ingredients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.element_ingredients ENABLE ROW LEVEL SECURITY;

--
-- Name: element_ingredients_fk_element_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.element_ingredients_fk_element_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: element_ingredients_fk_ingredient_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.element_ingredients_fk_ingredient_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: elements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.elements ENABLE ROW LEVEL SECURITY;

--
-- Name: elements_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.elements_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_definitions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feature_definitions ENABLE ROW LEVEL SECURITY;

--
-- Name: files; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.files ENABLE ROW LEVEL SECURITY;

--
-- Name: files_folder_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.files_folder_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: files_related_mph; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.files_related_mph ENABLE ROW LEVEL SECURITY;

--
-- Name: fiscal_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fiscal_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: fiscal_attempts_fk_checkout_attempt_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fiscal_attempts_fk_checkout_attempt_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: fiscal_attempts_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fiscal_attempts_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: fiscal_correction_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fiscal_correction_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: fiscal_correction_attempts_fk_checkout_attempt_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fiscal_correction_attempts_fk_checkout_attempt_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: fiscal_correction_attempts_fk_fiscal_attempt_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fiscal_correction_attempts_fk_fiscal_attempt_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: fiscal_correction_attempts_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fiscal_correction_attempts_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: hardware_endpoints; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hardware_endpoints ENABLE ROW LEVEL SECURITY;

--
-- Name: hardware_endpoints_fk_pos_device_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hardware_endpoints_fk_pos_device_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: hardware_endpoints_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hardware_endpoints_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: hardware_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hardware_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: hardware_jobs_fk_checkout_attempt_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hardware_jobs_fk_checkout_attempt_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: hardware_jobs_fk_hardware_endpoint_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hardware_jobs_fk_hardware_endpoint_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: hardware_jobs_fk_pos_device_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hardware_jobs_fk_pos_device_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: hardware_jobs_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hardware_jobs_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: i18n_locale; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.i18n_locale ENABLE ROW LEVEL SECURITY;

--
-- Name: ingredients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ingredients ENABLE ROW LEVEL SECURITY;

--
-- Name: ingredients_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ingredients_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_alerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_alerts_acknowledged_by_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_alerts_acknowledged_by_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_alerts_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_alerts_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_movements_fk_bar_shift_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements_fk_bar_shift_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_movements_fk_ingredient_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements_fk_ingredient_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_movements_fk_order_item_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements_fk_order_item_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_movements_fk_order_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements_fk_order_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_movements_fk_restock_order_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements_fk_restock_order_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_movements_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: menu_element_stats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.menu_element_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: menu_element_stats_fk_element_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.menu_element_stats_fk_element_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: menu_element_stats_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.menu_element_stats_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: menus; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.menus ENABLE ROW LEVEL SECURITY;

--
-- Name: menus_fk_elements_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.menus_fk_elements_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: menus_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.menus_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: order_archives; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_archives ENABLE ROW LEVEL SECURITY;

--
-- Name: order_archives_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_archives_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: order_item_addons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_item_addons ENABLE ROW LEVEL SECURITY;

--
-- Name: order_item_addons_fk_ingredient_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_item_addons_fk_ingredient_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: order_item_addons_fk_order_item_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_item_addons_fk_order_item_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: order_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

--
-- Name: order_items_fk_element_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_items_fk_element_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: order_items_fk_order_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_items_fk_order_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: order_realtime_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_realtime_events ENABLE ROW LEVEL SECURITY;

--
-- Name: order_realtime_events order_realtime_events_tenant_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY order_realtime_events_tenant_select ON public.order_realtime_events FOR SELECT TO authenticated USING ((user_id = ((auth.jwt() ->> 'app_user_id'::text))::bigint));


--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

--
-- Name: orders_fk_table_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.orders_fk_table_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: orders_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.orders_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: owner_feature_grant_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.owner_feature_grant_events ENABLE ROW LEVEL SECURITY;

--
-- Name: owner_feature_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.owner_feature_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_attempts_fk_checkout_attempt_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_attempts_fk_checkout_attempt_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_attempts_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_attempts_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_devices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_devices ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_devices_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_devices_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_jobs_fk_device_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_jobs_fk_device_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_jobs_fk_order_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_jobs_fk_order_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_jobs_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_jobs_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_pairing_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_pairing_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: pos_pairing_tokens_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pos_pairing_tokens_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: reservations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reservations ENABLE ROW LEVEL SECURITY;

--
-- Name: reservations_fk_order_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reservations_fk_order_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: reservations_fk_table_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reservations_fk_table_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: reservations_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reservations_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: restaurant_category_routing; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restaurant_category_routing ENABLE ROW LEVEL SECURITY;

--
-- Name: restaurant_daily_stats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restaurant_daily_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: restaurant_daily_stats_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restaurant_daily_stats_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: restaurant_printer_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restaurant_printer_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: restaurant_printer_configs_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restaurant_printer_configs_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: restaurant_staff; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restaurant_staff ENABLE ROW LEVEL SECURITY;

--
-- Name: restock_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restock_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: restock_orders_fk_ingredient_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restock_orders_fk_ingredient_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: restock_orders_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.restock_orders_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_ai_localization_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_ai_localization_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_ai_metadata_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_ai_metadata_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_api_token_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_api_token_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_api_token_permissions_token_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_api_token_permissions_token_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_api_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_api_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_api_tokens_admin_user_owner_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_api_tokens_admin_user_owner_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_core_store_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_core_store_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_database_schema; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_database_schema ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_history_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_history_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_migrations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_migrations_internal; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_migrations_internal ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_release_actions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_release_actions ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_release_actions_release_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_release_actions_release_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_releases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_releases ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_transfer_token_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_transfer_token_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_transfer_token_permissions_token_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_transfer_token_permissions_token_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_transfer_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_transfer_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_webhooks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_workflows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_workflows ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_workflows_stage_required_to_publish_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_workflows_stages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_workflows_stages ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_workflows_stages_permissions_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_workflows_stages_permissions_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: strapi_workflows_stages_workflow_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.strapi_workflows_stages_workflow_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: suppliers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

--
-- Name: suppliers_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suppliers_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: sync_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sync_events ENABLE ROW LEVEL SECURITY;

--
-- Name: sync_events_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sync_events_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: table_order_realtime_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.table_order_realtime_events ENABLE ROW LEVEL SECURITY;

--
-- Name: table_order_realtime_events table_order_realtime_events_no_write; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY table_order_realtime_events_no_write ON public.table_order_realtime_events TO authenticated, anon USING (false) WITH CHECK (false);


--
-- Name: table_order_realtime_events table_order_realtime_events_session_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY table_order_realtime_events_session_select ON public.table_order_realtime_events FOR SELECT TO authenticated USING (((session_public_id)::text = (auth.jwt() ->> 'table_order_session_id'::text)));


--
-- Name: tables; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tables ENABLE ROW LEVEL SECURITY;

--
-- Name: tables_fk_origins_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tables_fk_origins_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: tables_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tables_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: tables_fk_zone_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tables_fk_zone_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: up_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.up_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: up_permissions_role_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.up_permissions_role_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: up_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.up_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: up_users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.up_users ENABLE ROW LEVEL SECURITY;

--
-- Name: up_users_fk_owner_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.up_users_fk_owner_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: up_users_role_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.up_users_role_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: upload_folders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.upload_folders ENABLE ROW LEVEL SECURITY;

--
-- Name: upload_folders_parent_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.upload_folders_parent_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: website_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.website_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: website_configs_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.website_configs_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: zones; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.zones ENABLE ROW LEVEL SECURITY;

--
-- Name: zones_fk_user_lnk; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.zones_fk_user_lnk ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime order_realtime_events; Type: PUBLICATION TABLE; Schema: public; Owner: -
--

ALTER PUBLICATION supabase_realtime ADD TABLE ONLY public.order_realtime_events;


--
-- Name: supabase_realtime table_order_realtime_events; Type: PUBLICATION TABLE; Schema: public; Owner: -
--

ALTER PUBLICATION supabase_realtime ADD TABLE ONLY public.table_order_realtime_events;


--
-- PostgreSQL database dump complete
--


